export interface IncomeRangePayload {
    name: string;
    code:string;
    uid:string;
}