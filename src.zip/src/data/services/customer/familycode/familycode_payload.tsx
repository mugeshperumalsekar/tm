export interface FamilyCodePayload {
    name: string;
    code:string;
    uid:string;
}

