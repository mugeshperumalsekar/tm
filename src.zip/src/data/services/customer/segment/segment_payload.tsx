export interface SegmentPayload {
    name: string;
    code:string;
    uid:string;
}