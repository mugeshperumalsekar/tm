export interface ChannelPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

