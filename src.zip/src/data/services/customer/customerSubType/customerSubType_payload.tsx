export interface CustomerSubTypePayload {
    name: string;
    code:string;
    uid:string;
}