export interface InsiderInformationPayload {
    name: string;
    code:string;
    uid:string;
}

