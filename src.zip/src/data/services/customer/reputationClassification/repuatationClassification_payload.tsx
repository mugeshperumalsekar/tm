export interface ReputationClassificationPayload {
    name: string;
    code:string;
    uid:string;
}