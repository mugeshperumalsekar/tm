export interface RelationPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

