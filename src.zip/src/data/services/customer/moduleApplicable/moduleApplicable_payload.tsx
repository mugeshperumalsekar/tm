export interface ModuleApplicablePayload {
    name: string;
    code:string;
    uid:string;
}