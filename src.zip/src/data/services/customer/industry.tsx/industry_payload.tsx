export interface IndustryPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

