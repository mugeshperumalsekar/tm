export interface MaritalStatusPayload {
    name: string;
    code:string;
    uid:string;
}