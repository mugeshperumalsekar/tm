export interface AttachmentPayload{
    name:string;
    code:string;
    uid:number;
}