export interface TagPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

