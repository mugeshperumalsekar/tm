
export interface SourceOfFundPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

