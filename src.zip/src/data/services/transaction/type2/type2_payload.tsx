
export interface Type2Payload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

