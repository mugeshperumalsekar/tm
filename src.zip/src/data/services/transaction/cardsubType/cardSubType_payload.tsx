
export interface CardSubTypePayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

