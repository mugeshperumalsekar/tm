export interface ExcelRow {
    [key: string]: string | number | boolean;
  }
  