export interface RegAMLRiskPayload {
    name: string;
    code:string;
    uid:string;
}