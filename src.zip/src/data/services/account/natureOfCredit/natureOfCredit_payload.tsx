export interface NatureOfCreditPayload {
    name: string;
    code:string;
    uid:string;
}