export interface AccountRelationPayload {
    name: string;
    code:string;
    uid:string;
}