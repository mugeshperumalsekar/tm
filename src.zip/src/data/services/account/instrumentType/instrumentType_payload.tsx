export interface InstrumentTypePayload {
    name: string;
    code:string;
    uid:string;
}