import HttpClientWrapper from "../../api/http-client-wrapper";
import { Configparamenter } from "./configparameter_payload";

class ConfigparamenterApiService {

  private httpClientWrapper: HttpClientWrapper;

  constructor() {
    this.httpClientWrapper = new HttpClientWrapper();
  }

  getScenarioList = async () => {
    try {
      const response = await this.httpClientWrapper.get('/api/v1/scenario-lists/fetch');
      return response;
    } catch (error) {
      throw error;
    }
  };

  getScenarioParamMapping = async () => {
    try {
      const response = await this.httpClientWrapper.get('/api/v1/ScenarioParamMapping/fetchAllScenarioParamMapping');
      return response;
    } catch (error) {
      throw error;
    }
  };

  getExistingMapping = async (scenarioListId: number, scenarioConditionId: number) => {
    try {
      const response = await this.httpClientWrapper.get(`/api/v1/ScenarioParamMapping/${scenarioListId}/scenario_condition_id?scenario_list_id=${scenarioListId}&scenario_condition_id=${scenarioConditionId}`);
      return response;
    } catch (error) {
      console.error(`Error fetching the getExistingMapping:`, error);
      throw error;
    }
  };

  CreateScenarioParamMapping = async (payload: Configparamenter[]) => {
    try {
      const response = await this.httpClientWrapper.post('/api/v1/ScenarioParamMapping/CreateScenarioParamMapping', payload);
      return response;
    } catch (error) {
      console.error(`Error fetching the createScenarioParamMapping:`, error);
      throw error;
    }
  };

  updateScenarioParamMapping = async (setScenarioListId: number, setScenarioConditionId: number, payload: Configparamenter[]) => {
    try {
      const response = await this.httpClientWrapper.put(`/api/v1/ScenarioParamMapping/${setScenarioListId}/${setScenarioConditionId}`, payload);
      return response;
    } catch (error) {
      console.error(`Error fetching the UpdateScenarioParamMapping:`, error);
      throw error;
    }
  };

}

export default ConfigparamenterApiService;