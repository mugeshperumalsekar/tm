import React, { useState, useEffect } from 'react';
import { Box, FormControl, InputLabel, Select, MenuItem, Button, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, Checkbox, Typography, Card, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import Header from '../../layouts/header/header';
import { SelectChangeEvent } from '@mui/material/Select';
import ConfigparamenterApiService from '../../data/services/configparameter/configparamenter_api_service';
import { Snackbar, Alert } from '@mui/material';

export interface ScenarioList {
    id: number;
    name: string;
    code: number;
}

export interface TableRowData {
    scenarioConditionId: number;
    transactionType: string | null;
    customerType: string | null;
    customerRisk: string | null;
    customerSegment: string | null;
    occupationType: string | null;
}

function ConfigParameter() {

    const [selectedValue, setSelectedValue] = useState('');
    const [scenarioList, setScenarioList] = useState<ScenarioList[]>([]);
    const [tableData, setTableData] = useState<TableRowData[]>([]);
    const [selectedRows, setSelectedRows] = useState<{ [key: number]: boolean }>({});
    const [selectAll, setSelectAll] = useState(false);
    const configparamenter = new ConfigparamenterApiService();
    const [selectedMapping, setSelectedMapping] = useState<TableRowData | null>(null);
    const [openDialog, setOpenDialog] = useState(false);
    const [dialogAction, setDialogAction] = useState<'create' | 'update'>('create');
    const [successMessage, setSuccessMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [openSnackbar, setOpenSnackbar] = useState<boolean>(false);

    useEffect(() => {
        const fetchScenarioList = async () => {
            try {
                const response = await configparamenter.getScenarioList();
                setScenarioList(response);
            } catch (error) {
                console.error('Error fetching scenarios:', error);
            }
        };
        fetchScenarioList();
    }, []);

    useEffect(() => {
        fetchTableData()
    }, []);

    const fetchTableData = async () => {
        try {
            const response: TableRowData[] = await configparamenter.getScenarioParamMapping();
            setTableData(response);
        } catch (error) {
            console.error('Error fetching table data:', error);
        }
    };

    const handleChange = (event: SelectChangeEvent<string>) => {
        setSelectedValue(event.target.value);
    };

    const handleSelectAll = (event: React.ChangeEvent<HTMLInputElement>) => {
        const isChecked = event.target.checked;
        setSelectAll(isChecked);
        const updatedSelectedRows: { [key: number]: boolean } = {};
        tableData.forEach((row) => {
            updatedSelectedRows[row.scenarioConditionId] = isChecked;
        });
        setSelectedRows(updatedSelectedRows);
    };

    const handleRowCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, rowId: number) => {
        setSelectedRows((prev) => {
            const newSelectedRows = { ...prev };
            newSelectedRows[rowId] = event.target.checked;
            return newSelectedRows;
        });
    };

    const handleSubmit = async () => {
        if (!selectedValue) {
            alert("Please select a scenario!");
            return;
        }
        const selectedRowsData = selectAll ? tableData : tableData.filter(row => selectedRows[row.scenarioConditionId]);
        if (selectedRowsData.length === 0) {
            alert("Please select at least one row!");
            return;
        }
        try {
            const existingMappings = await configparamenter.getExistingMapping(Number(selectedValue), selectedRowsData[0].scenarioConditionId);
            if (existingMappings && existingMappings.length > 0) {
                setSelectedMapping(existingMappings[0]);
                setDialogAction('update');
                setOpenDialog(true);
            } else {
                const payload = selectedRowsData.map(row => ({
                    scenario_list_id: Number(selectedValue),
                    scenario_condition_id: row.scenarioConditionId,
                    uid: 1,
                    euid: 1,
                }));
                await configparamenter.CreateScenarioParamMapping(payload);
                setSuccessMessage('ScenarioParameterMapping Insert successfully!');
                setOpenSnackbar(true);
                fetchTableData();
            }
        } catch (error) {
            console.error("Error handling submit:", error);
            setErrorMessage('Error saving data.');
            setOpenSnackbar(true);
        }
    };

    const handleSnackbarClose = () => {
        setOpenSnackbar(false);
        setSuccessMessage('');
        setErrorMessage('');
    };

    const handleConfirmDialog = async () => {
        try {
            const selectedRowsData = selectAll ? tableData : tableData.filter(row => selectedRows[row.scenarioConditionId]);
            const payload = selectedRowsData.map(row => ({
                scenario_list_id: Number(selectedValue),
                scenario_condition_id: row.scenarioConditionId,
                uid: 1,
                euid: 1,
            }));
            await configparamenter.updateScenarioParamMapping(
                Number(selectedValue),
                selectedRowsData[0].scenarioConditionId,
                payload
            );
            setOpenDialog(false);
            setSuccessMessage(' updated successfully!');
            setOpenSnackbar(true);
            fetchTableData();
        } catch (error) {
            console.error("Error confirming dialog action:", error);
            setErrorMessage('Error saving data.');
            setOpenSnackbar(true);
        }
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };

    return (
        <Box sx={{ display: 'flex' }}>
            <Header />
            <Box component="main" sx={{ flexGrow: 1, p: 3, m: 4 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                    <h6 className='allheading'> CONFIG PARAMETER </h6>
                </Box>
                <div style={{ display: 'flex', gap: '8px' }}>
                    <FormControl className="custom-textfield .MuiInputBase-root" fullWidth>
                        <InputLabel className="custom-textfield .MuiInputBase-root" htmlFor="Scenario-List">Scenario List</InputLabel>
                        <Select
                            size='small'
                            className="custom-textfield .MuiInputBase-root"
                            labelId="config-parameter-select-label"
                            value={selectedValue}
                            onChange={handleChange}
                            label="Select Parameter"
                        >
                            {scenarioList.map((scenario) => (
                                <MenuItem className="custom-menu-item" key={scenario.id} value={scenario.id}>
                                    {scenario.name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </div>
                <br></br>
                <TableContainer component={Card} style={{ maxHeight: '350px', overflow: 'auto' }}>
                    <Table size="small" >
                        <TableHead>
                            <TableRow>
                                <TableCell>
                                    <Checkbox sx={{
                                        fontSize: '16px',
                                        transform: 'scale(0.75)',
                                    }}
                                        checked={selectAll}
                                        onChange={handleSelectAll}
                                    />
                                </TableCell>
                                <TableCell className="MuiTableCell-head">S.No</TableCell>
                                <TableCell className="MuiTableCell-head">Transaction Type</TableCell>
                                <TableCell className="MuiTableCell-head">Customer Type</TableCell>
                                <TableCell className="MuiTableCell-head">Customer Risk</TableCell>
                                <TableCell className="MuiTableCell-head">Customer Segment</TableCell>
                                <TableCell className="MuiTableCell-head">Occupation Type</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {tableData.map((row, index) => (
                                <TableRow key={row.scenarioConditionId}>
                                    <TableCell className="small-cells">
                                        <Checkbox
                                            sx={{
                                                fontSize: '16px',
                                                transform: 'scale(0.75)',
                                            }}
                                            checked={selectedRows[row.scenarioConditionId] || false}
                                            onChange={(e) => handleRowCheckboxChange(e, row.scenarioConditionId)}
                                        />
                                    </TableCell>
                                    <TableCell className="small-cells">{index + 1}</TableCell>
                                    <TableCell>{row.transactionType || 'N/A'}</TableCell>
                                    <TableCell className="small-cells">
                                        <Checkbox style={{ fontSize: '16px' }}
                                            disabled
                                            checked={row.customerType === 'A'}
                                            icon={<span style={{ color: 'red', fontSize: '16px' }}>✖</span>}
                                            checkedIcon={<span style={{ color: 'green', fontSize: '16px' }}>✔</span>}
                                            sx={{
                                                color: row.customerType === 'A' ? 'green' : 'red',
                                                '& .MuiSvgIcon-root': {
                                                    color: row.customerType === 'A' ? 'green' : 'red',
                                                },
                                            }}
                                        />
                                    </TableCell>
                                    <TableCell className="small-cells">
                                        <Checkbox
                                            checked={row.customerRisk === 'A'}
                                            disabled
                                            icon={<span style={{ color: 'red', fontSize: '16px' }}>✖</span>}
                                            checkedIcon={<span style={{ color: 'green', fontSize: '16px' }}>✔</span>}
                                            sx={{
                                                color: row.customerRisk === 'A' ? 'green' : 'red',
                                                '& .MuiSvgIcon-root': {
                                                    color: row.customerRisk === 'A' ? 'green' : 'red',
                                                },
                                            }}
                                        />
                                    </TableCell>
                                    <TableCell className="small-cells">
                                        <Checkbox
                                            disabled
                                            checked={row.customerSegment === 'A'}
                                            icon={<span style={{ color: 'red', fontSize: '16px' }}>✖</span>}
                                            checkedIcon={<span style={{ color: 'green', fontSize: '16px' }}>✔</span>}
                                            sx={{
                                                color: row.customerSegment === 'A' ? 'green' : 'red',
                                                '& .MuiSvgIcon-root': {
                                                    color: row.customerSegment === 'A' ? 'green' : 'red',
                                                },
                                            }}
                                        />
                                    </TableCell>
                                    <TableCell className="small-cells">
                                        <Checkbox
                                            disabled
                                            checked={row.occupationType === 'A'}
                                            icon={<span style={{ color: 'red', fontSize: '16px' }}>✖</span>}
                                            checkedIcon={<span style={{ color: 'green', fontSize: '16px' }}>✔</span>}
                                            sx={{
                                                color: row.occupationType === 'A' ? 'green' : 'red',
                                                '& .MuiSvgIcon-root': {
                                                    color: row.occupationType === 'A' ? 'green' : 'red',
                                                },
                                            }}
                                        />
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
                <br></br>
                <Box sx={{ display: 'flex', justifyContent: 'end', alignItems: 'end', }}>
                    <Button
                        variant="contained"
                        onClick={handleSubmit}
                    >
                        Submit
                    </Button>
                </Box>

                <Dialog open={openDialog} onClose={handleCloseDialog}>
                    <DialogTitle className="custom-dialog-title">Update Existing Mapping</DialogTitle>
                    <DialogContent>
                        <Typography className='confirmation-text'>
                            The data is  already exists. Would you like to update the existing mapping?
                        </Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseDialog} color="primary">Cancel</Button>
                        <Button onClick={handleConfirmDialog} color="primary">Confirm</Button>
                    </DialogActions>
                </Dialog>

            </Box>

            <Snackbar open={openSnackbar} autoHideDuration={6000} onClose={handleSnackbarClose} anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
                {successMessage ? (
                    <Alert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
                        {successMessage}
                    </Alert>
                ) : (
                    <Alert onClose={handleSnackbarClose} severity="error" sx={{ width: '100%' }}>
                        {errorMessage}
                    </Alert>
                )}
            </Snackbar>

        </Box>
    );
}

export default ConfigParameter;