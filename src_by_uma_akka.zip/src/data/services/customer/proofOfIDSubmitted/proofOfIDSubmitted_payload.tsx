export interface ProofOfIDSubmittedPayload {
    name: string;
    code:string;
    uid:string;
}