export interface CustomerRelatedPartyStatusPayload {
    name: string;
    code:string;
    uid:string;
}