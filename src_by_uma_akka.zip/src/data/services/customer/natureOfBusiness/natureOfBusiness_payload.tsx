export interface NatureOfBusinessPayload {
    name: string;
    code:string;
    uid:string;
}