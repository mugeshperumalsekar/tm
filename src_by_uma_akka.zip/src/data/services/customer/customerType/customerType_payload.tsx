export interface CustomerTypePayload {
    name: string;
    customercategory:string;
    uid:string;
}