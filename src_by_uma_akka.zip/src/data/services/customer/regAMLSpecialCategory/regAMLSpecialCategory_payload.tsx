
export interface RegAMLSpecialCategoryPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

