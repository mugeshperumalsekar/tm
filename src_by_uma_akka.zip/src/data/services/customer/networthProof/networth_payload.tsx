export interface NetworthPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

