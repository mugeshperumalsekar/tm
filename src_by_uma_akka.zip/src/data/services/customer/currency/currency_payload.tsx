export interface CurrencyPayload {
    name: string;
    code:string;
    uid:string;
}