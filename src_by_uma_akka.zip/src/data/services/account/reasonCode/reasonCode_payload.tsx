export interface ReasonCodePayload {
    name: string;
    code:string;
    uid:string;
}