export interface IsDefaultedPayload {
    name: string;
    code:string;
    uid:string;
}