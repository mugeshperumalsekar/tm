
export interface OriginalCurrencyPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

