export interface RelationsPayload {
    customer_id: number;
    firstName: string;
    lastName: string;
    contactPersonMobileNo: string;
    contactPersonMobileNo2: string;
    contactPersonEmailId1: string;
    contactPersonEmailId2: string;
    related_customer_id: string;
    related_first_name: string;
    related_last_name: string;
}