import React, { useState } from 'react';
import { Layout } from 'antd';
import Header from '../header/header';

import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';


const { Content } = Layout;

const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [collapsed, setCollapsed] = useState(true); // Start with sidebar collapsed
  const navigate = useNavigate();
  const location = useLocation();
  const userDetails = useSelector((state: any) => state.loginReducer);
  const loginDetails = userDetails.loginDetails;

  const roleId = loginDetails?.roleId;
  
  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  // Check if the user is an admin or super admin
  const isAdmin = roleId === 1 || roleId === 2;
  const isClient = roleId === 3;

  return (
    <Layout style={{ minHeight: '100vh' }}>

      {/* {isAdmin && <AppSidebar collapsed={collapsed} />} */}
      <Layout className="site-layout">
      <Header />
      {/* <div style={{ paddingTop: '25px', marginBottom:'10px' }}>
        <MenuBar />
      </div> */}

        <Content
          style={{
            // padding: 2,
            marginTop: 34, 
            // marginLeft: isAdmin ? (collapsed ? 80 : 200) : 0, 
            marginLeft: 10, 
            background: 'whitesmoke',
          }}
        >
          {children}
        </Content>

      </Layout>

    </Layout>
  );
};

export default AppLayout;
