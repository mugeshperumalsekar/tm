export interface CaseStatus {
    id: number;
    name: string;
    uid: number;
    euid: number;
};