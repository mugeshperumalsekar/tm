export interface GenderPayload {
    name: string;
    code:string;
    uid:string;
}