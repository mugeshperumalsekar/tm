export interface QualificationPayload {
    name: string;
    code:string;
    uid:string;
}