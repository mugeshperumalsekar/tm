export interface IUPartyTypePayload {
    iupartyName: string;
    code:string;
    uid:string;
}