export interface ProductSegmentPayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

