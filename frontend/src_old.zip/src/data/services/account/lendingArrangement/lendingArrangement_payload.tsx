export interface LendingArrangementPayload {
    name: string;
    code:string;
    uid:string;
}