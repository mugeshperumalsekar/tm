export interface PolicyTypePayload {
    name: string;
    code:string;
    uid:string;
}