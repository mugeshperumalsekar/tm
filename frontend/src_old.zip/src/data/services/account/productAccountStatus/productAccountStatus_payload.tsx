export interface ProductAccountStatusPayload {
    name: string;
    code:string;
    uid:string;
}