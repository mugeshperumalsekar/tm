export interface ScenariolistPayload {
    transactionType:string;
    scenarioListId:number;
    riskLevel:string;
    occupationType:string;
    segmentType:string;
    customerType:string;
    period:string;
    amount:number[];
    noOfTransaction:number[];
    percentageValue:number[];
    transaction_period_id:number;
  }