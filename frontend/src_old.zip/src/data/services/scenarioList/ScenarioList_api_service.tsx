import HttpClientWrapper from "../../api/http-client-wrapper";
import { ScenariolistPayload } from "./Scenariolist_payload";
class ScenarioListApiService {

    
  private httpClientWrapper: HttpClientWrapper;

  constructor() {
    this.httpClientWrapper = new HttpClientWrapper();
  }

 
getScenarioList = async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/scenario-lists/fetch');
        return response;
    } catch (error) {
        throw error;
    }
};
getTransactionType= async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/TransactionType');
        return response;
    } catch (error) {
        throw error;
    }
};
getTransactionPeriod= async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/transactionPeriods');
        return response;
    } catch (error) {
        throw error;
    }
};

getScenarioData = async (
    includeCustomerType: boolean, 
    includeCustomerRisk: boolean, 
    includeCustomerSegment: boolean, 
    includeOccupationType: boolean,  
    transactionTypeId: number | null
) => {
    // Map transaction type IDs to names
    const transactionTypeMapping: { [key: number]: string } = {
        1: "CASH",
        2: "NONCASH"
    };

    // Get the name based on the ID, default to empty string if null or invalid
    const transactionTypeName = transactionTypeId ? transactionTypeMapping[transactionTypeId] || '' : '';

    try {
        const response = await this.httpClientWrapper.get(
            `/api/v1/ThresholdMappingApiService?includeCustomerType=${includeCustomerType}&includeCustomerRisk=${includeCustomerRisk}&includeCustomerSegment=${includeCustomerSegment}&includeOccupationType=${includeOccupationType}&transactionType=${transactionTypeName}`
        );
        return response;
    } catch (error) {
        throw error;
    }
};

CreateScenarioList = async (payload: ScenariolistPayload) => {
    try {
        const response = await this.httpClientWrapper.post('/api/v1/ThresholdMappingApiService/saveThresholdMapping', payload);
        const data = response.data;
        return data;
    } catch (error) {
        console.error("FamilyCodeApiService FamilyCode() error:", error);
        throw error;
    }
};
getCustomerType = async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/CustomerSubType');
        return response;
    } catch (error) {
        throw error;
    }
};

getRiskLevel = async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/RegulatoryAMLRisk');
        return response;
    } catch (error) {
        throw error;
    }
};


getSegment = async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/Segment');
        return response;
    } catch (error) {
        throw error;
    }
};

getOccupationType = async () => {
    try {
        const response = await this.httpClientWrapper.get('/api/v1/OccupationType');
        return response;
    } catch (error) {
        throw error;
    }
};



}
export default ScenarioListApiService;