import axios, { AxiosInstance } from "axios";

class ApiConfig {

    // private baseURL = 'http://61.2.136.192:8090';
    // private baseURL = 'http://192.168.1.38:9001';
    // private baseURL = 'http://192.168.0.4:9001';
    // private baseURL = 'http://192.168.0.11:9001';
    private baseURL = 'http://192.168.0.16:9001';
    // private baseURL = 'http://192.168.1.35:9001';

    private apiBaseUrl: string;

    constructor() {
        this.apiBaseUrl = this.baseURL;
    }

    private getApiBaseURL = () => {
        return this.apiBaseUrl;
    }

    public getAxiosInstance = () => {
        return axios.create({
            baseURL: this.getApiBaseURL()
        });
    }

}

export default ApiConfig;