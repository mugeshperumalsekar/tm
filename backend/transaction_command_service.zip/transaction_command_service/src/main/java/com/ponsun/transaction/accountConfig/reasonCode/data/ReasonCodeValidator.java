package com.ponsun.transaction.accountConfig.reasonCode.data;


import com.ponsun.transaction.accountConfig.reasonCode.request.CreateReasonCodeRequest;
import com.ponsun.transaction.accountConfig.reasonCode.request.UpdateReasonCodeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ReasonCodeValidator {
    public void validateSaveReasonCode(final CreateReasonCodeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateReasonCode(final UpdateReasonCodeRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
