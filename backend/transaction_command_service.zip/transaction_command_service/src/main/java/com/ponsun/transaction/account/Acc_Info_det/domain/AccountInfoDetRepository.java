package com.ponsun.transaction.account.Acc_Info_det.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountInfoDetRepository extends JpaRepository<AccountInfoDet,Integer> {
    List<AccountInfoDet> findByStatus(Status string);

}
