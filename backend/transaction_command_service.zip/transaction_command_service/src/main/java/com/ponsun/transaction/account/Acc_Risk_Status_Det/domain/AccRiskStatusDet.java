package com.ponsun.transaction.account.Acc_Risk_Status_Det.domain;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.CreateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.UpdateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_risk_status_det")
public class AccRiskStatusDet extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "accountId", referencedColumnName = "id", nullable = false)
    private AccInfo accInfo;

    @Column(name = "customerId")
    private Integer customerId;

    @Column(name = "accountRisk" )
    private String accountRisk;

    @Column(name = "accountRiskEffectiveDate")
    private String accountRiskEffectiveDate;

    @Column(name = "accountRiskNextReviewDate")
    private String accountRiskNextReviewDate;

    @Column(name = "clientStatus")
    private String clientStatus;

    @Column(name = "accountNumber", columnDefinition = "TEXT")
    private String accountNumber;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;
    public static AccRiskStatusDet create(final CreateAccRiskStatusDetRequest request, AccInfo accInfo) {
        final AccRiskStatusDet accRiskStatusDet = new AccRiskStatusDet();
        accRiskStatusDet.setAccInfo(accInfo);
        accRiskStatusDet.setCustomerId(request.getCustomerId());
        accRiskStatusDet.setAccountRisk(request.getAccountRisk());
        accRiskStatusDet.setAccountRiskEffectiveDate(request.getAccountRiskEffectiveDate());
        accRiskStatusDet.setAccountRiskNextReviewDate(request.getAccountRiskNextReviewDate());
        accRiskStatusDet.setClientStatus(request.getClientStatus());
        accRiskStatusDet.setAccountNumber(request.getAccountNumber());
        accRiskStatusDet.setUid(request.getUid());
        accRiskStatusDet.setEuid(request.getEuid());
        accRiskStatusDet.setStatus(Status.ACTIVE);
        accRiskStatusDet.setCreatedAt(LocalDateTime.now());
        return accRiskStatusDet;
    }
    public void update(final UpdateAccRiskStatusDetRequest request) {
        this.setCustomerId(request.getCustomerId());
        this.setAccountRisk(request.getAccountRisk());
        this.setAccountRiskEffectiveDate(request.getAccountRiskEffectiveDate());
        this.setAccountRiskNextReviewDate(request.getAccountRiskNextReviewDate());
        this.setClientStatus(request.getClientStatus());
        this.setAccountNumber(request.getAccountNumber());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }

}
