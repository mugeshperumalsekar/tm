package com.ponsun.transaction.accountConfig.productAccountType.services;

import com.ponsun.transaction.accountConfig.productAccountType.requests.CreateProductAccountTypeRequest;
import com.ponsun.transaction.accountConfig.productAccountType.requests.UpdateProductAccountTypeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface ProductAccountTypeWriteService {
    Response createProductAccount(CreateProductAccountTypeRequest request);
    Response updateProductAccount(Integer id, UpdateProductAccountTypeRequest request);
    Response unblockProductAccount(Integer id);
    Response deactive(Integer id, Integer euid);

}

