package com.ponsun.transaction.account.Acc_transaction.requests;

import lombok.Data;

@Data
public class CreateAccTransactionRequest extends AbstractAccTransactionRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
