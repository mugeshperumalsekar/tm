package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests;

import lombok.Data;

@Data
public class CreatePermanentCKYCAddressTypeRequest extends AbstractPermanentCKYCAddressTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
