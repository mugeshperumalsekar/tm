package com.ponsun.transaction.account.Acc_Info_det.api;

import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDet;
import com.ponsun.transaction.account.Acc_Info_det.requests.CreateAccountInfoDetRequest;
import com.ponsun.transaction.account.Acc_Info_det.requests.UpdateAccountInfoDetRequest;
import com.ponsun.transaction.account.Acc_Info_det.services.AccountInfoDetReadService;
import com.ponsun.transaction.account.Acc_Info_det.services.AccountInfoDetWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccountInfoDet")
@Tag(name = "AccountInfoDetApiResources")
public class AccountInfoDetApiResources {
    private final AccountInfoDetWriteService writeService;
    private final AccountInfoDetReadService readService;

    @PostMapping("/CreateAccountInfoDetRequest")
    public Response createAccountInfoDet(@RequestBody CreateAccountInfoDetRequest request) {
        Response response = this.writeService.createAccountInfoDet(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccountInfoDet(@PathVariable Integer id, @RequestBody UpdateAccountInfoDetRequest request) {
        Response response = this.writeService.updateAccountInfoDet(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccountInfoDet fetchAccountInfoDetById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccountInfoDetById(id);
    }

    @GetMapping
    public List<AccountInfoDet> fetchAll() {
        return this.readService.fetchAllAccountInfoDet();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccountInfoDet(@PathVariable Integer id){
        Response response = this.writeService.unblockAccountInfoDet(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccountInfoDet> fetchActiveAccountInfoDet() {
        return readService.fetchActiveAccountInfoDet();
    }

    @GetMapping("DeActive")
    public List<AccountInfoDet> fetchDeActiveAccountInfoDet() {
        return readService.fetchDeActiveAccountInfoDet();
    }

}
