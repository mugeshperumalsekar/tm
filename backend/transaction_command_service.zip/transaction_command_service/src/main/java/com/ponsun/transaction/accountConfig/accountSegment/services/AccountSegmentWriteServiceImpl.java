package com.ponsun.transaction.accountConfig.accountSegment.services;

import com.ponsun.transaction.accountConfig.accountSegment.data.AccountSegmentValidator;
import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegment;
import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegmentRepository;
import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegmentWrapper;
import com.ponsun.transaction.accountConfig.accountSegment.requests.CreateAccountSegmentRequest;
import com.ponsun.transaction.accountConfig.accountSegment.requests.UpdateAccountSegmentRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountSegmentWriteServiceImpl implements AccountSegmentWriteService {
    private final AccountSegmentRepository repository;
    private final AccountSegmentWrapper wrapper;
    private final AccountSegmentValidator validator;

    @Override
    @Transactional
    public Response createAccountSegment(CreateAccountSegmentRequest request) {
        try {
            this.validator.validateSaveAccountSegment(request);
            final AccountSegment accountSegment = AccountSegment.create(request);
            this.repository.saveAndFlush(accountSegment);
            return Response.of(Long.valueOf(accountSegment.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response updateAccountSegment(Integer id, UpdateAccountSegmentRequest request) {
        try {
            this.validator.validateUpdateAccountSegment(request);
            final AccountSegment accountSegment = this.wrapper.findOneWithNotFoundDetection(id);
            accountSegment.update(request);
            this.repository.saveAndFlush(accountSegment);
            return Response.of(Long.valueOf(accountSegment.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccountSegment(Integer id) {
        try {
            final AccountSegment accountSegment = this.wrapper.findOneWithNotFoundDetection(id);
            accountSegment.setStatus(Status.ACTIVE);
            accountSegment.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accountSegment);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid){
        try{
            AccountSegment accountSegment = this.wrapper.findOneWithNotFoundDetection(id);
            accountSegment.setEuid(euid);
            accountSegment.setStatus(Status.DELETE);
            accountSegment.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accountSegment);
            return Response.of(Long.valueOf(accountSegment.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

}
