package com.ponsun.transaction.accountConfig.fundedType.request;

import lombok.Data;

@Data
public class UpdateFundedTypeRequest extends AbstractFundedTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
