package com.ponsun.transaction.accountConfig.policyType.rowmapper;

import com.ponsun.transaction.accountConfig.policyType.data.PolicyTypeData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Service
@Slf4j
@Data

public class PolicyTypeRowMapper implements RowMapper<PolicyTypeData> {
    private final String schema;
    public PolicyTypeRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM tm_config_PolicyType a ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("a.id as id ,");
        builder.append("a.name as  name ,");
        builder.append("a.code as  code ,");
        builder.append("a.uid as uid ,");
        builder.append("a.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public PolicyTypeData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final String name = rs.getString("name");
        final String code = rs.getString("code");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new PolicyTypeData(id,name,code,uid,euid);
    }
}

