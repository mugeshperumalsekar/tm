package com.ponsun.transaction.accountConfig.regAMLRisk.request;

public class UpdateRegAMLRiskRequest extends AbstractRegAMLRiskRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}


