package com.ponsun.transaction.accountConfig.lendingArrangement.data;


import com.ponsun.transaction.accountConfig.lendingArrangement.request.CreateLendingArrangementRequest;
import com.ponsun.transaction.accountConfig.lendingArrangement.request.UpdateLendingArrangementRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LendingArrangementValidator {
    public void validateSaveLendingArrangement(final CreateLendingArrangementRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateLendingArrangement(final UpdateLendingArrangementRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");


        }
    }
}
