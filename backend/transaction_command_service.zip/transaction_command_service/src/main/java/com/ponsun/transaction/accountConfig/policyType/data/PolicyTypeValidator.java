package com.ponsun.transaction.accountConfig.policyType.data;


import com.ponsun.transaction.accountConfig.policyType.request.CreatePolicyTypeRequest;
import com.ponsun.transaction.accountConfig.policyType.request.UpdatePolicyTypeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PolicyTypeValidator {
    public void validateSavePolicyType(final CreatePolicyTypeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdatePolicyType(final UpdatePolicyTypeRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
