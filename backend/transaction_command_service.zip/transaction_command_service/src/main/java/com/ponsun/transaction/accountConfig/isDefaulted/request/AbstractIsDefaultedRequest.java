package com.ponsun.transaction.accountConfig.isDefaulted.request;

import lombok.Data;

@Data
public class AbstractIsDefaultedRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
