package com.ponsun.transaction.accountConfig.lendingArrangement.services;

import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangement;

import java.util.List;

public interface LendingArrangementReadService {
    List<LendingArrangement> fetchAllLendingArrangement();

    LendingArrangement fetchLendingArrangementById(Integer id);

    List<LendingArrangement> fetchActiveLendingArrangement();

    List<LendingArrangement> fetchDeActiveLendingArrangement();
}
