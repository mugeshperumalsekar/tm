package com.ponsun.transaction.accountConfig.reasonCode.services;


import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCode;
import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCodeRepository;
import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCodeWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReasonCodeReadServiceImpl implements ReasonCodeReadService {
    private final ReasonCodeWrapper reasonCodeWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final ReasonCodeRepository reasonCodeRepository;

    @Override
    public ReasonCode fetchReasonCodeById(Integer id) {
        return this.reasonCodeRepository.findById(id).get();
    }

    @Override
    public List<ReasonCode> fetchActiveReasonCode() {
        return this.reasonCodeRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<ReasonCode> fetchDeActiveReasonCode() {
        return reasonCodeRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<ReasonCode> fetchAllReasonCode() {
        return this.reasonCodeRepository.findAll();
    }
}
