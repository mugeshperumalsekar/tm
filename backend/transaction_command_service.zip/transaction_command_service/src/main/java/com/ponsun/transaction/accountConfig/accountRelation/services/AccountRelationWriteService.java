package com.ponsun.transaction.accountConfig.accountRelation.services;

import com.ponsun.transaction.accountConfig.accountRelation.request.CreateAccountRelationRequest;
import com.ponsun.transaction.accountConfig.accountRelation.request.UpdateAccountRelationRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccountRelationWriteService {
    Response createAccountRelation(CreateAccountRelationRequest createAccountRelationRequest);

    Response updateAccountRelation(Integer id, UpdateAccountRelationRequest updateAccountRelationRequest);

    Response unblockAccountRelation(Integer id);

    Response deActivate(Integer id, Integer euid);
}
