package com.ponsun.transaction.accountConfig.regAMLRisk.services;


import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRisk;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRiskRepository;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRiskWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class RegAMLRiskReadServiceImpl implements RegAMLRiskReadService {
    private final RegAMLRiskWrapper regAMLRiskWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final RegAMLRiskRepository regAMLRiskRepository;

    @Override
    public RegAMLRisk fetchRegAMLRiskById(Integer id) {
        return this.regAMLRiskRepository.findById(id).get();
    }

    @Override
    public List<RegAMLRisk> fetchActiveRegAMLRisk() {
        return this.regAMLRiskRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<RegAMLRisk> fetchDeActiveRegAMLRisk() {
        return this.regAMLRiskRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<RegAMLRisk> fetchAllRegAMLRisk() {
        return this.regAMLRiskRepository.findAll();
    }
}
