package com.ponsun.transaction.accountConfig.fundedType.request;

import lombok.Data;

@Data
public class CreateFundedTypeRequest extends AbstractFundedTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
