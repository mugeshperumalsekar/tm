package com.ponsun.transaction.accountConfig.productAccountType.requests;

import lombok.Data;

@Data
public class AbstractProductAccountTypeRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
