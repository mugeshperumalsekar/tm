package com.ponsun.transaction.account.Acc_Pay_Details.domain;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.CreateAccPayDetailsRequest;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.UpdateAccPayDetailsRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_pay_details")
public class AccPayDetails extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "accountId", referencedColumnName = "id", nullable = false)
    private AccInfo accInfo;

    @Column(name = "amountofLastRepayment")
    private double amountofLastRepayment;

    @Column(name = "customerId")
    private Integer customerId;

    @Column(name = "amountoverdue")
    private double amountoverdue;

    @Column(name = "daysPastDue")
    private Integer daysPastDue;

    @Column(name = "otherChargesOutstanding")
    private double otherChargesOutstanding;

    @Column(name = "payTerm")
    private Integer payTerm;

    @Column(name = "tenureinMonths")
    private Integer tenureinMonths;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccPayDetails create(final CreateAccPayDetailsRequest request,AccInfo accInfo) {
        final AccPayDetails accPayDetails = new AccPayDetails();
        accPayDetails.setAccInfo(accInfo);
        accPayDetails.setAmountofLastRepayment(request.getAmountofLastRepayment());
        accPayDetails.setCustomerId(request.getCustomerId());
        accPayDetails.setAmountoverdue(request.getAmountoverdue());
        accPayDetails.setDaysPastDue(request.getDaysPastDue());
        accPayDetails.setOtherChargesOutstanding(request.getOtherChargesOutstanding());
        accPayDetails.setPayTerm(request.getPayTerm());
        accPayDetails.setTenureinMonths(request.getTenureinMonths());
        accPayDetails.setUid(request.getUid());
        accPayDetails.setEuid(request.getEuid());
        accPayDetails.setStatus(Status.ACTIVE);
        accPayDetails.setCreatedAt(LocalDateTime.now());
        return accPayDetails;
    }
    public void update(final UpdateAccPayDetailsRequest request) {
        this.setAmountofLastRepayment(request.getAmountofLastRepayment());
        this.setCustomerId(request.getCustomerId());
        this.setAmountoverdue(request.getAmountoverdue());
        this.setDaysPastDue(request.getDaysPastDue());
        this.setOtherChargesOutstanding(request.getOtherChargesOutstanding());
        this.setPayTerm(request.getPayTerm());
        this.setTenureinMonths(request.getTenureinMonths());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}
