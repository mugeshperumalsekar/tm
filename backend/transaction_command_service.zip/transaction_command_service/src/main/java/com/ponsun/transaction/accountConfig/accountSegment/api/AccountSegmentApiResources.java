package com.ponsun.transaction.accountConfig.accountSegment.api;
import com.ponsun.transaction.accountConfig.accountSegment.requests.CreateAccountSegmentRequest;
import com.ponsun.transaction.accountConfig.accountSegment.requests.UpdateAccountSegmentRequest;
import com.ponsun.transaction.accountConfig.accountSegment.services.AccountSegmentWriteService;
import com.ponsun.transaction.accountConfig.accountSegment.services.AccountSegmenttReadService;
import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegment;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccountSegment")
@Tag(name = "AccountSegmentApiResources")
public class AccountSegmentApiResources {
    private final AccountSegmentWriteService writeService;
    private final AccountSegmenttReadService readService;

    @PostMapping("/CreateAccountSegmentRequest")
    public Response createAccountSegment(@RequestBody CreateAccountSegmentRequest request) {
        Response response = this.writeService.createAccountSegment(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccountSegment(@PathVariable Integer id, @RequestBody UpdateAccountSegmentRequest request) {
        Response response = this.writeService.updateAccountSegment(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccountSegment fetchAccountSegmentById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccountSegmentById(id);
    }
    @GetMapping
    public List<AccountSegment> fetchAll() {
        return this.readService.fetchAllAccountSegment();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccountSegment(@PathVariable Integer id){
        Response response = this.writeService.unblockAccountSegment(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccountSegment> fetchActiveAccountSegment() {
        return readService.fetchActiveAccountSegment();
    }
    @GetMapping("DeActive")
    public List<AccountSegment> fetchDeAccountSegment() {
        return readService.fetchDeActiveAccountSegment();
    }
}
