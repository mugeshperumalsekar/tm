package com.ponsun.transaction.accountConfig.fundedType.services;

import com.ponsun.transaction.accountConfig.fundedType.request.UpdateFundedTypeRequest;
import com.ponsun.transaction.accountConfig.fundedType.request.CreateFundedTypeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface FundedTypeWriteService {
    Response createFundedType(CreateFundedTypeRequest createFundedTypeRequest);

    Response updateFundedType(Integer id, UpdateFundedTypeRequest updateFundedTypeRequest);

    Response unblockFundedType(Integer id);

    Response deActivate(Integer id, Integer euid);
}
