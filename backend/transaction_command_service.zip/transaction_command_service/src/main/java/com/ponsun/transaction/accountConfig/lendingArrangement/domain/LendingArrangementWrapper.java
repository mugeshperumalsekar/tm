package com.ponsun.transaction.accountConfig.lendingArrangement.domain;


import com.ponsun.transaction.accountConfig.lendingArrangement.request.AbstractLendingArrangementRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class LendingArrangementWrapper extends AbstractLendingArrangementRequest {
    private final LendingArrangementRepository lendingArrangementRepository;

    @Transactional
    public LendingArrangement findOneWithNotFoundDetection(final Integer id) {
        return this.lendingArrangementRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("LendingArrangement Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }

}

