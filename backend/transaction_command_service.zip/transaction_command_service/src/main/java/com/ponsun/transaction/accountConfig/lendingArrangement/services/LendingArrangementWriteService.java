package com.ponsun.transaction.accountConfig.lendingArrangement.services;

import com.ponsun.transaction.accountConfig.lendingArrangement.request.CreateLendingArrangementRequest;
import com.ponsun.transaction.accountConfig.lendingArrangement.request.UpdateLendingArrangementRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface LendingArrangementWriteService {
    Response createLendingArrangement(CreateLendingArrangementRequest createLendingArrangementRequest);

    Response updateLendingArrangement(Integer id, UpdateLendingArrangementRequest updateLendingArrangementRequest);

    Response unblockLendingArrangement(Integer id);

    Response deActivate(Integer id, Integer euid);
}
