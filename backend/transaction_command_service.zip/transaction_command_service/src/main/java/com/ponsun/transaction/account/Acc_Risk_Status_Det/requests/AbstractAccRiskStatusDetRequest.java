package com.ponsun.transaction.account.Acc_Risk_Status_Det.requests;

import lombok.Data;

@Data
public class AbstractAccRiskStatusDetRequest {
    private Integer id;
    private Integer accountId;
    private Integer customerId;
    private String accountRisk;
    private String accountRiskEffectiveDate;
    private String accountRiskNextReviewDate;
    private String clientStatus;
    private String accountNumber;
    private Integer uid;
    private Integer euid;
}
