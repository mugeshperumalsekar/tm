package com.ponsun.transaction.account.Acc_Pay_Details.requests;

import lombok.Data;

@Data
public class UpdateAccPayDetailsRequest extends AbstractAccPayDetailsRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
