package com.ponsun.transaction.accountConfig.transactionFrequency.services;

import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequency;

import java.util.List;

public interface TransactionFrequencyReadService {

    List<TransactionFrequency> fetchAllTransactionFrequency();

    TransactionFrequency fetchTransactionFrequencyById(Integer id);

    List<TransactionFrequency> fetchActiveTransactionFrequency();

    List<TransactionFrequency> fetchDeActiveTransactionFrequency();
}
