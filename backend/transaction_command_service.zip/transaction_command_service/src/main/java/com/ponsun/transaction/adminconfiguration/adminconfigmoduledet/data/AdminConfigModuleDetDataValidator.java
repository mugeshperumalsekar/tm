package com.ponsun.transaction.adminconfiguration.adminconfigmoduledet.data;

import com.ponsun.transaction.adminconfiguration.adminconfigmoduledet.request.CreateAdminConfigModuleDetRequest;
import com.ponsun.transaction.adminconfiguration.adminconfigmoduledet.request.UpdateAdminConfigModuleDetRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AdminConfigModuleDetDataValidator {
    public void validateSaveModuleDet(final CreateAdminConfigModuleDetRequest request) {
        if (request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("ModuleName parameter required");
        }
    }
    public void validateUpdateModuleDet(final UpdateAdminConfigModuleDetRequest request) {
        if (request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("ModuleName parameter required");
        }
    }
}