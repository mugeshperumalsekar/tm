package com.ponsun.transaction.accountConfig.modeOfAccount.domain;


import com.ponsun.transaction.accountConfig.modeOfAccount.request.AbstractModeOfAccountRequest;
import com.ponsun.transaction.customerConfig.tmConfigCountry.domain.TmConfigCountry;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ModeOfAccountWrapper extends AbstractModeOfAccountRequest {
    private final ModeOfAccountRepository modeOfAccountRepository;

    @Transactional
    public ModeOfAccount findOneWithNotFoundDetection(final Integer id) {
        return this.modeOfAccountRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("ModeOfAccount Not found " + id));
    }
    @Transactional
    public List<ModeOfAccount> findModeOfAccountByIds(final List<Integer> ids) {
        List<ModeOfAccount> modeOfAccounts = modeOfAccountRepository.findModeOfAccountByIds(ids);
        return modeOfAccounts;
    }

//    @Transactional
//    public List<ModeOfAccount> findModeOfAccountByIds(final List<Integer> ids) {
//        List<ModeOfAccount> modeOfAccounts = modeOfAccountRepository.findModeOfAccountByIds(ids);
//        if (modeOfAccounts == null || modeOfAccounts.isEmpty()) {
//            ModeOfAccount modeOfAccount = new ModeOfAccount();
//            modeOfAccount.setId(0);
//            modeOfAccounts = new ArrayList<>();
//            modeOfAccounts.add(modeOfAccount);
//        }
//        return modeOfAccounts;
//    }

    @Override
    public String toString() {
        return super.toString();
    }
}