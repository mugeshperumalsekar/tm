package com.ponsun.transaction.accountConfig.policyType.services;

import com.ponsun.transaction.accountConfig.policyType.data.PolicyTypeValidator;
import com.ponsun.transaction.accountConfig.policyType.domain.PolicyType;
import com.ponsun.transaction.accountConfig.policyType.domain.PolicyTypeRepository;
import com.ponsun.transaction.accountConfig.policyType.domain.PolicyTypeWrapper;
import com.ponsun.transaction.accountConfig.policyType.request.CreatePolicyTypeRequest;
import com.ponsun.transaction.accountConfig.policyType.request.UpdatePolicyTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class PolicyTypeWriteServiceImpl implements PolicyTypeWriteService {

    private final PolicyTypeRepository policyTypeRepository;
    private final PolicyTypeWrapper policyTypeWrapper;
    private final PolicyTypeValidator policyTypeValidator;

    @Override
    @Transactional
    public Response createPolicyType(CreatePolicyTypeRequest createPolicyTypeRequest) {
        try {
            this.policyTypeValidator.validateSavePolicyType(createPolicyTypeRequest);
            final PolicyType policyType = PolicyType.create(createPolicyTypeRequest);
            this.policyTypeRepository.saveAndFlush(policyType);
            return Response.of(Long.valueOf(policyType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updatePolicyType(Integer id, UpdatePolicyTypeRequest updatePolicyTypeRequest) {
        try {
            this.policyTypeValidator.validateUpdatePolicyType(updatePolicyTypeRequest);
            final PolicyType policyType = this.policyTypeWrapper.findOneWithNotFoundDetection(id);
            policyType.update(updatePolicyTypeRequest);
            this.policyTypeRepository.saveAndFlush(policyType);
            return Response.of(Long.valueOf(policyType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockPolicyType(Integer id) {
        try {
            final PolicyType policyType = this.policyTypeWrapper.findOneWithNotFoundDetection(id);
            policyType.setStatus(Status.ACTIVE);
            policyType.setUpdatedAt(LocalDateTime.now());
            this.policyTypeRepository.saveAndFlush(policyType);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            PolicyType policyType = this.policyTypeWrapper.findOneWithNotFoundDetection(id);
            policyType.setEuid(euid);
            policyType.setStatus(Status.DELETE);
            policyType.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(policyType.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
