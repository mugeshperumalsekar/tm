package com.ponsun.transaction.accountConfig.isDefaulted.services;

import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaulted;

import java.util.List;

public interface IsDefaultedReadService {
    List<IsDefaulted> fetchAllIsDefaulted();

    IsDefaulted fetchIsDefaultedById(Integer id);

    List<IsDefaulted> fetchActiveIsDefaulted();

    List<IsDefaulted> fetchDeActiveIsDefaulted();
}
