package com.ponsun.transaction.accountConfig.productAccountType.api;
import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountType;
import com.ponsun.transaction.accountConfig.productAccountType.requests.CreateProductAccountTypeRequest;
import com.ponsun.transaction.accountConfig.productAccountType.requests.UpdateProductAccountTypeRequest;
import com.ponsun.transaction.accountConfig.productAccountType.services.ProductAccountTypeReadService;
import com.ponsun.transaction.accountConfig.productAccountType.services.ProductAccountTypeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/ProductAccountType")
@Tag(name = "ProductAccountTypeApiResources")
public class ProductAccountTypeApiResources {
    private final ProductAccountTypeWriteService writeService;
    private final ProductAccountTypeReadService readService;

    @PostMapping("/CreateProductAccountRequest")
    public Response createProductAccount(@RequestBody CreateProductAccountTypeRequest request) {
        Response response = this.writeService.createProductAccount(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateProductAccount(@PathVariable Integer id, @RequestBody UpdateProductAccountTypeRequest request) {
        Response response = this.writeService.updateProductAccount(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public ProductAccountType fetchProductAccountById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchProductAccountById(id);
    }
    @GetMapping
    public List<ProductAccountType> fetchAll() {
        return this.readService.fetchAllProductAccount();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockProductAccount(@PathVariable Integer id){
        Response response = this.writeService.unblockProductAccount(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }
    @GetMapping("active")
    public List<ProductAccountType> fetchActiveProductAccountType() {
        return readService.fetchActiveProductAccountType();
    }
    @GetMapping("DeActive")
    public List<ProductAccountType> fetchDeProductAccountType() {
        return readService.fetchDeActiveProductAccountType();
    }
}
