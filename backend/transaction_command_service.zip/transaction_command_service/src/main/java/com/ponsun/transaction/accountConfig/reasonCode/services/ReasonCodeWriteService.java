package com.ponsun.transaction.accountConfig.reasonCode.services;

import com.ponsun.transaction.accountConfig.reasonCode.request.CreateReasonCodeRequest;
import com.ponsun.transaction.accountConfig.reasonCode.request.UpdateReasonCodeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface ReasonCodeWriteService {
    Response createReasonCode(CreateReasonCodeRequest createReasonCodeRequest);

    Response updateReasonCode(Integer id, UpdateReasonCodeRequest updateReasonCodeRequest);

    Response unblockReasonCode(Integer id);

    Response deActivate(Integer id, Integer euid);
}
