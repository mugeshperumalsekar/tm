package com.ponsun.transaction.account.Acc_Info.domain;

import com.ponsun.transaction.account.Acc_Info.requests.CreateAccInfoRequest;
import com.ponsun.transaction.account.Acc_Info.requests.UpdateAccInfoRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_info")
public class AccInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "customerId")
    private Integer customerId;

    @Column(name = "productAccOpeningDate")
    private String productAccOpeningDate;

    @Column(name = "productAccountNumber")
    private String productAccountNumber;

    @Column(name = "productAccountReasonCodeDescription", columnDefinition = "TEXT")
    private String productAccountReasonCodeDescription;

    @Column(name = "productAccountStatus")
    private String productAccountStatus;

    @Column(name = "productAccountStatusDescription", columnDefinition = "TEXT")
    private String productAccountStatusDescription;

    @Column(name = "productAccountStatusEffectiveDate")
    private String productAccountStatusEffectiveDate;

    @Column(name = "productAccountStatusReasonCode", columnDefinition = "TEXT")
    private String productAccountStatusReasonCode;

    @Column(name = "productAccountType")
    private String productAccountType;

    @Column(name = "productApplicationDate")
    private String productApplicationDate;

    @Column(name = "productSegmentId")
    private Integer productSegmentId;

    @Column(name = "rmCode")
    private String rmCode;

    @Column(name = "rmType")
    private String rmType;

    @Column(name = "tags", columnDefinition = "TEXT")
    private String tags;

    @Column(name = "underwritingDate")
    private String underwritingDate;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccInfo create(final CreateAccInfoRequest request) {
        final AccInfo accInfo = new AccInfo();
        accInfo.setCustomerId(request.getCustomerId());
        accInfo.setProductAccOpeningDate(request.getProductAccOpeningDate());
        accInfo.setProductAccountNumber(request.getProductAccountNumber());
        accInfo.setProductAccountReasonCodeDescription(request.getProductAccountReasonCodeDescription());
        accInfo.setProductAccountStatus(request.getProductAccountStatus());
        accInfo.setProductAccountStatusDescription(request.getProductAccountStatusDescription());
        accInfo.setProductAccountStatusEffectiveDate(request.getProductAccountStatusEffectiveDate());
        accInfo.setProductAccountStatusReasonCode(request.getProductAccountStatusReasonCode());
        accInfo.setProductAccountType(request.getProductAccountType());
        accInfo.setProductApplicationDate(request.getProductApplicationDate());
        accInfo.setProductSegmentId(request.getProductSegmentId());
        accInfo.setRmCode(request.getRmCode());
        accInfo.setRmType(request.getRmType());
        accInfo.setTags(request.getTags());
        accInfo.setUid(request.getUid());
        accInfo.setEuid(request.getEuid());
        accInfo.setUnderwritingDate(request.getUnderwritingDate());
        accInfo.setStatus(Status.ACTIVE);
        accInfo.setCreatedAt(LocalDateTime.now());
        return accInfo;
    }
        public void update(final UpdateAccInfoRequest request) {
            this.setCustomerId(request.getCustomerId());
            this.setProductAccOpeningDate(request.getProductAccOpeningDate());
            this.setProductAccountNumber(request.getProductAccountNumber());
            this.setProductAccountReasonCodeDescription(request.getProductAccountReasonCodeDescription());
            this.setProductAccountStatus(request.getProductAccountStatus());
            this.setProductAccountStatusDescription(request.getProductAccountStatusDescription());
            this.setProductAccountStatusEffectiveDate(request.getProductAccountStatusEffectiveDate());
            this.setProductAccountStatusReasonCode(request.getProductAccountStatusReasonCode());
            this.setProductAccountType(request.getProductAccountType());
            this.setProductApplicationDate(request.getProductApplicationDate());
            this.setProductSegmentId(request.getProductSegmentId());
            this.setRmCode(request.getRmCode());
            this.setRmType(request.getRmType());
            this.setTags(request.getTags());
            this.setUid(request.getUid());
            this.setEuid(request.getEuid());
            this.setStatus(Status.ACTIVE);
            this.setUpdatedAt(LocalDateTime.now());
        }
}
