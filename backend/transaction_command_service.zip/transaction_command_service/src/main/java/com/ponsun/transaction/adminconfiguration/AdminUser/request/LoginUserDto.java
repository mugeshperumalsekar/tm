package com.ponsun.transaction.adminconfiguration.AdminUser.request;

import lombok.Data;

@Data
public class LoginUserDto {

    private String email;

    private String password;

}
