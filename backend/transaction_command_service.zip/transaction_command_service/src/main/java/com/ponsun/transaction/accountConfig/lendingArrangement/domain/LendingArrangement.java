package com.ponsun.transaction.accountConfig.lendingArrangement.domain;

import com.ponsun.transaction.accountConfig.lendingArrangement.request.UpdateLendingArrangementRequest;
import com.ponsun.transaction.accountConfig.lendingArrangement.request.CreateLendingArrangementRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_LendingArrangement")
public class LendingArrangement extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static LendingArrangement create(final CreateLendingArrangementRequest createLendingArrangementRequest){
        final LendingArrangement lendingArrangement = new LendingArrangement();
        lendingArrangement.setName(createLendingArrangementRequest.getName());
        lendingArrangement.setCode(createLendingArrangementRequest.getCode());
        lendingArrangement.setUid(createLendingArrangementRequest.getUid());
        lendingArrangement.setStatus(Status.ACTIVE);
        lendingArrangement.setCreatedAt(LocalDateTime.now());
        return lendingArrangement;
    }
    public void update(final UpdateLendingArrangementRequest updateLendingArrangementRequest){
        this.setName(updateLendingArrangementRequest.getName());
        this.setCode(updateLendingArrangementRequest.getCode());
        this.setEuid(updateLendingArrangementRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

