package com.ponsun.transaction.account.Acc_Address_Info.services;
import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfo;

import java.util.List;

public interface AccAddressInfoReadService {

    AccAddressInfo fetchAccAddressInfoById(Integer id);

    List<AccAddressInfo> fetchAllAccAddressInfo();

    List<AccAddressInfo> fetchActiveAccAddressInfo();
    List<AccAddressInfo> fetchDeActiveAccAddressInfo();
}
