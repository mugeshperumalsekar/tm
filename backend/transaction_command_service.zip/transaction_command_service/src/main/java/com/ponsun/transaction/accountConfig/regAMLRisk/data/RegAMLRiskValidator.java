package com.ponsun.transaction.accountConfig.regAMLRisk.data;


import com.ponsun.transaction.accountConfig.regAMLRisk.request.CreateRegAMLRiskRequest;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.UpdateRegAMLRiskRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RegAMLRiskValidator {
    public void validateSaveRegAMLRisk(final CreateRegAMLRiskRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateRegAMLRisk(final UpdateRegAMLRiskRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");


        }
    }
}
