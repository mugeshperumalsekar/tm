package com.ponsun.transaction.accountConfig.modeOfAccount.api;


import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccount;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.CreateModeOfAccountRequest;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.UpdateModeOfAccountRequest;
import com.ponsun.transaction.accountConfig.modeOfAccount.services.ModeOfAccountReadService;
import com.ponsun.transaction.accountConfig.modeOfAccount.services.ModeOfAccountWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/ModeOfAccount")
@Tag(name = "ModeOfAccountApiResource")
public class ModeOfAccountApiResources {
    private final ModeOfAccountWriteService modeOfAccountWriteService;
    private final ModeOfAccountReadService modeOfAccountReadService;

    @PostMapping("/CreateModeOfAccountRequest")
    public Response saveModeOfAccount(@RequestBody CreateModeOfAccountRequest createModeOfAccountRequest) {
        log.debug("START saveModeOfAccount request body {}",createModeOfAccountRequest);
        Response response = this.modeOfAccountWriteService.createModeOfAccount(createModeOfAccountRequest);
        log.debug("START saveModeOfAccount response",response);
        return response;
    }

    @GetMapping
    public List<ModeOfAccount> fetchAll() {
        return this.modeOfAccountReadService.fetchAllModeOfAccount();
    }

    @GetMapping("/{id}")
    public ModeOfAccount fetchModeOfAccountById(@PathVariable(name = "id") Integer id) {
        return this.modeOfAccountReadService.fetchModeOfAccountById(id);
    }

    @PutMapping("/{id}")
    public Response updateModeOfAccount(@PathVariable Integer id, @RequestBody UpdateModeOfAccountRequest updateModeOfAccountRequest) {
        log.debug("START updateModeOfAccount request body {}",updateModeOfAccountRequest);
        Response response = this.modeOfAccountWriteService.updateModeOfAccount(id, updateModeOfAccountRequest);
        log.debug("START updateModeOfAccount response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockModeOfAccount(@PathVariable Integer id){
        Response response = this.modeOfAccountWriteService.unblockModeOfAccount(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.modeOfAccountWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<ModeOfAccount> fetchActiveType() {
        return modeOfAccountReadService.fetchActiveType();
    }
    @GetMapping("DeActive")
    public List<ModeOfAccount> fetchDeType() {
        return modeOfAccountReadService.fetchDeActiveType();
    }
}

