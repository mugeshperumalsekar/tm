package com.ponsun.transaction.account.Acc_Address_Info.services;

import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfo;
import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfoRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccAddressInfoReadServiceImpl implements AccAddressInfoReadService {
    private final AccAddressInfoRepository repository;

    @Override
    @Transactional
    public AccAddressInfo fetchAccAddressInfoById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccAddressInfo> fetchAllAccAddressInfo() {
        return this.repository.findAll();
    }

    @Override
    public List<AccAddressInfo> fetchActiveAccAddressInfo() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccAddressInfo> fetchDeActiveAccAddressInfo() {
        return repository.findByStatus(Status.DELETE);
    }
}
