package com.ponsun.transaction.account.Acc_transaction.services;
import com.ponsun.transaction.account.Acc_transaction.requests.CreateAccTransactionRequest;
import com.ponsun.transaction.account.Acc_transaction.requests.UpdateAccTransactionRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccTransactionWriteService {

    Response createAccTransaction(CreateAccTransactionRequest request);
    Response updateAccTransaction(Integer id, UpdateAccTransactionRequest request);
    void updateCalulatedThresholdAccTransaction(Integer id);
    Response unblockAccTransaction(Integer id);
    Response deactive(Integer id, Integer euid);
}
