package com.ponsun.transaction.accountDetails.services;

import com.ponsun.transaction.accountDetails.data.AccountDetailsDataValidator;
import com.ponsun.transaction.accountDetails.domain.*;
import com.ponsun.transaction.accountDetails.request.CreateAccountDetailsRequest;
import com.ponsun.transaction.accountDetails.request.UpdateAccountDetailsRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountDetailsWritePlatformServiceImpl implements AccountDetailsWritePlatformService {

    private final AccountDetailsRepository accountDetailsRepository;
    //private final AlertGenerationRepository alertGenerationRepository;
    private final AccountDetailsRepositoryWrapper accountDetailsRepositoryWrapper;
    private final AccountDetailsDataValidator accountDetailsDataValidator;

    @Override
    @Transactional
    public Response createAccountDetails(CreateAccountDetailsRequest createAccountDetailsRequest) {
        try {
            this.accountDetailsDataValidator.validateSaveAccountDetailsData(createAccountDetailsRequest);
            final AccountDetails accountDetails = AccountDetails.create(createAccountDetailsRequest);
            this.accountDetailsRepository.saveAndFlush(accountDetails);
            return Response.of(accountDetails.getId());
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccountDetails(Integer id, UpdateAccountDetailsRequest updateAccountDetailsRequest) {
        try {
            this.accountDetailsDataValidator.validateUpdateAccountDetailsData(updateAccountDetailsRequest);
            final AccountDetails accountDetails = this.accountDetailsRepositoryWrapper.findOneWithNotFoundDetection(id);
            accountDetails.update(updateAccountDetailsRequest);
            this.accountDetailsRepository.saveAndFlush(accountDetails);
            return Response.of(accountDetails.getId());
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response blockAccountDetails(Integer id) {
        try {
            final AccountDetails accountDetails = this.accountDetailsRepositoryWrapper.findOneWithNotFoundDetection(id);
            accountDetails.setStatus(Status.DELETE);
            accountDetails.setUpdatedAt(LocalDateTime.now());
            this.accountDetailsRepository.saveAndFlush(accountDetails);
            return Response.of(id);
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccountDetails(Integer id) {
        try {
            final AccountDetails accountDetails = this.accountDetailsRepositoryWrapper.findOneWithNotFoundDetection(id);
            accountDetails.setStatus(Status.ACTIVE);
            accountDetails.setUpdatedAt(LocalDateTime.now());
            this.accountDetailsRepository.saveAndFlush(accountDetails);
            return Response.of(id);
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
