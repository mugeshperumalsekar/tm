package com.ponsun.transaction.accountConfig.clientStatus.api;



import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatus;
import com.ponsun.transaction.accountConfig.clientStatus.request.CreateClientStatusRequest;
import com.ponsun.transaction.accountConfig.clientStatus.request.UpdateClientStatusRequest;
import com.ponsun.transaction.accountConfig.clientStatus.services.ClientStatusReadService;
import com.ponsun.transaction.accountConfig.clientStatus.services.ClientStatusWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/ClientStatus")
@Tag(name = "ClientStatusApiResource")
public class ClientStatusApiResources {
    private final ClientStatusWriteService clientStatusWriteService;
    private final ClientStatusReadService clientStatusReadService;

    @PostMapping("/CreateClientStatusRequest")
    public Response saveClientStatus(@RequestBody CreateClientStatusRequest createClientStatusRequest) {
        log.debug("START saveClientStatus request body {}",createClientStatusRequest);
        Response response = this.clientStatusWriteService.createClientStatus(createClientStatusRequest);
        log.debug("START saveClientStatus response",response);
        return response;
    }

    @GetMapping
    public List<ClientStatus> fetchAll() {
        return this.clientStatusReadService.fetchAllClientStatus();
    }

    @GetMapping("/{id}")
    public ClientStatus fetchClientStatusById(@PathVariable(name = "id") Integer id) {
        return this.clientStatusReadService.fetchClientStatusById(id);
    }

    @PutMapping("/{id}")
    public Response updateClientStatus(@PathVariable Integer id, @RequestBody UpdateClientStatusRequest updateClientStatusRequest) {
        log.debug("START updateClientStatus request body {}",updateClientStatusRequest);
        Response response = this.clientStatusWriteService.updateClientStatus(id, updateClientStatusRequest);
        log.debug("START updateClientStatus response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockClientStatus(@PathVariable Integer id){
        Response response = this.clientStatusWriteService.unblockClientStatus(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.clientStatusWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<ClientStatus> fetchActiveClientStatus() {
        return clientStatusReadService.fetchActiveClientStatus();
    }
    @GetMapping("DeActive")
    public List<ClientStatus> fetchDeClientStatus() {
        return clientStatusReadService.fetchDeActiveClientStatus();
    }

}

