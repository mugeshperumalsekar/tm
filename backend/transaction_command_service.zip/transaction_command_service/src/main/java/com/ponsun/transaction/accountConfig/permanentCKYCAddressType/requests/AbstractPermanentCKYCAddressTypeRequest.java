package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests;

import lombok.Data;

@Data
public class AbstractPermanentCKYCAddressTypeRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
