package com.ponsun.transaction.accountConfig.accountSegment.services;

import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegment;
import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegmentRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@RequiredArgsConstructor
@Slf4j
public class AccountSegmenttReadServiceImpl implements AccountSegmenttReadService {
    private final AccountSegmentRepository repository;

    @Override
    @Transactional
    public AccountSegment fetchAccountSegmentById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccountSegment> fetchAllAccountSegment() {
        return this.repository.findAll();
    }

    @Override
    public List<AccountSegment> fetchActiveAccountSegment() {
        return this.repository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<AccountSegment> fetchDeActiveAccountSegment() {
        return this.repository.findByStatus(Status.DELETE);
    }
}
