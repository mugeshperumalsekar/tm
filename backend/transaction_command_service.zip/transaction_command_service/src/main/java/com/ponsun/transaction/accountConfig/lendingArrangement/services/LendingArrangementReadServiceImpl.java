package com.ponsun.transaction.accountConfig.lendingArrangement.services;


import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangement;
import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangementRepository;
import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangementWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class LendingArrangementReadServiceImpl implements LendingArrangementReadService {
    private final LendingArrangementWrapper lendingArrangementWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final LendingArrangementRepository lendingArrangementRepository;

    @Override
    public LendingArrangement fetchLendingArrangementById(Integer id) {
        return this.lendingArrangementRepository.findById(id).get();
    }

    @Override
    public List<LendingArrangement> fetchActiveLendingArrangement() {
        return this.lendingArrangementRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<LendingArrangement> fetchDeActiveLendingArrangement() {
        return this.lendingArrangementRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<LendingArrangement> fetchAllLendingArrangement() {
        return this.lendingArrangementRepository.findAll();
    }
}
