package com.ponsun.transaction.accountConfig.natureOfCredit.request;

import lombok.Data;

@Data
public class UpdateNatureOfCreditRequest extends AbstractNatureOfCreditRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

