package com.ponsun.transaction.accountConfig.fundedType.services;

import com.ponsun.transaction.accountConfig.fundedType.request.UpdateFundedTypeRequest;
import com.ponsun.transaction.accountConfig.fundedType.data.FundedTypeValidator;
import com.ponsun.transaction.accountConfig.fundedType.domain.FundedType;
import com.ponsun.transaction.accountConfig.fundedType.domain.FundedTypeRepository;
import com.ponsun.transaction.accountConfig.fundedType.domain.FundedTypeWrapper;
import com.ponsun.transaction.accountConfig.fundedType.request.CreateFundedTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class FundedTypeWriteServiceImpl implements FundedTypeWriteService {

    private final FundedTypeRepository fundedTypeRepository;
    private final FundedTypeWrapper fundedTypeWrapper;
    private final FundedTypeValidator fundedTypeValidator;

    @Override
    @Transactional
    public Response createFundedType(CreateFundedTypeRequest createFundedTypeRequest) {
        try {
            this.fundedTypeValidator.validateSaveFundedType(createFundedTypeRequest);
            final FundedType fundedType = FundedType.create(createFundedTypeRequest);
            this.fundedTypeRepository.saveAndFlush(fundedType);
            return Response.of(Long.valueOf(fundedType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateFundedType(Integer id, UpdateFundedTypeRequest updateFundedTypeRequest) {
        try {
            this.fundedTypeValidator.validateUpdateFundedType(updateFundedTypeRequest);
            final FundedType fundedType = this.fundedTypeWrapper.findOneWithNotFoundDetection(id);
            fundedType.update(updateFundedTypeRequest);
            this.fundedTypeRepository.saveAndFlush(fundedType);
            return Response.of(Long.valueOf(fundedType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockFundedType(Integer id) {
        try {
            final FundedType fundedType = this.fundedTypeWrapper.findOneWithNotFoundDetection(id);
            fundedType.setStatus(Status.ACTIVE);
            fundedType.setUpdatedAt(LocalDateTime.now());
            this.fundedTypeRepository.saveAndFlush(fundedType);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            FundedType fundedType = this.fundedTypeWrapper.findOneWithNotFoundDetection(id);
            fundedType.setEuid(euid);
            fundedType.setStatus(Status.DELETE);
            fundedType.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(fundedType.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
