package com.ponsun.transaction.accountConfig.fundedType.services;

import com.ponsun.transaction.accountConfig.fundedType.domain.FundedType;
import com.ponsun.transaction.accountConfig.fundedType.domain.FundedTypeRepository;
import com.ponsun.transaction.accountConfig.fundedType.domain.FundedTypeWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class FundedTypeReadServiceImpl implements FundedTypeReadService {
    private final FundedTypeWrapper fundedTypeWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final FundedTypeRepository fundedTypeRepository;

    @Override
    public FundedType fetchFundedTypeById(Integer id) {
        return this.fundedTypeRepository.findById(id).get();
    }

    @Override
    public List<FundedType> fetchActiveFundedType() {
        return this.fundedTypeRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<FundedType> fetchDeActiveFundedType() {
        return this.fundedTypeRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<FundedType> fetchAllFundedType() {
        return this.fundedTypeRepository.findAll();
    }
}
