package com.ponsun.transaction.account.Acc_Address_Info.requests;

import lombok.Data;

@Data
public class AbstractAccAddressInfoRequest {
    private Integer id;
    private Integer customerId;
    private String correspondenceAddressCity;
    private String correspondenceAddressCountry;
    private String correspondenceAddressDistrict;
    private String correspondenceAddressLine1;
    private String correspondenceAddressLine2;
    private String correspondenceAddressLine3;
    private String correspondenceAddressPinCode;
    private String correspondenceAddressProof;
    private String correspondenceAddressState;
    private String permanentAddressCity;
    private String permanentAddressCountry;
    private String permanentAddressDistrict;
    private String permanentAddressLine1;
    private String permanentAddressLine2;
    private String permanentAddressLine3;
    private String permanentAddressPinCode;
    private String permanentAddressProof;
    private String permanentAddressState;
    private String permanentCKYCAddressType;
    private Integer accountId;
    private Integer uid;
    private Integer euid;
}
