package com.ponsun.transaction.accountConfig.instrumentType.requests;

import lombok.Data;

@Data
public class CreateInstrumentTypeRequest extends AbstractInstrumentTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
