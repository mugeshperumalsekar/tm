package com.ponsun.transaction.accountConfig.policyType.request;


public class CreatePolicyTypeRequest extends AbstractPolicyTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}