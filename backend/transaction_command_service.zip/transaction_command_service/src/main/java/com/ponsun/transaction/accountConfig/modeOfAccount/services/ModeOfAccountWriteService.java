package com.ponsun.transaction.accountConfig.modeOfAccount.services;

import com.ponsun.transaction.accountConfig.modeOfAccount.request.CreateModeOfAccountRequest;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.UpdateModeOfAccountRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface ModeOfAccountWriteService {
    Response createModeOfAccount(CreateModeOfAccountRequest createModeOfAccountRequest);

    Response updateModeOfAccount(Integer id, UpdateModeOfAccountRequest updateModeOfAccountRequest);

    Response unblockModeOfAccount(Integer id);

    Response deActivate(Integer id, Integer euid);
}
