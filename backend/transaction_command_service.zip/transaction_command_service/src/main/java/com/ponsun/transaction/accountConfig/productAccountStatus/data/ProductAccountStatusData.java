package com.ponsun.transaction.accountConfig.productAccountStatus.data;
import lombok.Data;
@Data
public class ProductAccountStatusData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public ProductAccountStatusData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static ProductAccountStatusData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new ProductAccountStatusData(id,name,code,uid,euid);
    }
}

