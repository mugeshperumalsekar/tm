package com.ponsun.transaction.accountConfig.fundedType.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FundedTypeRepository extends JpaRepository<FundedType, Integer> {
    Optional<FundedType> findById(Integer id);
    List<FundedType> findByStatus (Status string);

}