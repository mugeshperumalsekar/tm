package com.ponsun.transaction.accountConfig.insurancePurpose.services;

import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurpose;
import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurposeRepository;
import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurposeWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class InsurancePurposeReadServiceImpl implements InsurancePurposeReadService {
    private final InsurancePurposeWrapper insurancePurposeWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final InsurancePurposeRepository insurancePurposeRepository;

    @Override
    public InsurancePurpose fetchInsurancePurposeById(Integer id) {
        return this.insurancePurposeRepository.findById(id).get();
    }

    @Override
    public List<InsurancePurpose> fetchActiveInsurancePurpose() {
        return this.insurancePurposeRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<InsurancePurpose> fetchDeActiveInsurancePurpose() {
        return this.insurancePurposeRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<InsurancePurpose> fetchAllInsurancePurpose() {
        return this.insurancePurposeRepository.findAll();
    }
}
