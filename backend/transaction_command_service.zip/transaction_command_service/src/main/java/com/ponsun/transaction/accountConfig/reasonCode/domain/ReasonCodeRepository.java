package com.ponsun.transaction.accountConfig.reasonCode.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ReasonCodeRepository extends JpaRepository<ReasonCode, Integer> {
    Optional<ReasonCode> findById(Integer id);
    List<ReasonCode> findByStatus(Status string);

}