package com.ponsun.transaction.accountConfig.isDefaulted.api;



import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaulted;
import com.ponsun.transaction.accountConfig.isDefaulted.request.CreateIsDefaultedRequest;
import com.ponsun.transaction.accountConfig.isDefaulted.request.UpdateIsDefaultedRequest;
import com.ponsun.transaction.accountConfig.isDefaulted.services.IsDefaultedReadService;
import com.ponsun.transaction.accountConfig.isDefaulted.services.IsDefaultedWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/IsDefaulted")
@Tag(name = "IsDefaultedApiResource")
public class IsDefaultedApiResources {
    private final IsDefaultedWriteService isDefaultedWriteService;
    private final IsDefaultedReadService isDefaultedReadService;

    @PostMapping("/CreateIsDefaultedRequest")
    public Response saveIsDefaulted(@RequestBody CreateIsDefaultedRequest createIsDefaultedRequest) {
        log.debug("START saveIsDefaulted request body {}",createIsDefaultedRequest);
        Response response = this.isDefaultedWriteService.createIsDefaulted(createIsDefaultedRequest);
        log.debug("START saveIsDefaulted response",response);
        return response;
    }

    @GetMapping
    public List<IsDefaulted> fetchAll() {
        return this.isDefaultedReadService.fetchAllIsDefaulted();
    }

    @GetMapping("/{id}")
    public IsDefaulted fetchIsDefaultedById(@PathVariable(name = "id") Integer id) {
        return this.isDefaultedReadService.fetchIsDefaultedById(id);
    }

    @PutMapping("/{id}")
    public Response updateIsDefaulted(@PathVariable Integer id, @RequestBody UpdateIsDefaultedRequest updateIsDefaultedRequest) {
        log.debug("START updateIsDefaulted request body {}",updateIsDefaultedRequest);
        Response response = this.isDefaultedWriteService.updateIsDefaulted(id, updateIsDefaultedRequest);
        log.debug("START updateIsDefaulted response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockIsDefaulted(@PathVariable Integer id){
        Response response = this.isDefaultedWriteService.unblockIsDefaulted(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.isDefaultedWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<IsDefaulted> fetchActiveIsDefaulted() {
        return isDefaultedReadService.fetchActiveIsDefaulted();
    }
    @GetMapping("DeActive")
    public List<IsDefaulted> fetchDeIsDefaulted() {
        return isDefaultedReadService.fetchDeActiveIsDefaulted();
    }

}

