package com.ponsun.transaction.account.Acc_Address_Info.api;

import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfo;
import com.ponsun.transaction.account.Acc_Address_Info.requests.CreateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Address_Info.requests.UpdateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Address_Info.services.AccAddressInfoReadService;
import com.ponsun.transaction.account.Acc_Address_Info.services.AccAddressInfoWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccAddressInfo")
@Tag(name = "AccAddressInfoApiResources")
public class AccAddressInfoApiResources {
    private final AccAddressInfoWriteService writeService;
    private final AccAddressInfoReadService readService;

    @PostMapping("/CreateAccAddressInfoRequest")
    public Response createAccAddressInfo(@RequestBody CreateAccAddressInfoRequest request) {
        Response response = this.writeService.createAccAddressInfo(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccAddressInfo(@PathVariable Integer id, @RequestBody UpdateAccAddressInfoRequest request) {
        Response response = this.writeService.updateAccAddressInfo(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccAddressInfo fetchAccAddressInfoById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccAddressInfoById(id);
    }
    @GetMapping
    public List<AccAddressInfo> fetchAll() {
        return this.readService.fetchAllAccAddressInfo();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccAddressInfo(@PathVariable Integer id){
        Response response = this.writeService.unblockAccAddressInfo(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }
    @GetMapping("active")
    public List<AccAddressInfo> fetchActiveAccAddressInfo() {
        return readService.fetchActiveAccAddressInfo();
    }

    @GetMapping("DeActive")
    public List<AccAddressInfo> fetchDeActivityAccAddressInfo() {
        return readService.fetchDeActiveAccAddressInfo();
    }

}
