package com.ponsun.transaction.accountConfig.productAccountStatus.request;

import lombok.Data;

@Data
public class AbstractProductAccountStatusRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
