package com.ponsun.transaction.accountConfig.debtSubType.data;



import com.ponsun.transaction.accountConfig.debtSubType.request.CreateDebtSubTypeRequest;
import com.ponsun.transaction.accountConfig.debtSubType.request.UpdateDebtSubTypeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DebtSubTypeValidator {
    public void validateSaveDebtSubType(final CreateDebtSubTypeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateDebtSubType(final UpdateDebtSubTypeRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
