package com.ponsun.transaction.accountConfig.accountRelation.request;

import lombok.Data;

@Data
public class CreateAccountRelationRequest extends AbstractAccountRelationRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

