package com.ponsun.transaction.adminconfiguration.admingroup.data;

import com.ponsun.transaction.adminconfiguration.admingroup.request.CreateAdmingroupRequest;
import com.ponsun.transaction.adminconfiguration.admingroup.request.UpdateAdmingroupRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AdmingroupDataValidator {
    public void validateSaveAdmingroup(final CreateAdmingroupRequest request) {
        if (request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("ModuleName parameter required");
        }
    }
    public void validateUpdateAdmingroup(final UpdateAdmingroupRequest request) {
        if (request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("ModuleName parameter required");
        }
    }
}
