package com.ponsun.transaction.accountConfig.accountProductSegment.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountProductSegmentRepository extends JpaRepository<AccountProductSegment,Integer> {

    List<AccountProductSegment> findByStatus (Status string);
}
