package com.ponsun.transaction.accountConfig.accountProductSegment.requests;

import lombok.Data;

@Data
public class UpdateAccountProductSegmentRequest extends AbstractAccountProductSegmentRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
