package com.ponsun.transaction.accountConfig.transactionFrequency.request;

import lombok.Data;

@Data
public class UpdateTransactionFrequencyRequest extends AbstractTransactionFrequencyRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}