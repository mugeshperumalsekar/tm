package com.ponsun.transaction.accessPermission.api;

import com.ponsun.transaction.accessPermission.data.AccessPermissionData;
import com.ponsun.transaction.accessPermission.services.AccessPermissionReadService;
import com.ponsun.transaction.accessPermission.services.AccessPermissionWritePlatformService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("api/v1/accessPermission")
public class AccessPermissionApiResource {
    private final AccessPermissionWritePlatformService accessPermissionWritePlatformService;
    private final AccessPermissionReadService accessPermissionReadService;

    public AccessPermissionApiResource(AccessPermissionWritePlatformService accessPermissionWritePlatformService, AccessPermissionReadService accessPermissionReadService){
        this.accessPermissionWritePlatformService = accessPermissionWritePlatformService;
        this.accessPermissionReadService = accessPermissionReadService;
    }
    @GetMapping
    public List<AccessPermissionData> fetchAll(@RequestParam String uid){
        return this.accessPermissionWritePlatformService.fetchAllAccessPermissionData(uid);
    }

    @GetMapping("/{userId}")
    public List<AccessPermissionData> fetchAllMenuListBasedOnRole(@PathVariable Integer userId){
        return this.accessPermissionReadService.fetchAllMenuListBasedOnRole(userId);
    }
}
