package com.ponsun.transaction.accountConfig.productAccountStatus.domain;

import com.ponsun.transaction.accountConfig.productAccountStatus.request.CreateProductAccountStatusRequest;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.UpdateProductAccountStatusRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_ProductAccountStatus")
public class ProductAccountStatus extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static ProductAccountStatus create(final CreateProductAccountStatusRequest createProductAccountStatusRequest){
        final ProductAccountStatus productAccountStatus = new ProductAccountStatus();
        productAccountStatus.setName(createProductAccountStatusRequest.getName());
        productAccountStatus.setCode(createProductAccountStatusRequest.getCode());
        productAccountStatus.setUid(createProductAccountStatusRequest.getUid());
        productAccountStatus.setStatus(Status.ACTIVE);
        productAccountStatus.setCreatedAt(LocalDateTime.now());
        return productAccountStatus;
    }
    public void update(final UpdateProductAccountStatusRequest updateProductAccountStatusRequest){
        this.setName(updateProductAccountStatusRequest.getName());
        this.setCode(updateProductAccountStatusRequest.getCode());
        this.setEuid(updateProductAccountStatusRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

