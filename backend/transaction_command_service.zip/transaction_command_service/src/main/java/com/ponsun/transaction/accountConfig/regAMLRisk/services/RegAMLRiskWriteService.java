package com.ponsun.transaction.accountConfig.regAMLRisk.services;

import com.ponsun.transaction.accountConfig.regAMLRisk.request.CreateRegAMLRiskRequest;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.UpdateRegAMLRiskRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface RegAMLRiskWriteService {
    Response createRegAMLRisk(CreateRegAMLRiskRequest createRegAMLRiskRequest);

    Response updateRegAMLRisk(Integer id, UpdateRegAMLRiskRequest updateRegAMLRiskRequest);

    Response unblockRegAMLRisk(Integer id);

    Response deActivate(Integer id, Integer euid);
}
