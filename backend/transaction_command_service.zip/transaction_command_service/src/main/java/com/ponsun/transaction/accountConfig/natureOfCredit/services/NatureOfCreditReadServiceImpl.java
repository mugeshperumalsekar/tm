package com.ponsun.transaction.accountConfig.natureOfCredit.services;


import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCredit;
import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCreditRepository;
import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCreditWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class NatureOfCreditReadServiceImpl implements NatureOfCreditReadService {
    private final NatureOfCreditWrapper natureOfCreditWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final NatureOfCreditRepository natureOfCreditRepository;

    @Override
    public NatureOfCredit fetchNatureOfCreditById(Integer id) {
        return this.natureOfCreditRepository.findById(id).get();
    }

    @Override
    public List<NatureOfCredit> fetchActiveNatureOfCredit() {
        return this.natureOfCreditRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<NatureOfCredit> fetchDeActiveNatureOfCredit() {
        return this.natureOfCreditRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<NatureOfCredit> fetchAllNatureOfCredit() {
        return this.natureOfCreditRepository.findAll();
    }
}
