package com.ponsun.transaction.accountConfig.modeOfAccount.services;


import com.ponsun.transaction.accountConfig.modeOfAccount.data.ModeOfAccountValidator;
import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccount;
import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccountRepository;
import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccountWrapper;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.CreateModeOfAccountRequest;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.UpdateModeOfAccountRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class ModeOfAccountWriteServiceImpl implements ModeOfAccountWriteService {

    private final ModeOfAccountRepository modeOfAccountRepository;
    private final ModeOfAccountWrapper modeOfAccountWrapper;
    private final ModeOfAccountValidator modeOfAccountValidator;

    @Override
    @Transactional
    public Response createModeOfAccount(CreateModeOfAccountRequest createModeOfAccountRequest) {
        try {
            this.modeOfAccountValidator.validateSaveModeOfAccount(createModeOfAccountRequest);
            final ModeOfAccount modeOfAccount = ModeOfAccount.create(createModeOfAccountRequest);
            this.modeOfAccountRepository.saveAndFlush(modeOfAccount);
            return Response.of(Long.valueOf(modeOfAccount.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateModeOfAccount(Integer id, UpdateModeOfAccountRequest updateModeOfAccountRequest) {
        try {
            this.modeOfAccountValidator.validateUpdateModeOfAccount(updateModeOfAccountRequest);
            final ModeOfAccount modeOfAccount = this.modeOfAccountWrapper.findOneWithNotFoundDetection(id);
            modeOfAccount.update(updateModeOfAccountRequest);
            this.modeOfAccountRepository.saveAndFlush(modeOfAccount);
            return Response.of(Long.valueOf(modeOfAccount.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockModeOfAccount(Integer id) {
        try {
            final ModeOfAccount modeOfAccount = this.modeOfAccountWrapper.findOneWithNotFoundDetection(id);
            modeOfAccount.setStatus(Status.ACTIVE);
            modeOfAccount.setUpdatedAt(LocalDateTime.now());
            this.modeOfAccountRepository.saveAndFlush(modeOfAccount);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            ModeOfAccount modeOfAccount = this.modeOfAccountWrapper.findOneWithNotFoundDetection(id);
            modeOfAccount.setEuid(euid);
            modeOfAccount.setStatus(Status.DELETE);
            modeOfAccount.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(modeOfAccount.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
