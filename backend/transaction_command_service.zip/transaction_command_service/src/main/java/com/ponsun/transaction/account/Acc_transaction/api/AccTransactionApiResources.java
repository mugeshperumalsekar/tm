package com.ponsun.transaction.account.Acc_transaction.api;
import com.ponsun.transaction.account.Acc_transaction.data.AccTransactionData;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransaction;
import com.ponsun.transaction.account.Acc_transaction.requests.CreateAccTransactionRequest;
import com.ponsun.transaction.account.Acc_transaction.requests.UpdateAccTransactionRequest;
import com.ponsun.transaction.account.Acc_transaction.services.AccTransactionReadService;
import com.ponsun.transaction.account.Acc_transaction.services.AccTransactionWriteService;
import com.ponsun.transaction.excel.excelTranImport.fileupload.XlsFileParser;
import com.ponsun.transaction.excel.excelTranImport.service.TranExcelDataCommandService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccTransaction")
@Tag(name = "AccTransactionApiResources")
public class AccTransactionApiResources {
    private final AccTransactionWriteService writeService;
    private final AccTransactionReadService readService;
    private final JdbcTemplate jdbcTemplate;
    private final TranExcelDataCommandService tranExcelDataCommandService;

    @PostMapping("/CreateAccPayDetailsRequest")
    public Response createAccTransaction(@RequestBody CreateAccTransactionRequest request) {
        Response response = this.writeService.createAccTransaction(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccTransaction(@PathVariable Integer id, @RequestBody UpdateAccTransactionRequest request) {
        Response response = this.writeService.updateAccTransaction(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccTransaction fetchAccTransactionById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccTransactionById(id);
    }
    @GetMapping
    public List<AccTransaction> fetchAll() {
        return this.readService.fetchAllAccTransaction();
    }

    @GetMapping("/fetchAllData")
    public List<AccTransactionData> fetchAllTransactionGroupByAccountId() {
        return this.readService.fetchAllTransactionGroupByAccountId();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccTransaction(@PathVariable Integer id){
        Response response = this.writeService.unblockAccTransaction(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccTransaction> fetchActiveAccPayDetails() {
        return readService.fetchActiveAccTransaction();
    }
    @GetMapping("DeActive")
    public List<AccTransaction> fetchDeAccPayDetails() {
        return readService.fetchDeActiveAccTransaction();
    }


    @PostMapping(value = "/trantableBulkImport" , consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
     public String saveExcelDataFromFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("date") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) {
            System.out.println("START of saveExcelDataFromFile()");

        try {
            if (file.isEmpty()) {
                return "Invalid file: file is empty";
            }

            XlsFileParser parser = new XlsFileParser(file,date,jdbcTemplate,tranExcelDataCommandService);
            parser.parseAccTransExcelData();

//            tranExcelDataCommandService.saveBulkData(parsedData, date.atStartOfDay());

            System.out.println("END of saveExcelDataFromFile()");
            return "File processed successfully";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error processing file: " + e.getMessage();
        }
    }

}
