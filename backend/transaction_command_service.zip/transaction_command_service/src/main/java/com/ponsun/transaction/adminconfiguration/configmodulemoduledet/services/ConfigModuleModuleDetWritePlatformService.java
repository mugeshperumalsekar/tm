package com.ponsun.transaction.adminconfiguration.configmodulemoduledet.services;


import com.ponsun.transaction.adminconfiguration.configmodulemoduledet.data.ConfigModuleModuleDetData;

import java.util.List;

public interface ConfigModuleModuleDetWritePlatformService {
    List<ConfigModuleModuleDetData> fetchAllListofAlertData();
}
