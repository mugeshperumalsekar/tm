package com.ponsun.transaction.accountConfig.isDefaulted.services;

import com.ponsun.transaction.accountConfig.isDefaulted.request.CreateIsDefaultedRequest;
import com.ponsun.transaction.accountConfig.isDefaulted.request.UpdateIsDefaultedRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface IsDefaultedWriteService {
    Response createIsDefaulted(CreateIsDefaultedRequest createIsDefaultedRequest);

    Response updateIsDefaulted(Integer id, UpdateIsDefaultedRequest updateIsDefaultedRequest);

    Response unblockIsDefaulted(Integer id);

    Response deActivate(Integer id, Integer euid);
}
