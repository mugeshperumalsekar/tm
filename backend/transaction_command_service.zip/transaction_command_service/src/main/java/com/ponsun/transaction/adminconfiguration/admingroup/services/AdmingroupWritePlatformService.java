package com.ponsun.transaction.adminconfiguration.admingroup.services;


import com.ponsun.transaction.adminconfiguration.admingroup.request.CreateAdmingroupRequest;
import com.ponsun.transaction.adminconfiguration.admingroup.request.UpdateAdmingroupRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AdmingroupWritePlatformService {

    Response createAdmingroup(CreateAdmingroupRequest createAdmingroupRequest);
    Response updateAdmingroup(Integer id, UpdateAdmingroupRequest updateAdmingroupRequest);
    Response blockAdmingroup(Integer id);
    Response unblockAdmingroup(Integer id);


}
