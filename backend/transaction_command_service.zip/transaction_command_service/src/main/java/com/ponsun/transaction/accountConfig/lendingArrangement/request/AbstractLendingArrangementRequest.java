package com.ponsun.transaction.accountConfig.lendingArrangement.request;

import lombok.Data;

@Data
public class AbstractLendingArrangementRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}

