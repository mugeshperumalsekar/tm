package com.ponsun.transaction.account.Acc_transaction.domain;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRisk;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.customerConfig.customercategory.domain.CustomerCategory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AccTransactionRepository extends JpaRepository<AccTransaction, Integer> {

    List<AccTransaction> findByStatus(Status string);

    @Query("SELECT at FROM AccTransaction at WHERE at.isCalc = 0 AND at.transStatus = 'Completed' GROUP BY at.accInfo ORDER BY at.id")
    List<AccTransaction> fetchDataGroupByAccountId();

//    @Query("SELECT at bt.transType, COUNT(at) FROM AccTransaction at JOIN InstrumentType bt WHERE at.instrumentType.id = bt.id AND at.isCalc = 0 AND at.transStatus = 'Completed' GROUP BY at.accInfo, at.instrumentType.id, at.transType ORDER BY at.id")
//    List<AccTransaction> fetchDataGroupByAccountId();
//

    @Query("SELECT at FROM AccTransaction at WHERE at.isCalc = 0 AND at.accInfo.id = :accountId AND at.transStatus = 'Completed' ORDER BY at.id")
    List<AccTransaction> findByAccountId(@Param("accountId") Integer accountId);


}
