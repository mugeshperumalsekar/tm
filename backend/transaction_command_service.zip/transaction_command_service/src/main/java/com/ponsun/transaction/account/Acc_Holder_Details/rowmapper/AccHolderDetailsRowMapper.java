package com.ponsun.transaction.account.Acc_Holder_Details.rowmapper;

import com.ponsun.transaction.account.Acc_Holder_Details.data.AccHolderDetailsData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Service
@Slf4j
@Data
public class AccHolderDetailsRowMapper implements RowMapper<AccHolderDetailsData> {
    private final String schema;

    public AccHolderDetailsRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM tm_acc_holder_details ahd ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("ahd.id as id, ");
        builder.append("ahd.customerId as customerId, ");
        builder.append("ahd.borrowerDetails as borrowerDetails, ");
        builder.append("ahd.branchReceiptDate as branchReceiptDate, ");
        builder.append("ahd.dateofDefault as dateofDefault, ");
        builder.append("ahd.dateofFilingofSuit as dateofFilingofSuit, ");
        builder.append("ahd.dateofLastRepayment as dateofLastRepayment, ");
        builder.append("ahd.debtSubType as debtSubType, ");
        builder.append("ahd.defaultAmount as defaultAmount, ");
        builder.append("ahd.defaultRemarks as defaultRemarks, ");
        builder.append("ahd.disbursementDate as disbursementDate, ");
        builder.append("ahd.drawingPower as drawingPower, ");
        builder.append("ahd.emiAmount as emiAmount, ");
        builder.append("ahd.finalEMIDate as finalEMIDate, ");
        builder.append("ahd.firstHolderRecordIdentifier as firstHolderRecordIdentifier, ");
        builder.append("ahd.firstHolderRelation as firstHolderRelation, ");
        builder.append("ahd.firstHolderSourceSystemCustomerCode as firstHolderSourceSystemCustomerCode, ");
        builder.append("ahd.firstHolderSourceSystemName as firstHolderSourceSystemName, ");
        builder.append("ahd.firstPremiumReceiptDate as firstPremiumReceiptDate, ");
        builder.append("ahd.interestOutstanding as interestOutstanding, ");
        builder.append("ahd.isDefaulted as isDefaulted, ");
        builder.append("ahd.isFamilyDeclaration as isFamilyDeclaration, ");
        builder.append("ahd.isWhiteListed as isWhiteListed, ");
        builder.append("ahd.lendingArrangement as lendingArrangement, ");
        builder.append("ahd.loginDate as loginDate, ");
        builder.append("ahd.natureofCredit as natureofCredit, ");
        builder.append("ahd.networthMultiplier as networthMultiplier, ");
        builder.append("ahd.oldProductAccountNumber as oldProductAccountNumber, ");
        builder.append("ahd.preferredtransactionmode as preferredtransactionmode, ");
        builder.append("ahd.relatedPartyCount as relatedPartyCount, ");
        builder.append("ahd.remarks as remarks, ");
        builder.append("ahd.riskCommencementDate as riskCommencementDate, ");
        builder.append("ahd.sanctionedAmount as sanctionedAmount, ");
        builder.append("ahd.secondHolderFirstname as secondHolderFirstname, ");
        builder.append("ahd.secondHolderMiddlename as secondHolderMiddlename, ");
        builder.append("ahd.secondHolderLastname as secondHolderLastname, ");
        builder.append("ahd.secondHolderPan as secondHolderPan, ");
        builder.append("ahd.thirdHolderFirstname as thirdHolderFirstname, ");
        builder.append("ahd.thirdHolderMiddlename as thirdHolderMiddlename, ");
        builder.append("ahd.thirdHolderLastname as thirdHolderLastname, ");
        builder.append("ahd.thirdHolderPan as thirdHolderPan, ");
        builder.append("ahd.totalOutstandingAmount as totalOutstandingAmount, ");
        builder.append("ahd.accountId as accountId, ");
        builder.append("ahd.uid as uid, ");
        builder.append("ahd.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccHolderDetailsData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer customerId = rs.getInt("customerId");
        final String borrowerDetails = rs.getString("borrowerDetails");
        final String branchReceiptDate = rs.getString("branchReceiptDate");
        final String dateofDefault = rs.getString("dateofDefault");
        final String dateofFilingofSuit = rs.getString("dateofFilingofSuit");
        final String dateofLastRepayment = rs.getString("dateofLastRepayment");
        final String debtSubType = rs.getString("debtSubType");
        final double defaultAmount = rs.getDouble("defaultAmount");
        final String defaultRemarks = rs.getString("defaultRemarks");
        final String disbursementDate = rs.getString("disbursementDate");
        final double drawingPower = rs.getDouble("drawingPower");
        final double emiAmount = rs.getDouble("emiAmount");
        final String finalEMIDate = rs.getString("finalEMIDate");
        final String firstHolderRecordIdentifier = rs.getString("firstHolderRecordIdentifier");
        final String firstHolderRelation = rs.getString("firstHolderRelation");
        final String firstHolderSourceSystemCustomerCode = rs.getString("firstHolderSourceSystemCustomerCode");
        final String firstHolderSourceSystemName = rs.getString("firstHolderSourceSystemName");
        final String firstPremiumReceiptDate = rs.getString("firstPremiumReceiptDate");
        final double interestOutstanding = rs.getDouble("interestOutstanding");
        final String isDefaulted = rs.getString("isDefaulted");
        final String isFamilyDeclaration = rs.getString("isFamilyDeclaration");
        final String isWhiteListed = rs.getString("isWhiteListed");
        final String lendingArrangement = rs.getString("lendingArrangement");
        final String loginDate = rs.getString("loginDate");
        final String natureofCredit = rs.getString("natureofCredit");
        final double networthMultiplier = rs.getDouble("networthMultiplier");
        final String oldProductAccountNumber = rs.getString("oldProductAccountNumber");
        final String preferredtransactionmode = rs.getString("preferredtransactionmode");
        final Integer relatedPartyCount = rs.getInt("relatedPartyCount");
        final String remarks = rs.getString("remarks");
        final Integer riskCommencementDate = rs.getInt("riskCommencementDate");
        final double sanctionedAmount = rs.getDouble("sanctionedAmount");
        final String secondHolderFirstname = rs.getString("secondHolderFirstname");
        final String secondHolderMiddlename = rs.getString("secondHolderMiddlename");
        final String secondHolderLastname = rs.getString("secondHolderLastname");
        final String secondHolderPan = rs.getString("secondHolderPan");
        final String thirdHolderFirstname = rs.getString("thirdHolderFirstname");
        final String thirdHolderMiddlename = rs.getString("thirdHolderMiddlename");
        final String thirdHolderLastname = rs.getString("thirdHolderLastname");
        final String thirdHolderPan = rs.getString("thirdHolderPan");
        final double totalOutstandingAmount = rs.getDouble("totalOutstandingAmount");
        final Integer accountId = rs.getInt("accountId");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new AccHolderDetailsData( id,customerId, borrowerDetails, branchReceiptDate, dateofDefault, dateofFilingofSuit, dateofLastRepayment, debtSubType, defaultAmount, defaultRemarks, disbursementDate, drawingPower, emiAmount, finalEMIDate, firstHolderRecordIdentifier, firstHolderRelation, firstHolderSourceSystemCustomerCode, firstHolderSourceSystemName, firstPremiumReceiptDate,  interestOutstanding, isDefaulted,  isFamilyDeclaration, isWhiteListed, lendingArrangement, loginDate, natureofCredit, networthMultiplier, oldProductAccountNumber, preferredtransactionmode, relatedPartyCount, remarks, riskCommencementDate, sanctionedAmount, secondHolderFirstname, secondHolderMiddlename, secondHolderLastname, secondHolderPan, thirdHolderFirstname, thirdHolderMiddlename, thirdHolderLastname, thirdHolderPan, totalOutstandingAmount, accountId, uid, euid);
    }
}