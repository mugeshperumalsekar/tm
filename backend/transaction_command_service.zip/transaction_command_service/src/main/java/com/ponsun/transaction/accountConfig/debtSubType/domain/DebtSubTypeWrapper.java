package com.ponsun.transaction.accountConfig.debtSubType.domain;


import com.ponsun.transaction.accountConfig.debtSubType.request.AbstractDebtSubTypeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class DebtSubTypeWrapper extends AbstractDebtSubTypeRequest {
    private final DebtSubTypeRepository debtSubTypeRepository;

    @Transactional
    public DebtSubType findOneWithNotFoundDetection(final Integer id) {
        return this.debtSubTypeRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("DebtSubType Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }
}

