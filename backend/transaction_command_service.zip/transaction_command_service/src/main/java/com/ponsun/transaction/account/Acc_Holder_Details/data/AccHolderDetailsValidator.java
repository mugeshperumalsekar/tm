package com.ponsun.transaction.account.Acc_Holder_Details.data;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.CreateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.UpdateAccHolderDetailsRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccHolderDetailsValidator {
    public void validateSaveAccHolderDetails(final CreateAccHolderDetailsRequest request){
        if (request.getAccountId()== null || request.getAccountId().equals("")){
            throw new PS_transaction_ApplicationException("AccountId parameter required");
        }
    }
    public void validateUpdateAccHolderDetails(final UpdateAccHolderDetailsRequest request){
        if(request.getAccountId() == null || request.getAccountId().equals("")) {
            throw new PS_transaction_ApplicationException("AccountId parameter required");

        }
    }
}
