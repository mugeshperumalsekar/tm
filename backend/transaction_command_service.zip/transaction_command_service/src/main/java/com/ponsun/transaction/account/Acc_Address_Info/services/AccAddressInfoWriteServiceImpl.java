package com.ponsun.transaction.account.Acc_Address_Info.services;

import com.ponsun.transaction.account.Acc_Address_Info.data.AccAddressInfoValidator;
import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfo;
import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfoRepository;
import com.ponsun.transaction.account.Acc_Address_Info.domain.AccAddressInfoWrapper;
import com.ponsun.transaction.account.Acc_Address_Info.requests.CreateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Address_Info.requests.UpdateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccAddressInfoWriteServiceImpl implements AccAddressInfoWriteService {
    private final AccAddressInfoRepository repository;
    private final AccAddressInfoWrapper wrapper;
    private final AccAddressInfoValidator validator;
    private final AccInfoWrapper accInfoWrapper;

    @Override
    @Transactional

    public Response createAccAddressInfo(CreateAccAddressInfoRequest request) {
        try {
            this.validator.validateSaveAccAddressInfo(request);
            AccInfo accInfo = accInfoWrapper.findOneWithNotFoundDetection(request.getAccountId());
            if (accInfo == null) {
                throw new PS_transaction_ApplicationException("Account information not found for accountId: " + request.getAccountId());
            }
            final AccAddressInfo addressInfo = AccAddressInfo.create(request,accInfo);
            this.repository.saveAndFlush(addressInfo);
            return Response.of(Long.valueOf(addressInfo.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccAddressInfo(Integer id, UpdateAccAddressInfoRequest request) {
        try {
            this.validator.validateUpdateAccAddressInfo(request);
            final AccAddressInfo addressInfo = this.wrapper.findOneWithNotFoundDetection(id);
            addressInfo.update(request);
            this.repository.saveAndFlush(addressInfo);
            return Response.of(Long.valueOf(addressInfo.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccAddressInfo(Integer id) {
        try {
            final AccAddressInfo addressInfo = this.wrapper.findOneWithNotFoundDetection(id);
            addressInfo.setStatus(Status.ACTIVE);
            addressInfo.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(addressInfo);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccAddressInfo addressInfo = this.wrapper.findOneWithNotFoundDetection(id);
            addressInfo.setEuid(euid);
            addressInfo.setStatus(Status.DELETE);
            addressInfo.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(addressInfo);
            return Response.of(Long.valueOf(addressInfo.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }
}
