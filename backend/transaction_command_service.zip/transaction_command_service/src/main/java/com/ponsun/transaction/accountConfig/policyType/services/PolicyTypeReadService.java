package com.ponsun.transaction.accountConfig.policyType.services;

import com.ponsun.transaction.accountConfig.policyType.domain.PolicyType;

import java.util.List;

public interface PolicyTypeReadService {
    List<PolicyType> fetchAllPolicyType();

    PolicyType fetchPolicyTypeById(Integer id);

    List<PolicyType> fetchActivePolicyType();

    List<PolicyType> fetchDeActivePolicyType();
}
