package com.ponsun.transaction.account.Acc_Info.requests;

import lombok.Data;

@Data
public class AbstractAccInfoRequest {
    private Integer id;
    private Integer customerId;
    private String productAccOpeningDate;
    private String productAccountNumber;
    private String productAccountReasonCodeDescription;
    private String productAccountStatus;
    private String productAccountStatusDescription;
    private String productAccountStatusEffectiveDate;
    private String productAccountStatusReasonCode;
    private String productAccountType;
    private String productApplicationDate;
    private Integer productSegmentId;
    private String rmCode;
    private String rmType;
    private String tags;
    private String underwritingDate;
    private Integer uid;
    private Integer euid;
}
