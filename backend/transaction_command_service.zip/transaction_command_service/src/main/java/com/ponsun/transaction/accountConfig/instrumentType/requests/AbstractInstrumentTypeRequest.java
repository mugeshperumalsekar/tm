package com.ponsun.transaction.accountConfig.instrumentType.requests;

import lombok.Data;

@Data
public class AbstractInstrumentTypeRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
