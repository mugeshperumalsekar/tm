package com.ponsun.transaction.accountConfig.fundedType.services;

import com.ponsun.transaction.accountConfig.fundedType.domain.FundedType;

import java.util.List;

public interface FundedTypeReadService {
    List<FundedType> fetchAllFundedType();

    FundedType fetchFundedTypeById(Integer id);

    List<FundedType> fetchActiveFundedType();

    List<FundedType> fetchDeActiveFundedType();
}
