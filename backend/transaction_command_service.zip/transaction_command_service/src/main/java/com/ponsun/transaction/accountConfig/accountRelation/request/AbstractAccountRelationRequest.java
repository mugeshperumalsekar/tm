package com.ponsun.transaction.accountConfig.accountRelation.request;

import lombok.Data;

@Data
public class AbstractAccountRelationRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
