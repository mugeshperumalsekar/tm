package com.ponsun.transaction.account.Acc_Info_det.requests;

import lombok.Data;

@Data
public class CreateAccountInfoDetRequest extends AbstractAccountInfoDetRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
