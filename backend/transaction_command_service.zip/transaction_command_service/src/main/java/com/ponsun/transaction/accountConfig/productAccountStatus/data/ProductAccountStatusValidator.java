package com.ponsun.transaction.accountConfig.productAccountStatus.data;


import com.ponsun.transaction.accountConfig.productAccountStatus.request.CreateProductAccountStatusRequest;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.UpdateProductAccountStatusRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ProductAccountStatusValidator {
    public void validateSaveProductAccountStatus(final CreateProductAccountStatusRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateProductAccountStatus(final UpdateProductAccountStatusRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
