package com.ponsun.transaction.accountConfig.regAMLRisk.domain;


import com.ponsun.transaction.accountConfig.regAMLRisk.request.AbstractRegAMLRiskRequest;
import com.ponsun.transaction.customerConfig.Segment.domain.Segment;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RegAMLRiskWrapper extends AbstractRegAMLRiskRequest {
    private final RegAMLRiskRepository RegAMLRiskRepository;

    @Transactional
    public RegAMLRisk findOneWithNotFoundDetection(final Integer id) {
        return this.RegAMLRiskRepository.findByIdAndStatus(id).orElseThrow(() -> new EntityNotFoundException("RegAMLRisk Not found " + id));
    }

    @Transactional
    public RegAMLRisk findOneWithNotFoundDetection(final String risk) {
        return this.RegAMLRiskRepository.findByRisk(risk).orElse(null);//.orElseThrow(() -> new EntityNotFoundException("RegAMLRisk Not found " + risk));
    }

    @Transactional
    public List<RegAMLRisk> fetchAll(){
        return this.RegAMLRiskRepository.fetchAll(PageRequest.of(0, 100));

    }
    @Override
    public String toString() {
        return super.toString();
    }

    @Transactional
    public List<RegAMLRisk> findRisksByIds(final List<Integer> ids) {
        List<RegAMLRisk> regAMLRisks = RegAMLRiskRepository.findRisksByIds(ids);
        return regAMLRisks;
    }

//    @Transactional
//    public List<RegAMLRisk> findRisksByIds(final List<Integer> ids) {
//        List<RegAMLRisk> regAMLRisks = RegAMLRiskRepository.findRisksByIds(ids);
//        if (regAMLRisks == null || regAMLRisks.isEmpty()) {
//            RegAMLRisk regAMLRisk = new RegAMLRisk();
//            regAMLRisk.setId(0);
//            regAMLRisks = new ArrayList<>();
//            regAMLRisks.add(regAMLRisk);
//        }
//        return regAMLRisks;
//    }


}

