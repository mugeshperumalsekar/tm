package com.ponsun.transaction.account.Acc_Pay_Details.services;

import com.ponsun.transaction.account.Acc_Pay_Details.requests.CreateAccPayDetailsRequest;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.UpdateAccPayDetailsRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccPayDetailsWriteService {
    Response createAccPayDetails(CreateAccPayDetailsRequest request);
    Response updateAccPayDetails(Integer id, UpdateAccPayDetailsRequest request);
    Response unblockAccPayDetails(Integer id);
    Response deactive(Integer id, Integer euid);
}
