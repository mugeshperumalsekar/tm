package com.ponsun.transaction.account.Acc_Risk_Status_Det.data;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.CreateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.UpdateAccRiskStatusDetRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccRiskStatusDetValidator {
    public void validateSaveAccRiskStatusDet(final CreateAccRiskStatusDetRequest request){
        if (request.getAccountId()== null || request.getAccountId().equals("")){
            throw new PS_transaction_ApplicationException("AccountId parameter required");
        }
    }
    public void validateUpdateAccRiskStatusDet(final UpdateAccRiskStatusDetRequest request){
        if(request.getAccountId() == null || request.getAccountId().equals("")) {
            throw new PS_transaction_ApplicationException("AccountId parameter required");

        }
    }
}
