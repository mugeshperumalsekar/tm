package com.ponsun.transaction.account.Acc_Risk_Status_Det.domain;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.AbstractAccRiskStatusDetRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@RequiredArgsConstructor
public class AccRiskStatusDetWrapper extends AbstractAccRiskStatusDetRequest {

    private final AccRiskStatusDetRepository repository;
    @Transactional
    public AccRiskStatusDet findOneWithNotFoundDetection (final Integer id) {
        return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("AccRiskStatusDet Not found " + id));
    }
    @Override
    public String toString(){
        return super.toString();
    }
}
