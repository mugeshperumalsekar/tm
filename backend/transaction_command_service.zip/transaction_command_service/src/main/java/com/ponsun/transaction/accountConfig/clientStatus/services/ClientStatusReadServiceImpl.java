package com.ponsun.transaction.accountConfig.clientStatus.services;


import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatus;
import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatusRepository;
import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatusWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClientStatusReadServiceImpl implements ClientStatusReadService {
    private final ClientStatusWrapper clientStatusWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final ClientStatusRepository clientStatusRepository;

    @Override
    public ClientStatus fetchClientStatusById(Integer id) {
        return this.clientStatusRepository.findById(id).get();
    }

    @Override
    public List<ClientStatus> fetchActiveClientStatus() {
        return this.clientStatusRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<ClientStatus> fetchDeActiveClientStatus() {
        return this.clientStatusRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<ClientStatus> fetchAllClientStatus() {
        return this.clientStatusRepository.findAll();
    }
}
