package com.ponsun.transaction.account.Acc_Info_det.services;

import com.ponsun.transaction.account.Acc_Info_det.requests.CreateAccountInfoDetRequest;
import com.ponsun.transaction.account.Acc_Info_det.requests.UpdateAccountInfoDetRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccountInfoDetWriteService {
    Response createAccountInfoDet(CreateAccountInfoDetRequest request);
    Response updateAccountInfoDet(Integer id, UpdateAccountInfoDetRequest request);
    Response unblockAccountInfoDet(Integer id);
    Response deactive(Integer id, Integer euid);
}
