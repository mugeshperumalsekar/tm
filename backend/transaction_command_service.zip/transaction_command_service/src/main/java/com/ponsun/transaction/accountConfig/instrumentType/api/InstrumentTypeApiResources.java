package com.ponsun.transaction.accountConfig.instrumentType.api;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentType;
import com.ponsun.transaction.accountConfig.instrumentType.requests.CreateInstrumentTypeRequest;
import com.ponsun.transaction.accountConfig.instrumentType.requests.UpdateInstrumentTypeRequest;
import com.ponsun.transaction.accountConfig.instrumentType.services.InstrumentTypeReadService;
import com.ponsun.transaction.accountConfig.instrumentType.services.InstrumentTypeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/InstrumentType")
@Tag(name = "InstrumentTypeApiResources")
public class InstrumentTypeApiResources {
    private final InstrumentTypeWriteService writeService;
    private final InstrumentTypeReadService readService;

    @PostMapping("/CreateInstrumentTypeRequest")
    public Response createInstrumentType(@RequestBody CreateInstrumentTypeRequest request) {
        Response response = this.writeService.createInstrumentType(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateInstrumentType(@PathVariable Integer id, @RequestBody UpdateInstrumentTypeRequest request) {
        Response response = this.writeService.updateInstrumentType(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public InstrumentType fetchInstrumentTypeById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchInstrumentTypeById(id);
    }
    @GetMapping
    public List<InstrumentType> fetchAll() {
        return this.readService.fetchAllInstrumentType();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockInstrumentType(@PathVariable Integer id){
        Response response = this.writeService.unblockInstrumentType(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<InstrumentType> fetchActiveInstrumentType() {
        return readService.fetchActiveInstrumentType();
    }
    @GetMapping("DeActive")
    public List<InstrumentType> fetchDeInstrumentType() {
        return readService.fetchDeActiveInstrumentType();
    }
}
