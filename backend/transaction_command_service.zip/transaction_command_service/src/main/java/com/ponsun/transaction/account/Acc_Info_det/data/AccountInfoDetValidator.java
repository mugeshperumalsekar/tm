package com.ponsun.transaction.account.Acc_Info_det.data;
import com.ponsun.transaction.account.Acc_Info_det.requests.CreateAccountInfoDetRequest;
import com.ponsun.transaction.account.Acc_Info_det.requests.UpdateAccountInfoDetRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountInfoDetValidator {
    public void validateSaveAccountInfoDet(final CreateAccountInfoDetRequest request){
        if (request.getAccountNumber()== null || request.getAccountNumber().equals("")){
            throw new PS_transaction_ApplicationException("AccountNumber parameter required");
        }
    }
    public void validateUpdateAccountInfoDet(final UpdateAccountInfoDetRequest request){
        if(request.getAccountNumber() == null || request.getAccountNumber().equals("")) {
            throw new PS_transaction_ApplicationException("AccountNumber parameter required");

        }
    }
}
