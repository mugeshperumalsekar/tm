package com.ponsun.transaction.accountConfig.lendingArrangement.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface LendingArrangementRepository extends JpaRepository<LendingArrangement, Integer> {
    Optional<LendingArrangement> findById(Integer id);
    List<LendingArrangement> findByStatus (Status string);

}