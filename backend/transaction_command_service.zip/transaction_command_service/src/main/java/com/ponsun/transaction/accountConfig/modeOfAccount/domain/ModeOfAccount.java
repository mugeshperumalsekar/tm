package com.ponsun.transaction.accountConfig.modeOfAccount.domain;

import com.ponsun.transaction.accountConfig.modeOfAccount.request.CreateModeOfAccountRequest;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.UpdateModeOfAccountRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_mode_of_account")
public class ModeOfAccount extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static ModeOfAccount create(final CreateModeOfAccountRequest createModeOfAccountRequest){
        final ModeOfAccount modeOfAccount = new ModeOfAccount();
        modeOfAccount.setName(createModeOfAccountRequest.getName());
        modeOfAccount.setCode(createModeOfAccountRequest.getCode());
        modeOfAccount.setUid(createModeOfAccountRequest.getUid());
        modeOfAccount.setStatus(Status.ACTIVE);
        modeOfAccount.setCreatedAt(LocalDateTime.now());
        return modeOfAccount;
    }
    public void update(final UpdateModeOfAccountRequest updateModeOfAccountRequest){
        this.setName(updateModeOfAccountRequest.getName());
        this.setCode(updateModeOfAccountRequest.getCode());
        this.setEuid(updateModeOfAccountRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

