package com.ponsun.transaction.accountConfig.productAccountStatus.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProductAccountStatusRepository extends JpaRepository<ProductAccountStatus, Integer> {
    Optional<ProductAccountStatus> findById(Integer id);

    List<ProductAccountStatus> findByStatus(Status string);
}