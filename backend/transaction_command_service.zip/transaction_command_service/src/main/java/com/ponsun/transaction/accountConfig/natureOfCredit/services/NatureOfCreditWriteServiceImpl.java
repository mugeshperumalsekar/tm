package com.ponsun.transaction.accountConfig.natureOfCredit.services;


import com.ponsun.transaction.accountConfig.natureOfCredit.request.UpdateNatureOfCreditRequest;
import com.ponsun.transaction.accountConfig.natureOfCredit.data.NatureOfCreditValidator;
import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCredit;
import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCreditRepository;
import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCreditWrapper;
import com.ponsun.transaction.accountConfig.natureOfCredit.request.CreateNatureOfCreditRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class NatureOfCreditWriteServiceImpl implements NatureOfCreditWriteService {

    private final NatureOfCreditRepository natureOfCreditRepository;
    private final NatureOfCreditWrapper natureOfCreditWrapper;
    private final NatureOfCreditValidator natureOfCreditValidator;


    @Transactional
    public Response createNatureOfCredit(CreateNatureOfCreditRequest createNatureOfCreditRequest) {
        try {
            this.natureOfCreditValidator.validateSaveNatureOfCredit(createNatureOfCreditRequest);
            final NatureOfCredit natureOfCredit = NatureOfCredit.create(createNatureOfCreditRequest);
            this.natureOfCreditRepository.saveAndFlush(natureOfCredit);
            return Response.of(Long.valueOf(natureOfCredit.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
    @Override
    @Transactional
    public Response updateNatureOfCredit(Integer id, UpdateNatureOfCreditRequest updateNatureOfCreditRequest) {
        try {
            this.natureOfCreditValidator.validateUpdateNatureOfCredit(updateNatureOfCreditRequest);
            final NatureOfCredit natureOfCredit = this.natureOfCreditWrapper.findOneWithNotFoundDetection(id);
            natureOfCredit.update(updateNatureOfCreditRequest);
            this.natureOfCreditRepository.saveAndFlush(natureOfCredit);
            return Response.of(Long.valueOf(natureOfCredit.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
    @Override
    @Transactional
    public Response unblockNatureOfCredit(Integer id) {
        try {
            final NatureOfCredit natureOfCredit = this.natureOfCreditWrapper.findOneWithNotFoundDetection(id);
            natureOfCredit.setStatus(Status.ACTIVE);
            natureOfCredit.setUpdatedAt(LocalDateTime.now());
            this.natureOfCreditRepository.saveAndFlush(natureOfCredit);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            NatureOfCredit natureOfCredit = this.natureOfCreditWrapper.findOneWithNotFoundDetection(id);
            natureOfCredit.setEuid(euid);
            natureOfCredit.setStatus(Status.DELETE);
            natureOfCredit.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(natureOfCredit.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
