package com.ponsun.transaction.accountConfig.policyType.api;


import com.ponsun.transaction.accountConfig.policyType.domain.PolicyType;
import com.ponsun.transaction.accountConfig.policyType.request.CreatePolicyTypeRequest;
import com.ponsun.transaction.accountConfig.policyType.request.UpdatePolicyTypeRequest;
import com.ponsun.transaction.accountConfig.policyType.services.PolicyTypeReadService;
import com.ponsun.transaction.accountConfig.policyType.services.PolicyTypeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/PolicyType")
@Tag(name = "PolicyTypeApiResource")
public class PolicyTypeApiResources {
    private final PolicyTypeWriteService policyTypeWriteService;
    private final PolicyTypeReadService policyTypeReadService;

    @PostMapping("/CreatePolicyTypeRequest")
    public Response savePolicyType(@RequestBody CreatePolicyTypeRequest createPolicyTypeRequest) {
        log.debug("START savePolicyType request body {}",createPolicyTypeRequest);
        Response response = this.policyTypeWriteService.createPolicyType(createPolicyTypeRequest);
        log.debug("START savePolicyType response",response);
        return response;
    }

    @GetMapping
    public List<PolicyType> fetchAll() {
        return this.policyTypeReadService.fetchAllPolicyType();
    }

    @GetMapping("/{id}")
    public PolicyType fetchPolicyTypeById(@PathVariable(name = "id") Integer id) {
        return this.policyTypeReadService.fetchPolicyTypeById(id);
    }

    @PutMapping("/{id}")
    public Response updatePolicyType(@PathVariable Integer id, @RequestBody UpdatePolicyTypeRequest updatePolicyTypeRequest) {
        log.debug("START updatePolicyType request body {}",updatePolicyTypeRequest);
        Response response = this.policyTypeWriteService.updatePolicyType(id, updatePolicyTypeRequest);
        log.debug("START updatePolicyType response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockPolicyType(@PathVariable Integer id){
        Response response = this.policyTypeWriteService.unblockPolicyType(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.policyTypeWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<PolicyType> fetchActivePolicyType() {
        return policyTypeReadService.fetchActivePolicyType();
    }
    @GetMapping("DeActive")
    public List<PolicyType> fetchDePolicyType() {
        return policyTypeReadService.fetchDeActivePolicyType();
    }

}

