package com.ponsun.transaction.account.Acc_transaction.data;
import com.ponsun.transaction.account.Acc_transaction.requests.CreateAccTransactionRequest;
import com.ponsun.transaction.account.Acc_transaction.requests.UpdateAccTransactionRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccTransactionValidator {

    public void validateSaveAccTransaction(final CreateAccTransactionRequest request){
        if (request.getApplicationNumber()== null || request.getApplicationNumber().equals("")){
            throw new PS_transaction_ApplicationException("ApplicationNumber parameter required");
        }
        if (request.getAmt() <= 0) {
            throw new PS_transaction_ApplicationException("Amount must be greater than zero");
        }
    }
    public void validateUpdateAccTransaction(final UpdateAccTransactionRequest request){
        if(request.getApplicationNumber() == null || request.getApplicationNumber().equals("")) {
            throw new PS_transaction_ApplicationException("ApplicationNumber parameter required");

        }
        if (request.getAmt() <= 0) {
            throw new PS_transaction_ApplicationException("Amount must be greater than zero");
        }
    }
}
