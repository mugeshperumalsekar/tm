package com.ponsun.transaction.accountConfig.debtSubType.data;
import lombok.Data;
@Data
public class DebtSubTypeData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public DebtSubTypeData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static DebtSubTypeData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new DebtSubTypeData(id,name,code,uid,euid);
    }
}

