package com.ponsun.transaction.adminconfiguration.adminconfigmodule.request;

import lombok.Data;

@Data
public class CreateAdminConfigModuleRequest extends AbstractAdminConfigModuleBaseRequest{
    @Override
    public String toString() {return super.toString(); }

}
