package com.ponsun.transaction.accountConfig.isDefaulted.services;

import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaulted;
import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaultedRepository;
import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaultedWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class IsDefaultedReadServiceImpl implements IsDefaultedReadService {
    private final IsDefaultedWrapper isDefaultedWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final IsDefaultedRepository isDefaultedRepository;

    @Override
    public IsDefaulted fetchIsDefaultedById(Integer id) {
        return this.isDefaultedRepository.findById(id).get();
    }

    @Override
    public List<IsDefaulted> fetchActiveIsDefaulted() {
        return this.isDefaultedRepository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<IsDefaulted> fetchDeActiveIsDefaulted() {
        return this.isDefaultedRepository.findByStatus(Status.DELETE);
    }
    @Override
    public List<IsDefaulted> fetchAllIsDefaulted() {
        return this.isDefaultedRepository.findAll();
    }
}
