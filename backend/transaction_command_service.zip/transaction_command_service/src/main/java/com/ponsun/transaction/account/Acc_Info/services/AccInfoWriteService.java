package com.ponsun.transaction.account.Acc_Info.services;

import com.ponsun.transaction.account.Acc_Info.requests.CreateAccInfoRequest;
import com.ponsun.transaction.account.Acc_Info.requests.UpdateAccInfoRequest;

import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccInfoWriteService {
    Response createAccInfo(CreateAccInfoRequest request);
    Response updateAccInfo(Integer id, UpdateAccInfoRequest request);
    Response unblockAccInfo(Integer id);
    Response deactive(Integer id, Integer euid);
}
