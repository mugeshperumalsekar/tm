package com.ponsun.transaction.accountConfig.debtSubType.api;



import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubType;
import com.ponsun.transaction.accountConfig.debtSubType.request.CreateDebtSubTypeRequest;
import com.ponsun.transaction.accountConfig.debtSubType.request.UpdateDebtSubTypeRequest;
import com.ponsun.transaction.accountConfig.debtSubType.services.DebtSubTypeReadService;
import com.ponsun.transaction.accountConfig.debtSubType.services.DebtSubTypeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/DebtSubType")
@Tag(name = "DebtSubTypeApiResource")
public class DebtSubTypeApiResources {
    private final DebtSubTypeWriteService debtSubTypeWriteService;
    private final DebtSubTypeReadService debtSubTypeReadService;

    @PostMapping("/CreateDebtSubTypeRequest")
    public Response saveDebtSubType(@RequestBody CreateDebtSubTypeRequest createDebtSubTypeRequest) {
        log.debug("START saveDebtSubType request body {}",createDebtSubTypeRequest);
        Response response = this.debtSubTypeWriteService.createDebtSubType(createDebtSubTypeRequest);
        log.debug("START saveDebtSubType response",response);
        return response;
    }

    @GetMapping
    public List<DebtSubType> fetchAll() {
        return this.debtSubTypeReadService.fetchAllDebtSubType();
    }

    @GetMapping("/{id}")
    public DebtSubType fetchDebtSubTypeById(@PathVariable(name = "id") Integer id) {
        return this.debtSubTypeReadService.fetchDebtSubTypeById(id);
    }

    @PutMapping("/{id}")
    public Response updateDebtSubType(@PathVariable Integer id, @RequestBody UpdateDebtSubTypeRequest updateDebtSubTypeRequest) {
        log.debug("START updateDebtSubType request body {}",updateDebtSubTypeRequest);
        Response response = this.debtSubTypeWriteService.updateDebtSubType(id, updateDebtSubTypeRequest);
        log.debug("START updateDebtSubType response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockDebtSubType(@PathVariable Integer id){
        Response response = this.debtSubTypeWriteService.unblockDebtSubType(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.debtSubTypeWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<DebtSubType> fetchActiveDebtSubType() {
        return debtSubTypeReadService.fetchActiveDebtSubType();
    }
    @GetMapping("DeActive")
    public List<DebtSubType> fetchDeDebtSubType() {
        return debtSubTypeReadService.fetchDeActiveDebtSubType();
    }
    
}

