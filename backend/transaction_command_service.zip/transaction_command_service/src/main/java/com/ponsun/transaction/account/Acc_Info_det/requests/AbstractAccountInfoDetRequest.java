package com.ponsun.transaction.account.Acc_Info_det.requests;

import lombok.Data;

@Data
public class AbstractAccountInfoDetRequest {
    private Integer id;
    private Integer accountId;
    private String accountNumber;
    private Integer customerId;
    private String accountRisk;
    private String accountRiskEffectiveDate;
    private String accountRiskNextReviewDate;
    private String accountSegment;
    private String accountSegmentEffectiveDate;
    private String accountType;
    private String applicationNumber;
    private String applicationSignedDate;
    private String asOfDate;
    private String bankCode;
    private String bankName;
    private String bankbranchname;
    private String channel;
    private String clientStatus;
    private String creditorBusinessUnit;
    private String creditorRMEmail;
    private String currency;
    private Integer dpid;
    private String fundedType;
    private double grossAnnualPremiumwithTax;
    private double grossAnnualPremiumwithoutTax;
    private String ifscCode;
    private double incomeMultiplier;
    private String insurancePurpose;
    private String intermediaryCode;
    private String introducerEmployeeCode;
    private String micrCode;
    private double modalPremium;
    private String moduleApplicable;
    private String parentCompany;
    private String personalEmail;
    private String personalMobileISD;
    private String personalMobileNumber;
    private String plotnoSurveynoHouseFlatno;
    private String policyEndDate;
    private String policyTerm;
    private String policyType;
    private String rateofInterest;
    private String sanctionDate;
    private Integer securityCount;
    private String securityDetails;
    private double sumAssured;
    private String transactionFrequency;
    private String transactionId;
    private Integer uid;
    private Integer euid;
}
