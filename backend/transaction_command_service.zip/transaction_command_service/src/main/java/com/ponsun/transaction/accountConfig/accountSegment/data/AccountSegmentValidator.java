package com.ponsun.transaction.accountConfig.accountSegment.data;

import com.ponsun.transaction.accountConfig.accountSegment.requests.CreateAccountSegmentRequest;
import com.ponsun.transaction.accountConfig.accountSegment.requests.UpdateAccountSegmentRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AccountSegmentValidator {
    public void validateSaveAccountSegment(final CreateAccountSegmentRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("name parameter required");
        }
    }
    public void validateUpdateAccountSegment(final UpdateAccountSegmentRequest request){
        if(request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("name parameter required");

        }
    }
}
