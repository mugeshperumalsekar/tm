package com.ponsun.transaction.accountConfig.accountSegment.services;

import com.ponsun.transaction.accountConfig.accountSegment.domain.AccountSegment;

import java.util.List;

public interface AccountSegmenttReadService {
    AccountSegment fetchAccountSegmentById(Integer id);

    List<AccountSegment> fetchAllAccountSegment();

    List<AccountSegment> fetchActiveAccountSegment();

    List<AccountSegment> fetchDeActiveAccountSegment();
}
