package com.ponsun.transaction.accountConfig.insurancePurpose.data;



import com.ponsun.transaction.accountConfig.insurancePurpose.request.CreateInsurancePurposeRequest;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.UpdateInsurancePurposeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class InsurancePurposeValidator {
    public void validateSaveInsurancePurpose(final CreateInsurancePurposeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateInsurancePurpose(final UpdateInsurancePurposeRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
