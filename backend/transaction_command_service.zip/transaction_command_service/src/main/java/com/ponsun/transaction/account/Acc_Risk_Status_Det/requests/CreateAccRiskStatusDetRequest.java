package com.ponsun.transaction.account.Acc_Risk_Status_Det.requests;

import lombok.Data;

@Data
public class CreateAccRiskStatusDetRequest extends AbstractAccRiskStatusDetRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
