package com.ponsun.transaction.accountConfig.accountRelation.data;
import lombok.Data;
@Data
public class AccountRelationData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public AccountRelationData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static AccountRelationData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new AccountRelationData(id,name,code,uid,euid);
    }
}

