package com.ponsun.transaction.accountConfig.clientStatus.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface ClientStatusRepository extends JpaRepository<ClientStatus, Integer> {
    Optional<ClientStatus> findById(Integer id);
    List<ClientStatus> findByStatus (Status string);

}