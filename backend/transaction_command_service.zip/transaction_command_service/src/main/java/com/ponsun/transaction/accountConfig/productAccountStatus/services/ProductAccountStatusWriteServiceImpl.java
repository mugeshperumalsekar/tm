package com.ponsun.transaction.accountConfig.productAccountStatus.services;


import com.ponsun.transaction.accountConfig.productAccountStatus.data.ProductAccountStatusValidator;
import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatus;
import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatusRepository;
import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatusWrapper;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.CreateProductAccountStatusRequest;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.UpdateProductAccountStatusRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductAccountStatusWriteServiceImpl implements ProductAccountStatusWriteService {

    private final ProductAccountStatusRepository productAccountStatusRepository;
    private final ProductAccountStatusWrapper productAccountStatusWrapper;
    private final ProductAccountStatusValidator productAccountStatusValidator;

    @Override
    @Transactional
    public Response createProductAccountStatus(CreateProductAccountStatusRequest createProductAccountStatusRequest) {
        try {
            this.productAccountStatusValidator.validateSaveProductAccountStatus(createProductAccountStatusRequest);
            final ProductAccountStatus productAccountStatus = ProductAccountStatus.create(createProductAccountStatusRequest);
            this.productAccountStatusRepository.saveAndFlush(productAccountStatus);
            return Response.of(Long.valueOf(productAccountStatus.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateProductAccountStatus(Integer id, UpdateProductAccountStatusRequest updateProductAccountStatusRequest) {
        try {
            this.productAccountStatusValidator.validateUpdateProductAccountStatus(updateProductAccountStatusRequest);
            final ProductAccountStatus productAccountStatus = this.productAccountStatusWrapper.findOneWithNotFoundDetection(id);
            productAccountStatus.update(updateProductAccountStatusRequest);
            this.productAccountStatusRepository.saveAndFlush(productAccountStatus);
            return Response.of(Long.valueOf(productAccountStatus.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockProductAccountStatus(Integer id) {
        try {
            final ProductAccountStatus productAccountStatus = this.productAccountStatusWrapper.findOneWithNotFoundDetection(id);
            productAccountStatus.setStatus(Status.ACTIVE);
            productAccountStatus.setUpdatedAt(LocalDateTime.now());
            this.productAccountStatusRepository.saveAndFlush(productAccountStatus);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            ProductAccountStatus productAccountStatus = this.productAccountStatusWrapper.findOneWithNotFoundDetection(id);
            productAccountStatus.setEuid(euid);
            productAccountStatus.setStatus(Status.DELETE);
            productAccountStatus.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(productAccountStatus.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
