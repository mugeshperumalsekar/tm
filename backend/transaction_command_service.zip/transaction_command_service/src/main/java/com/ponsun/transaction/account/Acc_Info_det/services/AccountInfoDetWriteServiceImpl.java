package com.ponsun.transaction.account.Acc_Info_det.services;

import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.account.Acc_Info_det.data.AccountInfoDetValidator;
import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDet;
import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDetRepository;
import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDetWrapper;
import com.ponsun.transaction.account.Acc_Info_det.requests.CreateAccountInfoDetRequest;
import com.ponsun.transaction.account.Acc_Info_det.requests.UpdateAccountInfoDetRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountInfoDetWriteServiceImpl implements AccountInfoDetWriteService {
    private final AccountInfoDetRepository repository;
    private final AccountInfoDetWrapper wrapper;
    private final AccountInfoDetValidator validator;
    private final AccInfoWrapper accInfoWrapper;

    @Override
    @Transactional

    public Response createAccountInfoDet(CreateAccountInfoDetRequest request) {
        try {
            this.validator.validateSaveAccountInfoDet(request);

            AccInfo accInfo = accInfoWrapper.findOneWithNotFoundDetection(request.getAccountId());
            if (accInfo == null){
                throw new PS_transaction_ApplicationException("Account information not found for accountId: " + request.getAccountId());
            }

            final AccountInfoDet accountInfoDet = AccountInfoDet.create(request,accInfo);
            this.repository.saveAndFlush(accountInfoDet);
            return Response.of(Long.valueOf(accountInfoDet.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccountInfoDet(Integer id, UpdateAccountInfoDetRequest request) {
        try {
            this.validator.validateUpdateAccountInfoDet(request);
            final AccountInfoDet accountInfoDet = this.wrapper.findOneWithNotFoundDetection(id);
            accountInfoDet.update(request);
            this.repository.saveAndFlush(accountInfoDet);
            return Response.of(Long.valueOf(accountInfoDet.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccountInfoDet(Integer id) {
        try {
            final AccountInfoDet accountInfoDet = this.wrapper.findOneWithNotFoundDetection(id);
            accountInfoDet.setStatus(Status.ACTIVE);
            accountInfoDet.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accountInfoDet);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccountInfoDet AccountInfoDet = this.wrapper.findOneWithNotFoundDetection(id);
            AccountInfoDet.setEuid(euid);
            AccountInfoDet.setStatus(Status.DELETE);
            AccountInfoDet.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(AccountInfoDet);
            return Response.of(Long.valueOf(AccountInfoDet.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }
}
