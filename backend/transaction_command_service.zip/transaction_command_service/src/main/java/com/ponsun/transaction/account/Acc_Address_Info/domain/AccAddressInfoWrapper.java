package com.ponsun.transaction.account.Acc_Address_Info.domain;

import com.ponsun.transaction.account.Acc_Address_Info.requests.AbstractAccAddressInfoRequest;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@RequiredArgsConstructor
public class AccAddressInfoWrapper extends AbstractAccAddressInfoRequest {

    private final AccAddressInfoRepository repository;
    @Transactional
    public AccAddressInfo findOneWithNotFoundDetection (final Integer id) {
        return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("AccAddressInfo Not found " + id));
    }
    @Override
    public String toString(){
        return super.toString();
    }
}
