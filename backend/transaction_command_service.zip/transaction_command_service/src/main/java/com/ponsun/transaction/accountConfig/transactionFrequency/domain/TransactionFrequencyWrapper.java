package com.ponsun.transaction.accountConfig.transactionFrequency.domain;


import com.ponsun.transaction.accountConfig.transactionFrequency.request.AbstractTransactionFrequencyRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class TransactionFrequencyWrapper extends AbstractTransactionFrequencyRequest {
    private final TransactionFrequencyRepository transactionFrequencyRepository;

    @Transactional
    public TransactionFrequency findOneWithNotFoundDetection(final Integer id) {
        return this.transactionFrequencyRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("TransactionFrequency Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }

}

