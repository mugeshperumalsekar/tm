package com.ponsun.transaction.accountConfig.reasonCode.services;


import com.ponsun.transaction.accountConfig.reasonCode.data.ReasonCodeValidator;
import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCode;
import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCodeRepository;
import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCodeWrapper;
import com.ponsun.transaction.accountConfig.reasonCode.request.CreateReasonCodeRequest;
import com.ponsun.transaction.accountConfig.reasonCode.request.UpdateReasonCodeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReasonCodeWriteServiceImpl implements ReasonCodeWriteService {

    private final ReasonCodeRepository reasonCodeRepository;
    private final ReasonCodeWrapper reasonCodeWrapper;
    private final ReasonCodeValidator reasonCodeValidator;

    @Override
    @Transactional
    public Response createReasonCode(CreateReasonCodeRequest createReasonCodeRequest) {
        try {
            this.reasonCodeValidator.validateSaveReasonCode(createReasonCodeRequest);
            final ReasonCode reasonCode = ReasonCode.create(createReasonCodeRequest);
            this.reasonCodeRepository.saveAndFlush(reasonCode);
            return Response.of(Long.valueOf(reasonCode.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateReasonCode(Integer id, UpdateReasonCodeRequest updateReasonCodeRequest) {
        try {
            this.reasonCodeValidator.validateUpdateReasonCode(updateReasonCodeRequest);
            final ReasonCode reasonCode = this.reasonCodeWrapper.findOneWithNotFoundDetection(id);
            reasonCode.update(updateReasonCodeRequest);
            this.reasonCodeRepository.saveAndFlush(reasonCode);
            return Response.of(Long.valueOf(reasonCode.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockReasonCode(Integer id) {
        try {
            final ReasonCode reasonCode = this.reasonCodeWrapper.findOneWithNotFoundDetection(id);
            reasonCode.setStatus(Status.ACTIVE);
            reasonCode.setUpdatedAt(LocalDateTime.now());
            this.reasonCodeRepository.saveAndFlush(reasonCode);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            ReasonCode reasonCode = this.reasonCodeWrapper.findOneWithNotFoundDetection(id);
            reasonCode.setEuid(euid);
            reasonCode.setStatus(Status.DELETE);
            reasonCode.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(reasonCode.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
