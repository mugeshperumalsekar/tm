package com.ponsun.transaction.account.Acc_Holder_Details.requests;

import lombok.Data;

@Data
public class AbstractAccHolderDetailsRequest {
    private Integer id;
    private Integer customerId;
    private String borrowerDetails;
    private String branchReceiptDate;
    private String dateofDefault;
    private String dateofFilingofSuit;
    private String dateofLastRepayment;
    private String debtSubType;
    private double defaultAmount;
    private String defaultRemarks;
    private String disbursementDate;
    private double drawingPower;
    private double emiAmount;
    private String finalEMIDate;
    private String firstHolderRecordIdentifier;
    private String firstHolderRelation;
    private String firstHolderSourceSystemCustomerCode;
    private String firstHolderSourceSystemName;
    private String firstPremiumReceiptDate;
    private double interestOutstanding;
    private String isDefaulted;
    private String isFamilyDeclaration;
    private String isWhiteListed;
    private String lendingArrangement;
    private String loginDate;
    private String natureofCredit;
    private double networthMultiplier;
    private String oldProductAccountNumber;
    private String preferredtransactionmode;
    private Integer relatedPartyCount;
    private String remarks;
    private Integer riskCommencementDate;
    private double sanctionedAmount;
    private String secondHolderFirstname;
    private String secondHolderMiddlename;
    private String secondHolderLastname;
    private String secondHolderPan;
    private String thirdHolderFirstname;
    private String thirdHolderMiddlename;
    private String thirdHolderLastname;
    private String thirdHolderPan;
    private double totalOutstandingAmount;
    private Integer accountId;
    private Integer uid;
    private Integer euid;
}
