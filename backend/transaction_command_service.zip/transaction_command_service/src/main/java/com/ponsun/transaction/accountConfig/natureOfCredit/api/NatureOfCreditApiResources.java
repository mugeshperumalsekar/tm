package com.ponsun.transaction.accountConfig.natureOfCredit.api;



import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCredit;
import com.ponsun.transaction.accountConfig.natureOfCredit.request.CreateNatureOfCreditRequest;
import com.ponsun.transaction.accountConfig.natureOfCredit.request.UpdateNatureOfCreditRequest;
import com.ponsun.transaction.accountConfig.natureOfCredit.services.NatureOfCreditReadService;
import com.ponsun.transaction.accountConfig.natureOfCredit.services.NatureOfCreditWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/NatureOfCredit")
@Tag(name = "NatureOfCreditApiResource")
public class NatureOfCreditApiResources {
    private final NatureOfCreditWriteService natureOfCreditWriteService;
    private final NatureOfCreditReadService natureOfCreditReadService;

    @PostMapping("/CreateNatureOfCreditRequest")
    public Response saveNatureOfCredit(@RequestBody CreateNatureOfCreditRequest createNatureOfCreditRequest) {
        log.debug("START saveNatureOfCredit request body {}",createNatureOfCreditRequest);
        Response response = this.natureOfCreditWriteService.createNatureOfCredit(createNatureOfCreditRequest);
        log.debug("START saveNatureOfCredit response",response);
        return response;
    }

    @GetMapping
    public List<NatureOfCredit> fetchAll() {
        return this.natureOfCreditReadService.fetchAllNatureOfCredit();
    }

    @GetMapping("/{id}")
    public NatureOfCredit fetchNatureOfCreditById(@PathVariable(name = "id") Integer id) {
        return this.natureOfCreditReadService.fetchNatureOfCreditById(id);
    }

    @PutMapping("/{id}")
    public Response updateNatureOfCredit(@PathVariable Integer id, @RequestBody UpdateNatureOfCreditRequest updateNatureOfCreditRequest) {
        log.debug("START updateNatureOfCredit request body {}",updateNatureOfCreditRequest);
        Response response = this.natureOfCreditWriteService.updateNatureOfCredit(id, updateNatureOfCreditRequest);
        log.debug("START updateNatureOfCredit response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockNatureOfCredit(@PathVariable Integer id){
        Response response = this.natureOfCreditWriteService.unblockNatureOfCredit(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.natureOfCreditWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<NatureOfCredit> fetchActiveNatureOfCredit() {
        return natureOfCreditReadService.fetchActiveNatureOfCredit();
    }
    @GetMapping("DeActive")
    public List<NatureOfCredit> fetchDeNatureOfCredit() {
        return natureOfCreditReadService.fetchDeActiveNatureOfCredit();
    }
    
}

