package com.ponsun.transaction.accountConfig.productAccountStatus.services;

import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatus;

import java.util.List;

public interface ProductAccountStatusReadService {
    List<ProductAccountStatus> fetchAllProductAccountStatus();

    ProductAccountStatus fetchProductAccountStatusById(Integer id);

    List<ProductAccountStatus> fetchActiveProductAccountStatus();

    List<ProductAccountStatus> fetchDeActiveProductAccountStatus();
}
