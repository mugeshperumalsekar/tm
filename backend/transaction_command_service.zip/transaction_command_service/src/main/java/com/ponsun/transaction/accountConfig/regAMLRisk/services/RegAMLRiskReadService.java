package com.ponsun.transaction.accountConfig.regAMLRisk.services;

import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRisk;

import java.util.List;

public interface RegAMLRiskReadService {
    List<RegAMLRisk> fetchAllRegAMLRisk();

    RegAMLRisk fetchRegAMLRiskById(Integer id);

    List<RegAMLRisk> fetchActiveRegAMLRisk();

    List<RegAMLRisk> fetchDeActiveRegAMLRisk();
}
