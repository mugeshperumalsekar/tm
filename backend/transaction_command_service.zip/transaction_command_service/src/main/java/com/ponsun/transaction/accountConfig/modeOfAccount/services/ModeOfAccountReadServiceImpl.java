package com.ponsun.transaction.accountConfig.modeOfAccount.services;


import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccount;
import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccountRepository;
import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccountWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ModeOfAccountReadServiceImpl implements ModeOfAccountReadService {
    private final ModeOfAccountWrapper modeOfAccountWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final ModeOfAccountRepository modeOfAccountRepository;

    @Override
    public ModeOfAccount fetchModeOfAccountById(Integer id) {
        return this.modeOfAccountRepository.findById(id).get();
    }

    @Override
    public List<ModeOfAccount> fetchActiveType() {
        return this.modeOfAccountRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<ModeOfAccount> fetchDeActiveType() {
        return this.modeOfAccountRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<ModeOfAccount> fetchAllModeOfAccount() {
        return this.modeOfAccountRepository.findAll();
    }
}
