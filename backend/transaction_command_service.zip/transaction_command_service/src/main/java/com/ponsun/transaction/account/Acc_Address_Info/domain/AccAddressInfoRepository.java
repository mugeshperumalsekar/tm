package com.ponsun.transaction.account.Acc_Address_Info.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccAddressInfoRepository extends JpaRepository<AccAddressInfo,Integer> {
    List<AccAddressInfo> findByStatus(Status string);

}
