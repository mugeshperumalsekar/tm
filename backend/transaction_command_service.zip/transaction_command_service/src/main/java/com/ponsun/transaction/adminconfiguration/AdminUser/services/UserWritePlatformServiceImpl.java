package com.ponsun.transaction.adminconfiguration.AdminUser.services;

import com.ponsun.transaction.adminconfiguration.AdminUser.data.UserDataValidator;
import com.ponsun.transaction.adminconfiguration.AdminUser.domain.User;
import com.ponsun.transaction.adminconfiguration.AdminUser.domain.UserRepository;
import com.ponsun.transaction.adminconfiguration.AdminUser.domain.UserRepositoryWrapper;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.CreateUserRequest;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.LoginUserDto;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.UpdateUserRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import com.ponsun.transaction.master.role.domain.Role;
import com.ponsun.transaction.master.role.domain.RoleWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserWritePlatformServiceImpl implements UserWritePlatformService  {

    private final UserRepository userRepository;
    private final UserRepositoryWrapper userRepositoryWrapper;
    private final UserDataValidator userDataValidator;
    private final RoleWrapper roleWrapper;
    private final AuthenticationManager authenticationManager;

    @Override
    @Transactional
    public Response createUser(CreateUserRequest createUserRequest) {
        try {
         this.userDataValidator.validateSaveModuleDet(createUserRequest);
         final Role role = roleWrapper.findOneWithNotFoundDetection((createUserRequest.getRoleId()));
            final User user = User.create(createUserRequest, role);
            this.userRepository.saveAndFlush(user);
            return Response.of(Long.valueOf(user.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    public User authenticate(LoginUserDto input) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        input.getEmail(),
                        input.getPassword()
                )
        );

        if (authentication.isAuthenticated()) {
            return userRepository.findByEmail(input.getEmail())
                    .orElseThrow(() -> new RuntimeException("User not found"));
        } else {
            throw new RuntimeException("Authentication failed");
        }
    }

    @Override
    @Transactional
    public Response updateUser(Integer id, UpdateUserRequest updateUserRequest) {
        try {
            this.userDataValidator.validateUpdateModuleDet(updateUserRequest);
            final Role role = roleWrapper.findOneWithNotFoundDetection((updateUserRequest.getRoleId()));
            final User user = this.userRepositoryWrapper.findOneWithNotFoundDetection(id);
            user.update(updateUserRequest, role);
             this.userRepository.saveAndFlush(user);
            return Response.of(Long.valueOf(user.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response blockUser(Integer id) {
        try {
            final User user = this.userRepositoryWrapper.findOneWithNotFoundDetection(id);
            user.setStatus(Status.DELETE);
            user.setUpdatedAt(LocalDateTime.now());
            this.userRepository.saveAndFlush(user);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }


    @Override
    @Transactional
    public Response unblockUser(Integer id) {
        try {
            final User user = this.userRepositoryWrapper.findOneWithNotFoundDetection(id);
            user.setStatus(Status.ACTIVE);
            user.setUpdatedAt(LocalDateTime.now());
            this.userRepository.saveAndFlush(user);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

}
