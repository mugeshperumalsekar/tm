package com.ponsun.transaction.accountConfig.modeOfAccount.domain;

import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.customerConfig.tmConfigCountry.domain.TmConfigCountry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ModeOfAccountRepository extends JpaRepository<ModeOfAccount, Integer> {
    Optional<ModeOfAccount> findById(Integer id);

    List<ModeOfAccount> findByStatus (Status string);

    @Query("SELECT x FROM ModeOfAccount x WHERE x.id IN :ids")
    List<ModeOfAccount> findModeOfAccountByIds(@Param("ids") List<Integer> ids);



}