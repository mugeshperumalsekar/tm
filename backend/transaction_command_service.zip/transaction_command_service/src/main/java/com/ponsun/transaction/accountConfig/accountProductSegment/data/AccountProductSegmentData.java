package com.ponsun.transaction.accountConfig.accountProductSegment.data;

import lombok.Data;

@Data
public class AccountProductSegmentData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;

    public AccountProductSegmentData(Integer id, String name, String code, Integer uid, Integer euid) {
        this.id = id;
        this.name = name;
        this.code = code;
        this.uid = uid;
        this.euid = euid;
    }
    public static AccountProductSegmentData newInstance(Integer id, String name, String code, Integer uid, Integer euid){
        return new AccountProductSegmentData(id,name,code,uid,euid);
    }
}
