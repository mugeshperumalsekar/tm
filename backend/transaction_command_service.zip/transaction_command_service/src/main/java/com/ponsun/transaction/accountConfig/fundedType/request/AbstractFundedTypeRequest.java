package com.ponsun.transaction.accountConfig.fundedType.request;

import lombok.Data;

@Data
public class AbstractFundedTypeRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
