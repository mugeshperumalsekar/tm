package com.ponsun.transaction.accountConfig.policyType.services;

import com.ponsun.transaction.accountConfig.policyType.domain.PolicyType;
import com.ponsun.transaction.accountConfig.policyType.domain.PolicyTypeRepository;
import com.ponsun.transaction.accountConfig.policyType.domain.PolicyTypeWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PolicyTypeReadServiceImpl implements PolicyTypeReadService {
    private final PolicyTypeWrapper policyTypeWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final PolicyTypeRepository policyTypeRepository;

    @Override
    public PolicyType fetchPolicyTypeById(Integer id) {
        return this.policyTypeRepository.findById(id).get();
    }

    @Override
    public List<PolicyType> fetchActivePolicyType() {
        return this.policyTypeRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<PolicyType> fetchDeActivePolicyType() {
        return this.policyTypeRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<PolicyType> fetchAllPolicyType() {
        return this.policyTypeRepository .findAll();
    }
}
