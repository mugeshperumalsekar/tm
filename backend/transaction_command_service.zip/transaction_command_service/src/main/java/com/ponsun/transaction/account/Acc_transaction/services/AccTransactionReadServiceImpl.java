package com.ponsun.transaction.account.Acc_transaction.services;
import com.ponsun.transaction.account.Acc_transaction.data.AccTransactionData;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransaction;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransactionRepository;
import com.ponsun.transaction.account.Acc_transaction.rowmapper.AccTransactionRowMapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccTransactionReadServiceImpl implements AccTransactionReadService {
    private final AccTransactionRepository repository;
    private final JdbcTemplate jdbcTemplate;
    private final AccTransactionRowMapper accTransactionRowMapper;

    @Override
    @Transactional
    public AccTransaction fetchAccTransactionById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccTransaction> fetchAllAccTransaction() {
        return this.repository.findAll();
    }

    @Override
    public List<AccTransaction> fetchActiveAccTransaction() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccTransaction> fetchDeActiveAccTransaction() {
        return repository.findByStatus(Status.DELETE);
    }
    @Override
    public List<AccTransactionData> fetchAllTransactionGroupByAccountId(){
                String qry = "SELECT " + accTransactionRowMapper.tableSchema() +
                        " WHERE act.isCalc = 0 AND act.status = 'A' AND act.accountId = accountId" +
                        " GROUP BY act.accountId, it.trans_type, act.type2Id";

        return jdbcTemplate.query(qry, accTransactionRowMapper);
    }

    @Override
    public void Iscalc(Integer id){
        String qry = "UPDATE `tm_acc_transaction` SET is_calc = 1 WHERE is_calc = 0 AND id = ?";

        int rowsAffected = jdbcTemplate.update(qry, id);
//        System.out.println("Updated " + rowsAffected + " rows.");
    }
}
