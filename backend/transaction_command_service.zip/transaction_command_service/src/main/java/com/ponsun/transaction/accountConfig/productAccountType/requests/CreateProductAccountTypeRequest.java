package com.ponsun.transaction.accountConfig.productAccountType.requests;

import lombok.Data;

@Data
public class CreateProductAccountTypeRequest extends AbstractProductAccountTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
