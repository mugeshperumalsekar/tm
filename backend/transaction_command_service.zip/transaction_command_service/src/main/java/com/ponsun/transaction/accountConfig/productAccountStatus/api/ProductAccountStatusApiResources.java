package com.ponsun.transaction.accountConfig.productAccountStatus.api;


import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatus;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.CreateProductAccountStatusRequest;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.UpdateProductAccountStatusRequest;
import com.ponsun.transaction.accountConfig.productAccountStatus.services.ProductAccountStatusReadService;
import com.ponsun.transaction.accountConfig.productAccountStatus.services.ProductAccountStatusWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/ProductAccountStatus")
@Tag(name = "ProductAccountStatusApiResource")
public class ProductAccountStatusApiResources {
    private final ProductAccountStatusWriteService productAccountStatusWriteService;
    private final ProductAccountStatusReadService productAccountStatusReadService;

    @PostMapping("/CreateProductAccountStatusRequest")
    public Response saveProductAccountStatus(@RequestBody CreateProductAccountStatusRequest createProductAccountStatusRequest) {
        log.debug("START saveProductAccountStatus request body {}",createProductAccountStatusRequest);
        Response response = this.productAccountStatusWriteService.createProductAccountStatus(createProductAccountStatusRequest);
        log.debug("START saveProductAccountStatus response",response);
        return response;
    }

    @GetMapping
    public List<ProductAccountStatus> fetchAll() {
        return this.productAccountStatusReadService.fetchAllProductAccountStatus();
    }

    @GetMapping("/{id}")
    public ProductAccountStatus fetchProductAccountStatusById(@PathVariable(name = "id") Integer id) {
        return this.productAccountStatusReadService.fetchProductAccountStatusById(id);
    }

    @PutMapping("/{id}")
    public Response updateProductAccountStatus(@PathVariable Integer id, @RequestBody UpdateProductAccountStatusRequest updateProductAccountStatusRequest) {
        log.debug("START updateProductAccountStatus request body {}",updateProductAccountStatusRequest);
        Response response = this.productAccountStatusWriteService.updateProductAccountStatus(id, updateProductAccountStatusRequest);
        log.debug("START updateProductAccountStatus response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockProductAccountStatus(@PathVariable Integer id){
        Response response = this.productAccountStatusWriteService.unblockProductAccountStatus(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.productAccountStatusWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<ProductAccountStatus> fetchActiveProductAccountStatus() {
        return productAccountStatusReadService.fetchActiveProductAccountStatus();
    }
    @GetMapping("DeActive")
    public List<ProductAccountStatus> fetchDeProductAccountStatus() {
        return productAccountStatusReadService.fetchDeActiveProductAccountStatus();
    }
}

