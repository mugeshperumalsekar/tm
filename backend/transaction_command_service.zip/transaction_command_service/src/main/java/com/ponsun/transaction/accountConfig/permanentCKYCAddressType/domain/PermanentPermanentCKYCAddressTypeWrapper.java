package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.AbstractPermanentCKYCAddressTypeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PermanentPermanentCKYCAddressTypeWrapper extends AbstractPermanentCKYCAddressTypeRequest {

    private final PermanentCKYCAddressTypeRepository repository;

    @Transactional
    public PermanentCKYCAddressType findOneWithNotFoundDetection (final Integer id) {
    return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("PermanentCKYCAddressType Not found " + id));
}
    @Override
    public String toString(){
        return super.toString();
    }

}
