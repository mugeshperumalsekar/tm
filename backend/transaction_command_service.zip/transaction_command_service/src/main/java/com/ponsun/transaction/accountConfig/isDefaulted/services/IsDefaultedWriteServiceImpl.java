package com.ponsun.transaction.accountConfig.isDefaulted.services;


import com.ponsun.transaction.accountConfig.isDefaulted.data.IsDefaultedValidator;
import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaulted;
import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaultedRepository;
import com.ponsun.transaction.accountConfig.isDefaulted.domain.IsDefaultedWrapper;
import com.ponsun.transaction.accountConfig.isDefaulted.request.CreateIsDefaultedRequest;
import com.ponsun.transaction.accountConfig.isDefaulted.request.UpdateIsDefaultedRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class IsDefaultedWriteServiceImpl implements IsDefaultedWriteService {

    private final IsDefaultedRepository isDefaultedRepository;
    private final IsDefaultedWrapper isDefaultedWrapper;
    private final IsDefaultedValidator isDefaultedValidator;
    @Override
    @Transactional
    public Response createIsDefaulted(CreateIsDefaultedRequest createIsDefaultedRequest) {
        try {
            this.isDefaultedValidator.validateSaveIsDefaulted(createIsDefaultedRequest);
            final IsDefaulted isDefaulted = IsDefaulted.create(createIsDefaultedRequest);
            this.isDefaultedRepository.saveAndFlush(isDefaulted);
            return Response.of(Long.valueOf(isDefaulted.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
    @Override
    @Transactional
    public Response updateIsDefaulted(Integer id, UpdateIsDefaultedRequest updateIsDefaultedRequest) {
        try {
            this.isDefaultedValidator.validateUpdateIsDefaulted(updateIsDefaultedRequest);
            final IsDefaulted isDefaulted = this.isDefaultedWrapper.findOneWithNotFoundDetection(id);
            isDefaulted.update(updateIsDefaultedRequest);
            this.isDefaultedRepository.saveAndFlush(isDefaulted);
            return Response.of(Long.valueOf(isDefaulted.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
    @Override
    @Transactional
    public Response unblockIsDefaulted(Integer id) {
        try {
            final IsDefaulted isDefaulted = this.isDefaultedWrapper.findOneWithNotFoundDetection(id);
            isDefaulted.setStatus(Status.ACTIVE);
            isDefaulted.setUpdatedAt(LocalDateTime.now());
            this.isDefaultedRepository.saveAndFlush(isDefaulted);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            IsDefaulted isDefaulted = this.isDefaultedWrapper.findOneWithNotFoundDetection(id);
            isDefaulted.setEuid(euid);
            isDefaulted.setStatus(Status.DELETE);
            isDefaulted.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(isDefaulted.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
