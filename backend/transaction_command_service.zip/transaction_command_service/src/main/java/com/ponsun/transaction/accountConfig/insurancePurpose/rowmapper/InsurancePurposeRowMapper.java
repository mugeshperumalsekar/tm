package com.ponsun.transaction.accountConfig.insurancePurpose.rowmapper;

public class InsurancePurposeRowMapper {
}
