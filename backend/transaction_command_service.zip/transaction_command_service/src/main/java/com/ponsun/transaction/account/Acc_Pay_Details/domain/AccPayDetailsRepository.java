package com.ponsun.transaction.account.Acc_Pay_Details.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccPayDetailsRepository extends JpaRepository<AccPayDetails,Integer> {
    List<AccPayDetails> findByStatus(Status string);

}
