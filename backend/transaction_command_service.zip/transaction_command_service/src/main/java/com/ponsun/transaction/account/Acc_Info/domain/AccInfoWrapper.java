package com.ponsun.transaction.account.Acc_Info.domain;

import com.ponsun.transaction.account.Acc_Info.requests.AbstractAccInfoRequest;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AccInfoWrapper extends AbstractAccInfoRequest {

    private final AccInfoRepository repository;
    @Transactional
    public AccInfo findOneWithNotFoundDetection (final Integer id) {
        return this.repository.findById(id).orElse(null);//.orElseThrow(() -> new EntityNotFoundException("AccInfo Not found " + id));
    }

    @Transactional
    public List<AccInfo> fetchAll () {
        return this.repository.findAll();
    }

    @Override
    public String toString(){
        return super.toString();
    }
}
