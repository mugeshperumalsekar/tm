package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.services;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.UpdatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.data.PermanentCKYCAddressTypeValidator;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentCKYCAddressTypeRepository;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentPermanentCKYCAddressTypeWrapper;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentCKYCAddressType;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.CreatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class PermanentCKYCAddressTypeWriteServiceImpl implements PermanentCKYCAddressTypeWriteService {
    private final PermanentCKYCAddressTypeRepository repository;
    private final PermanentPermanentCKYCAddressTypeWrapper wrapper;
    private final PermanentCKYCAddressTypeValidator validator;

    @Override
    @Transactional
    public Response createAccAddressType(CreatePermanentCKYCAddressTypeRequest request) {
        try {
            this.validator.validateSaveAccAddressType(request);
            final PermanentCKYCAddressType addressType = PermanentCKYCAddressType.create(request);
            this.repository.saveAndFlush(addressType);
            return Response.of(Long.valueOf(addressType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response updateAccAddressType(Integer id, UpdatePermanentCKYCAddressTypeRequest request) {
        try {
            this.validator.validateUpdateAccAddressType(request);
            final PermanentCKYCAddressType addressType = this.wrapper.findOneWithNotFoundDetection(id);
            addressType.update(request);
            this.repository.saveAndFlush(addressType);
            return Response.of(Long.valueOf(addressType.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccAddressType(Integer id) {
        try {
            final PermanentCKYCAddressType addressType = this.wrapper.findOneWithNotFoundDetection(id);
            addressType.setStatus(Status.ACTIVE);
            addressType.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(addressType);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid){
        try{
            PermanentCKYCAddressType addressType = this.wrapper.findOneWithNotFoundDetection(id);
            addressType.setEuid(euid);
            addressType.setStatus(Status.DELETE);
            addressType.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(addressType);
            return Response.of(Long.valueOf(addressType.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

}
