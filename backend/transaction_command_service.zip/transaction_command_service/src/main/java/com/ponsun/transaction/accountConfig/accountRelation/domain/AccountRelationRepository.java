package com.ponsun.transaction.accountConfig.accountRelation.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AccountRelationRepository extends JpaRepository<AccountRelation, Integer> {
    Optional<AccountRelation> findById(Integer id);

    List<AccountRelation> findByStatus(Status string);

}