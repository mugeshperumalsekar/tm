package com.ponsun.transaction.account.Acc_Holder_Details.requests;

import lombok.Data;

@Data
public class CreateAccHolderDetailsRequest extends AbstractAccHolderDetailsRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
