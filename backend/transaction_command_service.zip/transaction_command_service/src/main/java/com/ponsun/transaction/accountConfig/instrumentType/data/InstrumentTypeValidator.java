package com.ponsun.transaction.accountConfig.instrumentType.data;

import com.ponsun.transaction.accountConfig.instrumentType.requests.CreateInstrumentTypeRequest;
import com.ponsun.transaction.accountConfig.instrumentType.requests.UpdateInstrumentTypeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class InstrumentTypeValidator {
    public void validateSaveInstrumentType(final CreateInstrumentTypeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("name parameter required");
        }
    }
    public void validateUpdateInstrumentType(final UpdateInstrumentTypeRequest request){
        if(request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("name parameter required");

        }
    }
}
