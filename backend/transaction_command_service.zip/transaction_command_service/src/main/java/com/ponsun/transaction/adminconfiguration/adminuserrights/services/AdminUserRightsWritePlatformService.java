package com.ponsun.transaction.adminconfiguration.adminuserrights.services;

import com.ponsun.transaction.adminconfiguration.adminuserrights.data.AdminUserRightsDTO;
import com.ponsun.transaction.adminconfiguration.adminuserrights.request.UpdateAdminUserRightsRequest;
import com.ponsun.transaction.infrastructure.utils.Response;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface AdminUserRightsWritePlatformService {

    @Transactional
    List<String> createAdminUserRights(List<AdminUserRightsDTO> createAdminUserRightsRequests);

    Response updateAdminUserRights(Integer id, UpdateAdminUserRightsRequest updateAdminUserRightsRequest);

    Response blockAdminUserRights(Integer id);
    Response unblockAdminUserRights(Integer id);
}
