package com.ponsun.transaction.accountConfig.natureOfCredit.services;

import com.ponsun.transaction.accountConfig.natureOfCredit.request.CreateNatureOfCreditRequest;
import com.ponsun.transaction.accountConfig.natureOfCredit.request.UpdateNatureOfCreditRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface NatureOfCreditWriteService {
    Response createNatureOfCredit(CreateNatureOfCreditRequest createNatureOfCreditRequest);

    Response updateNatureOfCredit(Integer id, UpdateNatureOfCreditRequest updateNatureOfCreditRequest);

    Response unblockNatureOfCredit(Integer id);

    Response deActivate(Integer id, Integer euid);
}
