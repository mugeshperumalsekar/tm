package com.ponsun.transaction.accountConfig.accountProductSegment.domain;

import com.ponsun.transaction.accountConfig.accountProductSegment.requests.UpdateAccountProductSegmentRequest;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.CreateAccountProductSegmentRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_account_product_segment")
public class AccountProductSegment extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccountProductSegment create(final CreateAccountProductSegmentRequest request) {
        final AccountProductSegment accountProductSegment = new AccountProductSegment();
        accountProductSegment.setName(request.getName());
        accountProductSegment.setCode(request.getCode());
        accountProductSegment.setUid(request.getUid());
        accountProductSegment.setEuid(request.getEuid());
        accountProductSegment.setStatus(Status.ACTIVE);
        accountProductSegment.setCreatedAt(LocalDateTime.now());
        return accountProductSegment;
    }

    public void update(final UpdateAccountProductSegmentRequest request) {
        this.setName(request.getName());
        this.setCode(request.getCode());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}
