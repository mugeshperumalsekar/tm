package com.ponsun.transaction.accountConfig.fundedType.data;


import com.ponsun.transaction.accountConfig.fundedType.request.CreateFundedTypeRequest;
import com.ponsun.transaction.accountConfig.fundedType.request.UpdateFundedTypeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class FundedTypeValidator {
    public void validateSaveFundedType(final CreateFundedTypeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateFundedType(final UpdateFundedTypeRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
