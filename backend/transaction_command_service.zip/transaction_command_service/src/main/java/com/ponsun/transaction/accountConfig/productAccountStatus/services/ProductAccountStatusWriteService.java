package com.ponsun.transaction.accountConfig.productAccountStatus.services;

import com.ponsun.transaction.accountConfig.productAccountStatus.request.CreateProductAccountStatusRequest;
import com.ponsun.transaction.accountConfig.productAccountStatus.request.UpdateProductAccountStatusRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface ProductAccountStatusWriteService {
    Response createProductAccountStatus(CreateProductAccountStatusRequest createProductAccountStatusRequest);

    Response updateProductAccountStatus(Integer id, UpdateProductAccountStatusRequest updateProductAccountStatusRequest);

    Response unblockProductAccountStatus(Integer id);

    Response deActivate(Integer id, Integer euid);
}
