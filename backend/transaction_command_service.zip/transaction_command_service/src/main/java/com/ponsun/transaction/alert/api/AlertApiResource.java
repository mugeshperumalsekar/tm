package com.ponsun.transaction.alert.api;


import com.ponsun.transaction.alert.domain.Alert;
import com.ponsun.transaction.alert.request.CreateAlertRequest;
import com.ponsun.transaction.alert.request.UpdateAlertRequest;
import com.ponsun.transaction.alert.services.AlertReadPlatformService;
import com.ponsun.transaction.alert.services.AlertWritePlatformService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/Alert")
@Tag(name = "AlertApiResource")
public class AlertApiResource {

    private final AlertWritePlatformService alertWritePlatformService;
    private final AlertReadPlatformService alertReadPlatformService;

    @PostMapping("/CreateAlertRequest")
    public Response saveAlert(@RequestBody CreateAlertRequest createAlertRequest) {
        log.debug("START saveAlert request body {}", createAlertRequest);
        Response response = this.alertWritePlatformService.createAlert(createAlertRequest);
        log.debug("START saveAlert request body {}", createAlertRequest);
        return response;
    }

    @GetMapping
    public List<Alert> fetchAllAlert() {
        return this.alertReadPlatformService.fetchAllAlert();
    }

    @GetMapping("/{id}")
    public Alert fetchAlertById(@PathVariable(name = "id") Integer id) {
        return this.alertReadPlatformService.fetchAlertById(id);
    }

    @PutMapping("/{id}")
    public Response updateAlert(@PathVariable Integer id, @RequestBody UpdateAlertRequest updateAlertRequest) {
        log.debug("UPDATE saveAlert request body {}", updateAlertRequest);
        Response response = this.alertWritePlatformService.updateAlert(id, updateAlertRequest);
        log.debug("UPDATE saveAlert request body {}", updateAlertRequest);

        return response;
    }

    @PutMapping("/{id}/block")
    public Response blockAlert(@PathVariable Integer id) {
        Response response = this.alertWritePlatformService.blockAlert(id);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAlert(@PathVariable Integer id) {
        Response response = this.alertWritePlatformService.unblockAlert(id);
        return response;
    }
}
