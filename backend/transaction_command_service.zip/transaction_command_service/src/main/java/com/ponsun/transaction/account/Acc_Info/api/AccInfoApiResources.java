package com.ponsun.transaction.account.Acc_Info.api;

import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.requests.CreateAccInfoRequest;
import com.ponsun.transaction.account.Acc_Info.requests.UpdateAccInfoRequest;
import com.ponsun.transaction.account.Acc_Info.services.AccInfoReadService;
import com.ponsun.transaction.account.Acc_Info.services.AccInfoWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccInfo")
@Tag(name = "AccInfoApiResources")
public class AccInfoApiResources {
    private final AccInfoWriteService writeService;
    private final AccInfoReadService readService;

    @PostMapping("/CreateAccInfoRequest")
    public Response createAccInfo(@RequestBody CreateAccInfoRequest request) {
        Response response = this.writeService.createAccInfo(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccInfo(@PathVariable Integer id, @RequestBody UpdateAccInfoRequest request) {
        Response response = this.writeService.updateAccInfo(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccInfo fetchAccInfoById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccInfoById(id);
    }
    @GetMapping
    public List<AccInfo> fetchAll() {
        return this.readService.fetchAllAccInfo();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccInfo(@PathVariable Integer id){
        Response response = this.writeService.unblockAccInfo(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccInfo> fetchActiveAccInfo() {
        return readService.fetchActiveAccInfo();
    }

    @GetMapping("DeActive")
    public List<AccInfo> fetchDeAccInfo() {
        return readService.fetchDeActiveAccInfo();
    }

}
