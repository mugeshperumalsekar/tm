package com.ponsun.transaction.accountConfig.clientStatus.services;

import com.ponsun.transaction.accountConfig.clientStatus.request.CreateClientStatusRequest;
import com.ponsun.transaction.accountConfig.clientStatus.request.UpdateClientStatusRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface ClientStatusWriteService {
    Response createClientStatus(CreateClientStatusRequest createClientStatusRequest);

    Response updateClientStatus(Integer id, UpdateClientStatusRequest updateClientStatusRequest);

    Response unblockClientStatus(Integer id);

    Response deActivate(Integer id, Integer euid);
}
