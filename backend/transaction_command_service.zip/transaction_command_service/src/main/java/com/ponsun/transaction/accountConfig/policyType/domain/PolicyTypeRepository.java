package com.ponsun.transaction.accountConfig.policyType.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PolicyTypeRepository extends JpaRepository<PolicyType, Integer> {
    Optional<PolicyType> findById(Integer id);

    List<PolicyType> findByStatus (Status string);

}