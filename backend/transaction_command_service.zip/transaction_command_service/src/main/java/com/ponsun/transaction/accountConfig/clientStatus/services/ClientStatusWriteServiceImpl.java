package com.ponsun.transaction.accountConfig.clientStatus.services;


import com.ponsun.transaction.accountConfig.clientStatus.request.CreateClientStatusRequest;
import com.ponsun.transaction.accountConfig.clientStatus.data.ClientStatusValidator;
import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatus;
import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatusRepository;
import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatusWrapper;
import com.ponsun.transaction.accountConfig.clientStatus.request.UpdateClientStatusRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClientStatusWriteServiceImpl implements ClientStatusWriteService {

    private final ClientStatusRepository clientStatusRepository;
    private final ClientStatusWrapper clientStatusWrapper;
    private final ClientStatusValidator clientStatusValidator;

    @Override
    @Transactional
    public Response createClientStatus(CreateClientStatusRequest createClientStatusRequest) {
        try {
            this.clientStatusValidator.validateSaveClientStatus(createClientStatusRequest);
            final ClientStatus clientStatus = ClientStatus.create(createClientStatusRequest);
            this.clientStatusRepository.saveAndFlush(clientStatus);
            return Response.of(Long.valueOf(clientStatus.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateClientStatus(Integer id, UpdateClientStatusRequest updateClientStatusRequest) {
        try {
            this.clientStatusValidator.validateUpdateClientStatus(updateClientStatusRequest);
            final ClientStatus clientStatus = this.clientStatusWrapper.findOneWithNotFoundDetection(id);
            clientStatus.update(updateClientStatusRequest);
            this.clientStatusRepository.saveAndFlush(clientStatus);
            return Response.of(Long.valueOf(clientStatus.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockClientStatus(Integer id) {
        try {
            final ClientStatus clientStatus = this.clientStatusWrapper.findOneWithNotFoundDetection(id);
            clientStatus.setStatus(Status.ACTIVE);
            clientStatus.setUpdatedAt(LocalDateTime.now());
            this.clientStatusRepository.saveAndFlush(clientStatus);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            ClientStatus clientStatus = this.clientStatusWrapper.findOneWithNotFoundDetection(id);
            clientStatus.setEuid(euid);
            clientStatus.setStatus(Status.DELETE);
            clientStatus.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(clientStatus.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
