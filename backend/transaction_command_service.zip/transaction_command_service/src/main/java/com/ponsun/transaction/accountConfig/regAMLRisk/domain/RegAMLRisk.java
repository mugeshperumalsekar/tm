package com.ponsun.transaction.accountConfig.regAMLRisk.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.CreateRegAMLRiskRequest;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.UpdateRegAMLRiskRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_RegAMLRisk")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class RegAMLRisk extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static RegAMLRisk create(final CreateRegAMLRiskRequest createRegAMLRiskRequest){
        final RegAMLRisk regAMLRisk = new RegAMLRisk();
        regAMLRisk.setName(createRegAMLRiskRequest.getName());
        regAMLRisk.setCode(createRegAMLRiskRequest.getCode());
        regAMLRisk.setUid(createRegAMLRiskRequest.getUid());
        regAMLRisk.setStatus(Status.ACTIVE);
        regAMLRisk.setCreatedAt(LocalDateTime.now());
        return regAMLRisk;
    }
    public void update(final UpdateRegAMLRiskRequest updateRegAMLRiskRequest){
        this.setName(updateRegAMLRiskRequest.getName());
        this.setCode(updateRegAMLRiskRequest.getCode());
        this.setEuid(updateRegAMLRiskRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

