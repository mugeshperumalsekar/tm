package com.ponsun.transaction.accessPermission.data;

public record RoleAccessDto(String uId, Integer modId, Integer modDetId, String modName, String modDetName, String link) {}
