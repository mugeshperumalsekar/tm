package com.ponsun.transaction.accountConfig.transactionFrequency.api;



import com.ponsun.transaction.accountConfig.transactionFrequency.request.CreateTransactionFrequencyRequest;
import com.ponsun.transaction.accountConfig.transactionFrequency.request.UpdateTransactionFrequencyRequest;
import com.ponsun.transaction.accountConfig.transactionFrequency.services.TransactionFrequencyReadService;
import com.ponsun.transaction.accountConfig.transactionFrequency.services.TransactionFrequencyWriteService;
import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequency;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/TransactionFrequency")
@Tag(name = "TransactionFrequencyApiResource")
public class TransactionFrequencyApiResources {
    private final TransactionFrequencyWriteService transactionFrequencyWriteService;
    private final TransactionFrequencyReadService transactionFrequencyReadService;

    @PostMapping("/CreateTransactionFrequencyRequest")
    public Response saveTransactionFrequency(@RequestBody CreateTransactionFrequencyRequest createTransactionFrequencyRequest) {
        log.debug("START saveTransactionFrequency request body {}",createTransactionFrequencyRequest);
        Response response = this.transactionFrequencyWriteService.createTransactionFrequency(createTransactionFrequencyRequest);
        log.debug("START saveTransactionFrequency response",response);
        return response;
    }

    @GetMapping
    public List<TransactionFrequency> fetchAll() {
        return this.transactionFrequencyReadService.fetchAllTransactionFrequency();
    }

    @GetMapping("/{id}")
    public TransactionFrequency fetchTransactionFrequencyById(@PathVariable(name = "id") Integer id) {
        return this.transactionFrequencyReadService.fetchTransactionFrequencyById(id);
    }

    @PutMapping("/{id}")
    public Response updateTransactionFrequency(@PathVariable Integer id, @RequestBody UpdateTransactionFrequencyRequest updateTransactionFrequencyRequest) {
        log.debug("START updateTransactionFrequency request body {}",updateTransactionFrequencyRequest);
        Response response = this.transactionFrequencyWriteService.updateTransactionFrequency(id, updateTransactionFrequencyRequest);
        log.debug("START updateTransactionFrequency response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockTransactionFrequency(@PathVariable Integer id){
        Response response = this.transactionFrequencyWriteService.unblockTransactionFrequency(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.transactionFrequencyWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<TransactionFrequency> fetchActiveTransactionFrequency() {
        return transactionFrequencyReadService.fetchActiveTransactionFrequency();
    }
    @GetMapping("DeActive")
    public List<TransactionFrequency> fetchDeTransactionFrequency() {
        return transactionFrequencyReadService.fetchDeActiveTransactionFrequency();
    }


}

