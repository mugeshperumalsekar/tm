package com.ponsun.transaction.accountConfig.productAccountType.data;

import com.ponsun.transaction.accountConfig.productAccountType.requests.CreateProductAccountTypeRequest;
import com.ponsun.transaction.accountConfig.productAccountType.requests.UpdateProductAccountTypeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ProductAccountTypeValidator {
    public void validateSaveProductAccount(final CreateProductAccountTypeRequest request){
        if (request.getId()== null || request.getId().equals("")){
            throw new PS_transaction_ApplicationException("id parameter required");
        }
    }
    public void validateUpdateProductAccount(final UpdateProductAccountTypeRequest request){
        if(request.getId() == null || request.getId().equals("")) {
            throw new PS_transaction_ApplicationException("id parameter required");

        }
    }
}
