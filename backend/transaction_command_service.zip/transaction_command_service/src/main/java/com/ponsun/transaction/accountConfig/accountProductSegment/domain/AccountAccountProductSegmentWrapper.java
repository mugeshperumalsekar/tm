package com.ponsun.transaction.accountConfig.accountProductSegment.domain;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.AbstractAccountProductSegmentRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AccountAccountProductSegmentWrapper extends AbstractAccountProductSegmentRequest {

    private final AccountProductSegmentRepository repository;

    @Transactional
    public AccountProductSegment findOneWithNotFoundDetection (final Integer id) {
    return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("AccountProductSegment Not found " + id));
}
    @Override
    public String toString(){
        return super.toString();
    }

}
