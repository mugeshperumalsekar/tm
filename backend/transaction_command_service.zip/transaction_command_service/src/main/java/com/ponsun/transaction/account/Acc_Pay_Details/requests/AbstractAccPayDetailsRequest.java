package com.ponsun.transaction.account.Acc_Pay_Details.requests;

import lombok.Data;

@Data
public class AbstractAccPayDetailsRequest {
    private Integer id;
    private double amountofLastRepayment;
    private Integer customerId;
    private double amountoverdue;
    private Integer daysPastDue;
    private double otherChargesOutstanding;
    private Integer payTerm;
    private Integer tenureinMonths;
    private Integer accountId;
    private Integer uid;
    private Integer euid;


}
