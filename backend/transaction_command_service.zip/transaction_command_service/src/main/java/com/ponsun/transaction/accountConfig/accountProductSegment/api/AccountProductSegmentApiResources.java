package com.ponsun.transaction.accountConfig.accountProductSegment.api;
import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountProductSegment;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.CreateAccountProductSegmentRequest;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.UpdateAccountProductSegmentRequest;
import com.ponsun.transaction.accountConfig.accountProductSegment.services.AccountProductSegmentReadService;
import com.ponsun.transaction.accountConfig.accountProductSegment.services.AccountProductSegmentWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccountProductSegment")
@Tag(name = "AccountProductSegmentApiResources")
public class AccountProductSegmentApiResources {
    private final AccountProductSegmentWriteService writeService;
    private final AccountProductSegmentReadService readService;

    @PostMapping("/CreateAccProductSegmentRequest")
    public Response createProductSegment(@RequestBody CreateAccountProductSegmentRequest request) {
        Response response = this.writeService.createAccProductSegment(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateProductSegment(@PathVariable Integer id, @RequestBody UpdateAccountProductSegmentRequest request) {
        Response response = this.writeService.updateAccProductSegment(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccountProductSegment fetchById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccProductSegmentById(id);
    }
    @GetMapping
    public List<AccountProductSegment> fetchAll() {
        return this.readService.fetchAllAccProductSegment();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockProductSegment(@PathVariable Integer id){
        Response response = this.writeService.unblockAccProductSegment(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccountProductSegment> fetchActiveAccountProductSegment() {
        return readService.fetchActiveAccountProductSegment();
    }
    @GetMapping("DeActive")
    public List<AccountProductSegment> fetchDeAccountProductSegment() {
        return readService.fetchDeActiveAccountProductSegment();
    }
}
