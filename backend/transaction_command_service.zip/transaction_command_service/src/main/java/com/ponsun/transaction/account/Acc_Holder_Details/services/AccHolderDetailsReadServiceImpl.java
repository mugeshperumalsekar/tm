package com.ponsun.transaction.account.Acc_Holder_Details.services;

import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetails;
import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetailsRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccHolderDetailsReadServiceImpl implements AccHolderDetailsReadService {
    private final AccHolderDetailsRepository repository;

    @Override
    @Transactional
    public AccHolderDetails fetchAccHolderDetailsById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccHolderDetails> fetchAllAccHolderDetails() {
        return this.repository.findAll();
    }

    @Override
    public List<AccHolderDetails> fetchActiveAccHolderDetails() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccHolderDetails> fetchDeActiveAccHolderDetails() {
        return repository.findByStatus(Status.DELETE);
    }
}
