package com.ponsun.transaction.account.Acc_transaction.rowmapper;
import com.ponsun.transaction.account.Acc_transaction.data.AccTransactionData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

@Service
@Slf4j
@Data
public class AccTransactionRowMapper implements RowMapper<AccTransactionData> {
    private final String schema;


    public AccTransactionRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM tm_acc_transaction_testing act ");
        builder.append("LEFT JOIN tm_acc_info ai ON act.accountId = ai.id ");
        builder.append("LEFT JOIN tm_Customer c ON ai.customerId = c.id ");
        builder.append("LEFT JOIN tm_config_CustomerType ct ON c.customer_type_id = ct.id ");
        builder.append("LEFT JOIN tm_config_instrument_type it ON act.instrumentTypeId = it.id ");
        builder.append("LEFT JOIN tm_config_type2 typ ON act.type2Id = typ.id ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("act.id as id, ");
        builder.append("act.accountId as accountId, ");
        builder.append("sum(act.amt) as amt, ");
        builder.append("act.applicationNumber as applicationNumber, ");
        builder.append("act.cardSubtype as cardSubtype, ");
        builder.append("act.cardType as cardType, ");
        builder.append("act.clientBankName as clientBankName, ");
        builder.append("act.clientBankCode as clientBankCode, ");
        builder.append("act.clientBankAccountNo as clientBankAccountNo, ");
        builder.append("act.counterPartyProductAccountType as counterPartyProductAccountType, ");
        builder.append("act.counterPartyProductAccountNumber as counterPartyProductAccountNumber, ");
        builder.append("act.instrumentNo as instrumentNo, ");
        builder.append("act.originalCurrency as originalCurrency, ");
        builder.append("act.organisationPoolAccount as organisationPoolAccount, ");
        builder.append("it.trans_type as transactionType, ");
        builder.append("COUNT(act.id) as transactionCount, ");
        builder.append("act.isCalc as isCalc, ");
        builder.append("ai.productSegmentId as segmentId, ");
        builder.append("ai.customerId as customerId, ");
        builder.append("c.customer_type_id as customerTypeId, ");
        builder.append("ct.customer_category_id as customerCategoryId, ");
        builder.append("c.regulatoryAmlRisk as customerRisk, ");
        builder.append("act.created_at as createdAt, ");
        builder.append("act.instrumentTypeId as instrumentTypeId, ");
        builder.append("it.code as instrumentType, ");
        builder.append("act.voucherTypeId as voucherTypeId, ");
        builder.append("act.type2Id as payTypeId, ");
        builder.append("act.userId as userId, ");
        builder.append("act.uid as uid, ");
        builder.append("act.euid as euid, ");
        builder.append("act.circleDate as circleDate, ");

        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) = DATE(act.circleDate) THEN 1 ELSE 0 END) AS SIGNED) AS sumCountCrntDay, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 DAY) AND DATE_SUB(act.circleDate, INTERVAL 1 DAY) THEN 1 ELSE 0 END) AS SIGNED) AS sumCountPreDay, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND act.circleDate THEN 1 ELSE 0 END) AS SIGNED) AS sumCountCrntMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) AS SIGNED) AS  sumCountPrevOneMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) AS SIGNED) AS  sumCountPrevThreeMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) AS SIGNED) AS  sumCountPrevSixMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) AS SIGNED) AS sumCountPrevNineMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) AS SIGNED) AS sumCountPrevTwelveMonth, ");

        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) = DATE(act.circleDate) THEN 1 ELSE 0 END)/2 AS SIGNED) AS avgCountCrntDay, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 DAY) AND DATE_SUB(act.circleDate, INTERVAL 1 DAY) THEN 1 ELSE 0 END) / 2 AS SIGNED) AS avgCountPreDay, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND act.circleDate  THEN 1 ELSE 0 END) / 2 AS SIGNED) AS avgCountCrntMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) / 2 AS SIGNED) AS  avgCountPrevOneMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) / 2 AS SIGNED) AS  avgCountPrevThreeMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) / 2 AS SIGNED) AS  avgCountPrevSixMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) / 2 AS SIGNED) AS avgCountPrevNineMonth, ");
        builder.append("CAST(SUM(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) THEN 1 ELSE 0 END) / 2 AS SIGNED) AS avgCountPrevTwelveMonth, ");

        builder.append("COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) = DATE(act.circleDate) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id GROUP BY DATE(transactionDate) ) AS dailyCounts ), 0 ) AS maxCountCrntDay, ");
        builder.append("COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 DAY)  AND DATE_SUB(act.circleDate, INTERVAL 1 DAY) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0) AS maxCountPreDay, ");
        builder.append("COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND act.circleDate AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0) AS maxCountCrntMonth, ");
        builder.append("COUNT(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)  THEN act.id  END ) AS oneMonthTransactionCount,COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH)  AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0)      AS maxCountPrevOneMonth, ");
        builder.append("COUNT(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)  THEN act.id  END ) AS threeMonthTransactionCount,COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH)  AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0)    AS maxCountPrevThreeMonth, ");
        builder.append("COUNT(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)  THEN act.id  END ) AS sixMonthTransactionCount,COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH)  AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0)      AS maxCountPrevSixMonth, ");
        builder.append("COUNT(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)  THEN act.id  END ) AS nineMonthTransactionCount,COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH)  AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0)   AS maxCountPrevNineMonth, ");
        builder.append("COUNT(CASE WHEN DATE(act.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)  THEN act.id  END ) AS twelveMonthTransactionCount,COALESCE((SELECT MAX(trans_count) FROM (SELECT DATE(transactionDate) AS txn_date, COUNT(*) AS trans_count FROM tm_acc_transaction_testing WHERE DATE(transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH)  AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id  GROUP BY DATE(transactionDate)) AS dailyCounts), 0) AS maxCountPrevTwelveMonth, ");


        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) = DATE(act.circleDate)), 0) AS sumAmtCrtDay,  ");
        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) = DATE(act.circleDate)), 0) AS maxAmtCrtDay,  ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) = DATE(act.circleDate)), 0) AS avgAmtCrtDay,  ");

        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND act.circleDate), 0) AS crtSumAmtOneMonth,  ");
        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND act.circleDate), 0) AS crtMaxAmtOneMonth,  ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 MONTH) AND act.circleDate), 0) AS crtAvgAmtOneMonth,  ");

        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 DAY) AND act.circleDate),0) AS sumAmtPerDay,  ");
        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 DAY) AND act.circleDate), 0) AS maxAmtPerDay,  ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 1 DAY) AND act.circleDate), 0) AS avgAmtPerDay,  ");

        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS MaxAmtOneMonth, ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS AvgAmtOneMonth, ");
        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 2 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS SumAmtOneMonth, ");

        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS MaxAmtThreeMonth, ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS AvgAmtThreeMonth, ");
        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 4 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS SumAmtThreeMonth, ");

        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS MaxAmtSixMonth, ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS AvgAmtSixMonth, ");
        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 7 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS SumAmtSixMonth, ");

        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS MaxAmtNineMonth, ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS AvgAmtNineMonth, ");
        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 10 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS SumAmtNineMonth, ");

        builder.append("IFNULL(( SELECT MAX(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS MaxAmtTwelveMonth, ");
        builder.append("IFNULL(( SELECT AVG(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS AvgAmtTwelveMonth, ");
        builder.append("IFNULL(( SELECT SUM(a.amt) FROM tm_acc_transaction_testing a WHERE a.accountId = act.accountId AND instrumentTypeId = it.id AND type2Id = act.type2Id AND DATE(a.transactionDate) BETWEEN DATE_SUB(act.circleDate, INTERVAL 13 MONTH) AND DATE_SUB(act.circleDate, INTERVAL 1 MONTH)), 0) AS SumAmtTwelveMonth ");

        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccTransactionData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer accountId = rs.getInt("accountId");
        final double amt = rs.getDouble("amt");
        final String applicationNumber = rs.getString("applicationNumber");
        final String cardSubtype = rs.getString("cardSubtype");
        final String cardType = rs.getString("cardType");
        final String clientBankName = rs.getString("clientBankName");
        final String clientBankCode = rs.getString("clientBankCode");
        final String clientBankAccountNo = rs.getString("clientBankAccountNo");
        final String counterPartyProductAccountType = rs.getString("counterPartyProductAccountType");
        final String counterPartyProductAccountNumber = rs.getString("counterPartyProductAccountNumber");
        final String instrumentType = rs.getString("instrumentType");
        final String instrumentNo = rs.getString("instrumentNo");
        final String originalCurrency = rs.getString("originalCurrency");
        final String organisationPoolAccount = rs.getString("organisationPoolAccount");
        final String transactionType = rs.getString("transactionType");
        final Integer transactionCount = rs.getInt("transactionCount");
        final Integer isCalc = rs.getInt("isCalc");
        final Integer segmentId = rs.getInt("segmentId");
        final Integer customerId = rs.getInt("customerId");
        final Integer customerTypeId = rs.getInt("customerTypeId");
        final Integer customerCategoryId = rs.getInt("customerCategoryId");
        final String customerRisk = rs.getString("customerRisk");
        final LocalDateTime createdAt = (LocalDateTime) rs.getObject("createdAt");
        final Integer instrumentTypeId = rs.getInt("instrumentTypeId");
        final Integer voucherTypeId = rs.getInt("voucherTypeId");
        final Integer payTypeId = rs.getInt("payTypeId");
        final String userId = rs.getString("userId");
        final String uid = rs.getString("uid");
        final Integer euid = rs.getInt("euid");

        final Integer sumCountCrntDay = rs.getInt("sumCountCrntDay");
        final Integer sumCountPreDay = rs.getInt("sumCountPreDay");
        final Integer sumCountCrntMonth = rs.getInt("sumCountCrntMonth");
        final Integer sumCountPrevOneMonth = rs.getInt("sumCountPrevOneMonth");
        final Integer sumCountPrevThreeMonth = rs.getInt("sumCountPrevThreeMonth");
        final Integer sumCountPrevSixMonth = rs.getInt("sumCountPrevSixMonth");
        final Integer sumCountPrevNineMonth = rs.getInt("sumCountPrevNineMonth");
        final Integer sumCountPrevTwelveMonth = rs.getInt("sumCountPrevTwelveMonth");
        final Integer avgCountCrntDay = rs.getInt("avgCountCrntDay");
        final Integer avgCountPreDay = rs.getInt("avgCountPreDay");
        final Integer avgCountCrntMonth = rs.getInt("avgCountCrntMonth");
        final Integer avgCountPrevOneMonth = rs.getInt("avgCountPrevOneMonth");
        final Integer avgCountPrevThreeMonth = rs.getInt("avgCountPrevThreeMonth");
        final Integer avgCountPrevSixMonth = rs.getInt("avgCountPrevSixMonth");
        final Integer avgCountPrevNineMonth = rs.getInt("avgCountPrevNineMonth");
        final Integer avgCountPrevTwelveMonth = rs.getInt("avgCountPrevTwelveMonth");
        final Integer maxCountCrntDay = rs.getInt("maxCountCrntDay");
        final Integer maxCountPreDay = rs.getInt("maxCountPreDay");
        final Integer maxCountCrntMonth = rs.getInt("maxCountCrntMonth");
        final Integer maxCountPrevOneMonth = rs.getInt("maxCountPrevOneMonth");
        final Integer maxCountPrevThreeMonth = rs.getInt("maxCountPrevThreeMonth");
        final Integer maxCountPrevSixMonth = rs.getInt("maxCountPrevSixMonth");
        final Integer maxCountPrevNineMonth = rs.getInt("maxCountPrevNineMonth");
        final Integer maxCountPrevTwelveMonth = rs.getInt("maxCountPrevTwelveMonth");

        final Double sumAmtCrtDay = rs.getDouble("sumAmtCrtDay");
        final Double maxAmtCrtDay = rs.getDouble("maxAmtCrtDay");
        final Double avgAmtCrtDay = rs.getDouble("avgAmtCrtDay");
        final Double crtSumAmtOneMonth = rs.getDouble("crtSumAmtOneMonth");
        final Double crtMaxAmtOneMonth = rs.getDouble("crtMaxAmtOneMonth");
        final Double crtAvgAmtOneMonth = rs.getDouble("crtAvgAmtOneMonth");

        final Double sumAmtPerDay = rs.getDouble("sumAmtPerDay");
        final Double maxAmtPerDay = rs.getDouble("maxAmtPerDay");
        final Double avgAmtPerDay = rs.getDouble("avgAmtPerDay");

        final Double SumAmtOneMonth = rs.getDouble("SumAmtOneMonth");
        final Double SumAmtThreeMonth = rs.getDouble("SumAmtThreeMonth");
        final Double SumAmtSixMonth = rs.getDouble("SumAmtSixMonth");
        final Double SumAmtNineMonth = rs.getDouble("SumAmtNineMonth");
        final Double SumAmtTwelveMonth = rs.getDouble("SumAmtTwelveMonth");
        final Double MaxAmtOneMonth = rs.getDouble("MaxAmtOneMonth");
        final Double MaxAmtThreeMonth = rs.getDouble("MaxAmtThreeMonth");
        final Double MaxAmtSixMonth = rs.getDouble("MaxAmtSixMonth");
        final Double MaxAmtNineMonth = rs.getDouble("MaxAmtNineMonth");
        final Double MaxAmtTwelveMonth = rs.getDouble("MaxAmtTwelveMonth");
        final Double AvgAmtOneMonth = rs.getDouble("AvgAmtOneMonth");
        final Double AvgAmtThreeMonth = rs.getDouble("AvgAmtThreeMonth");
        final Double AvgAmtSixMonth = rs.getDouble("AvgAmtSixMonth");
        final Double AvgAmtNineMonth = rs.getDouble("AvgAmtNineMonth");
        final Double AvgAmtTwelveMonth = rs.getDouble("AvgAmtTwelveMonth");

        return AccTransactionData.newInstance(id, accountId, amt, applicationNumber, cardSubtype, cardType, clientBankName, clientBankCode, clientBankAccountNo,
                counterPartyProductAccountType, counterPartyProductAccountNumber, instrumentType, instrumentNo, originalCurrency,
                organisationPoolAccount, transactionType, transactionCount, isCalc, segmentId, customerId, customerTypeId,
                customerCategoryId, 0, customerRisk, 0, createdAt, instrumentTypeId,voucherTypeId,payTypeId,userId, uid, euid,
                sumCountCrntDay, sumCountPreDay, sumCountCrntMonth, sumCountPrevOneMonth, sumCountPrevThreeMonth, sumCountPrevSixMonth, sumCountPrevNineMonth, sumCountPrevTwelveMonth, avgCountCrntDay, avgCountPreDay, avgCountCrntMonth, avgCountPrevOneMonth, avgCountPrevThreeMonth, avgCountPrevSixMonth, avgCountPrevNineMonth, avgCountPrevTwelveMonth, maxCountCrntDay, maxCountPreDay, maxCountCrntMonth, maxCountPrevOneMonth, maxCountPrevThreeMonth, maxCountPrevSixMonth, maxCountPrevNineMonth, maxCountPrevTwelveMonth,
                sumAmtCrtDay, maxAmtCrtDay, avgAmtCrtDay, crtSumAmtOneMonth, crtMaxAmtOneMonth, crtAvgAmtOneMonth ,sumAmtPerDay, maxAmtPerDay, avgAmtPerDay, SumAmtOneMonth, SumAmtThreeMonth, SumAmtSixMonth, SumAmtNineMonth, SumAmtTwelveMonth, MaxAmtOneMonth, MaxAmtThreeMonth, MaxAmtSixMonth, MaxAmtNineMonth, MaxAmtTwelveMonth, AvgAmtOneMonth, AvgAmtThreeMonth, AvgAmtSixMonth, AvgAmtNineMonth, AvgAmtTwelveMonth);
    }

}
