package com.ponsun.transaction.accountConfig.policyType.domain;

import com.ponsun.transaction.accountConfig.policyType.request.UpdatePolicyTypeRequest;
import com.ponsun.transaction.accountConfig.policyType.request.CreatePolicyTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_PolicyType")
public class PolicyType extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static PolicyType create(final CreatePolicyTypeRequest createPolicyTypeRequest){
        final PolicyType PolicyType = new PolicyType();
        PolicyType.setName(createPolicyTypeRequest.getName());
        PolicyType.setCode(createPolicyTypeRequest.getCode());
        PolicyType.setUid(createPolicyTypeRequest.getUid());
        PolicyType.setStatus(Status.ACTIVE);
        PolicyType.setCreatedAt(LocalDateTime.now());
        return PolicyType;
    }
    public void update(final UpdatePolicyTypeRequest updatePolicyTypeRequest){
        this.setName(updatePolicyTypeRequest.getName());
        this.setCode(updatePolicyTypeRequest.getCode());
        this.setEuid(updatePolicyTypeRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

