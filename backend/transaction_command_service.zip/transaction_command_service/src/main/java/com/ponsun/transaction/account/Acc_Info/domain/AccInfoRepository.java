package com.ponsun.transaction.account.Acc_Info.domain;
import com.ponsun.transaction.CustomersDetalis.tmCustomer.domain.TmCustomer;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AccInfoRepository extends JpaRepository<AccInfo,Integer> {
    List<AccInfo> findByStatus(Status string);

    @Query("SELECT ai FROM AccInfo ai WHERE ai.id = :id AND ai.status = 'A'")
    Optional<AccInfo> findByIdAndStatus(@Param("id") Integer id);


}
