package com.ponsun.transaction.accountConfig.policyType.request;

import lombok.Data;

@Data
public class AbstractPolicyTypeRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
