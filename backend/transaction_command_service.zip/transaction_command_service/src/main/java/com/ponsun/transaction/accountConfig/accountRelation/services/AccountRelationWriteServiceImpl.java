package com.ponsun.transaction.accountConfig.accountRelation.services;

import com.ponsun.transaction.accountConfig.accountRelation.data.AccountRelationValidator;
import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelation;
import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelationRepository;
import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelationWrapper;
import com.ponsun.transaction.accountConfig.accountRelation.request.CreateAccountRelationRequest;
import com.ponsun.transaction.accountConfig.accountRelation.request.UpdateAccountRelationRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountRelationWriteServiceImpl implements AccountRelationWriteService {

    private final AccountRelationRepository accountRelationRepository;
    private final AccountRelationWrapper accountRelationWrapper;
    private final AccountRelationValidator accountRelationValidator;

    @Override
    @Transactional
    public Response createAccountRelation(CreateAccountRelationRequest createAccountRelationRequest) {
        try {
            this.accountRelationValidator.validateSaveAccountRelation(createAccountRelationRequest);
            final AccountRelation accountRelation = AccountRelation.create(createAccountRelationRequest);
            this.accountRelationRepository.saveAndFlush(accountRelation);
            return Response.of(Long.valueOf(accountRelation.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccountRelation(Integer id, UpdateAccountRelationRequest updateAccountRelationRequest) {
        try {
            this.accountRelationValidator.validateUpdateAccountRelation(updateAccountRelationRequest);
            final AccountRelation accountRelation = this.accountRelationWrapper.findOneWithNotFoundDetection(id);
            accountRelation.update(updateAccountRelationRequest);
            this.accountRelationRepository.saveAndFlush(accountRelation);
            return Response.of(Long.valueOf(accountRelation.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccountRelation(Integer id) {
        try {
            final AccountRelation accountRelation = this.accountRelationWrapper.findOneWithNotFoundDetection(id);
            accountRelation.setStatus(Status.ACTIVE);
            accountRelation.setUpdatedAt(LocalDateTime.now());
            this.accountRelationRepository.saveAndFlush(accountRelation);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            AccountRelation accountRelation = this.accountRelationWrapper.findOneWithNotFoundDetection(id);
            accountRelation.setEuid(euid);
            accountRelation.setStatus(Status.DELETE);
            accountRelation.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(accountRelation.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
