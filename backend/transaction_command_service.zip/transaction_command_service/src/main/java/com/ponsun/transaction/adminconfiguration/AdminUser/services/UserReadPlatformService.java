package com.ponsun.transaction.adminconfiguration.AdminUser.services;


import com.ponsun.transaction.adminconfiguration.AdminUser.domain.User;

import java.util.List;

public interface UserReadPlatformService {

    User fetchUserById(Integer id);
    List<User> fetchAllUsers();
}
