package com.ponsun.transaction.account.Acc_Holder_Details.api;

import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetails;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.CreateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.UpdateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Holder_Details.services.AccHolderDetailsReadService;
import com.ponsun.transaction.account.Acc_Holder_Details.services.AccHolderDetailsWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccHolderDetails")
@Tag(name = "AccHolderDetailsApiResources")
public class AccHolderDetailsApiResources {
    private final AccHolderDetailsWriteService writeService;
    private final AccHolderDetailsReadService readService;

    @PostMapping("/CreateAccountRequest")
    public Response createAccHolderDetails(@RequestBody CreateAccHolderDetailsRequest request) {
        Response response = this.writeService.createAccHolderDetails(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccHolderDetails(@PathVariable Integer id, @RequestBody UpdateAccHolderDetailsRequest request) {
        Response response = this.writeService.updateAccHolderDetails(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccHolderDetails fetchAccHolderDetailsById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccHolderDetailsById(id);
    }
    @GetMapping
    public List<AccHolderDetails> fetchAll() {
        return this.readService.fetchAllAccHolderDetails();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccHolderDetails(@PathVariable Integer id){
        Response response = this.writeService.unblockAccHolderDetails(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccHolderDetails> fetchActiveAccHolderDetails() {
        return readService.fetchActiveAccHolderDetails();
    }

    @GetMapping("DeActive")
    public List<AccHolderDetails> fetchDeAccHolderDetails() {
        return readService.fetchDeActiveAccHolderDetails();
    }

}
