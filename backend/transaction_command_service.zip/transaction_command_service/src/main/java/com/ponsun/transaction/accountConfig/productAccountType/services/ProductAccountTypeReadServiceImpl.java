package com.ponsun.transaction.accountConfig.productAccountType.services;

import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountTypeRepository;
import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountType;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@RequiredArgsConstructor
@Slf4j
public class ProductAccountTypeReadServiceImpl implements ProductAccountTypeReadService {
    private final ProductAccountTypeRepository repository;

    @Override
    @Transactional
    public ProductAccountType fetchProductAccountById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<ProductAccountType> fetchAllProductAccount() {
        return this.repository.findAll();
    }

    @Override
    public List<ProductAccountType> fetchActiveProductAccountType() {
        return this.repository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<ProductAccountType> fetchDeActiveProductAccountType() {
        return this.repository.findByStatus(Status.DELETE);
    }
}
