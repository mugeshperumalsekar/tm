package com.ponsun.transaction.accountConfig.clientStatus.data;
import lombok.Data;
@Data
public class ClientStatusData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;


    public ClientStatusData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static ClientStatusData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new ClientStatusData(id,name,code,uid,euid);
    }
}

