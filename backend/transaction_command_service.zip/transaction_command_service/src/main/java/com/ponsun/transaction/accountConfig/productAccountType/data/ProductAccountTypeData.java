package com.ponsun.transaction.accountConfig.productAccountType.data;

import lombok.Data;

@Data
public class ProductAccountTypeData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;

    public ProductAccountTypeData(Integer id, String name, String code, Integer uid, Integer euid) {
        this.id = id;
        this.name = name;
        this.code = code;
        this.uid = uid;
        this.euid = euid;
    }
    public static ProductAccountTypeData newInstance(Integer id, String name, String code, Integer uid, Integer euid){
        return new ProductAccountTypeData(id,name,code,uid,euid);
    }
}
