package com.ponsun.transaction.accountConfig.regAMLRisk.services;


import com.ponsun.transaction.accountConfig.regAMLRisk.data.RegAMLRiskValidator;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRisk;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRiskRepository;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRiskWrapper;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.CreateRegAMLRiskRequest;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.UpdateRegAMLRiskRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class RegAMLRiskWriteServiceImpl implements RegAMLRiskWriteService {

    private final RegAMLRiskRepository regAMLRiskRepository;
    private final RegAMLRiskWrapper regAMLRiskWrapper;
    private final RegAMLRiskValidator regAMLRiskValidator;


    @Transactional
    public Response createRegAMLRisk(CreateRegAMLRiskRequest createRegAMLRiskRequest) {
        try {
            this.regAMLRiskValidator.validateSaveRegAMLRisk(createRegAMLRiskRequest);
            final RegAMLRisk regAMLRisk = RegAMLRisk.create(createRegAMLRiskRequest);
            this.regAMLRiskRepository.saveAndFlush(regAMLRisk);
            return Response.of(Long.valueOf(regAMLRisk.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateRegAMLRisk(Integer id, UpdateRegAMLRiskRequest updateRegAMLRiskRequest) {
        try {
            this.regAMLRiskValidator.validateUpdateRegAMLRisk(updateRegAMLRiskRequest);
            final RegAMLRisk regAMLRisk = this.regAMLRiskWrapper.findOneWithNotFoundDetection(id);
            regAMLRisk.update(updateRegAMLRiskRequest);
            this.regAMLRiskRepository.saveAndFlush(regAMLRisk);
            return Response.of(Long.valueOf(regAMLRisk.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockRegAMLRisk(Integer id) {
        try {
            final RegAMLRisk RegAMLRisk = this.regAMLRiskWrapper.findOneWithNotFoundDetection(id);
            RegAMLRisk.setStatus(Status.ACTIVE);
            RegAMLRisk.setUpdatedAt(LocalDateTime.now());
            this.regAMLRiskRepository.saveAndFlush(RegAMLRisk);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            RegAMLRisk regAMLRisk = this.regAMLRiskWrapper.findOneWithNotFoundDetection(id);
            regAMLRisk.setEuid(euid);
            regAMLRisk.setStatus(Status.DELETE);
            regAMLRisk.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(regAMLRisk.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
