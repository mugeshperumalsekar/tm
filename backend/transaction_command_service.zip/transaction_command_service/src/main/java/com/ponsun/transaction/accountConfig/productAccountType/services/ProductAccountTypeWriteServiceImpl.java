package com.ponsun.transaction.accountConfig.productAccountType.services;

import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountTypeRepository;
import com.ponsun.transaction.accountConfig.productAccountType.requests.CreateProductAccountTypeRequest;
import com.ponsun.transaction.accountConfig.productAccountType.data.ProductAccountTypeValidator;
import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountType;
import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountTypeWrapper;
import com.ponsun.transaction.accountConfig.productAccountType.requests.UpdateProductAccountTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductAccountTypeWriteServiceImpl implements ProductAccountTypeWriteService {
    private final ProductAccountTypeRepository repository;
    private final ProductAccountTypeWrapper wrapper;
    private final ProductAccountTypeValidator validator;

    @Override
    @Transactional
    public Response createProductAccount(CreateProductAccountTypeRequest request) {
        try {
            this.validator.validateSaveProductAccount(request);
            final ProductAccountType productAccountType = ProductAccountType.create(request);
            this.repository.saveAndFlush(productAccountType);
            return Response.of(Long.valueOf(productAccountType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response updateProductAccount(Integer id, UpdateProductAccountTypeRequest request) {
        try {
            this.validator.validateUpdateProductAccount(request);
            final ProductAccountType productAccountType = this.wrapper.findOneWithNotFoundDetection(id);
            productAccountType.update(request);
            this.repository.saveAndFlush(productAccountType);
            return Response.of(Long.valueOf(productAccountType.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockProductAccount(Integer id) {
        try {
            final ProductAccountType productAccountType = this.wrapper.findOneWithNotFoundDetection(id);
            productAccountType.setStatus(Status.ACTIVE);
            productAccountType.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(productAccountType);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid){
        try{
            ProductAccountType productAccountType = this.wrapper.findOneWithNotFoundDetection(id);
            productAccountType.setEuid(euid);
            productAccountType.setStatus(Status.DELETE);
            productAccountType.setUpdatedAt(LocalDateTime.now());

            return Response.of(Long.valueOf(productAccountType.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

}