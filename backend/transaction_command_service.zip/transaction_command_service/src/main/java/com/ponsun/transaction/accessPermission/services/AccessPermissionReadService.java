package com.ponsun.transaction.accessPermission.services;

import com.ponsun.transaction.accessPermission.data.AccessPermissionData;

import java.util.List;

public interface AccessPermissionReadService {

    List<AccessPermissionData> fetchAllMenuListBasedOnRole(Integer userId);
}
