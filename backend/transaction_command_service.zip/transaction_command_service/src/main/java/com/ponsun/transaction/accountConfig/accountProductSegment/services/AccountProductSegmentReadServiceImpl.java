package com.ponsun.transaction.accountConfig.accountProductSegment.services;

import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountProductSegment;
import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountProductSegmentRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@RequiredArgsConstructor
@Slf4j
public class AccountProductSegmentReadServiceImpl implements AccountProductSegmentReadService {
    private final AccountProductSegmentRepository repository;

    @Override
    @Transactional
    public AccountProductSegment fetchAccProductSegmentById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccountProductSegment> fetchAllAccProductSegment() {
        return this.repository.findAll();
    }

    @Override
    public List<AccountProductSegment> fetchActiveAccountProductSegment() {
        return this.repository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<AccountProductSegment> fetchDeActiveAccountProductSegment() {
        return this.repository.findByStatus(Status.DELETE);
    }


}
