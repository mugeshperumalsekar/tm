package com.ponsun.transaction.accountDetails.services;

import com.ponsun.transaction.accountDetails.domain.AccountDetails;

import java.util.List;

public interface AccountDetailsReadPlatformService {
    List<AccountDetails> fetchAllAccountDetails();

    AccountDetails fetchAccountDetailsById(Integer id);
}
