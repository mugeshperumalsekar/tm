package com.ponsun.transaction.accountConfig.accountProductSegment.services;

import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountProductSegment;

import java.util.List;

public interface AccountProductSegmentReadService {
    AccountProductSegment fetchAccProductSegmentById(Integer id);
    List<AccountProductSegment> fetchAllAccProductSegment();
    List<AccountProductSegment> fetchActiveAccountProductSegment();

    List<AccountProductSegment> fetchDeActiveAccountProductSegment();
}
