package com.ponsun.transaction.accountConfig.instrumentType.requests;

import lombok.Data;

@Data
public class UpdateInstrumentTypeRequest extends AbstractInstrumentTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
