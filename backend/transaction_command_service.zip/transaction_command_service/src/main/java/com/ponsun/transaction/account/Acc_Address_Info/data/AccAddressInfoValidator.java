package com.ponsun.transaction.account.Acc_Address_Info.data;

import com.ponsun.transaction.account.Acc_Address_Info.requests.CreateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Address_Info.requests.UpdateAccAddressInfoRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccAddressInfoValidator {
    public void validateSaveAccAddressInfo(final CreateAccAddressInfoRequest request){
        if (request.getAccountId()== null || request.getAccountId().equals("")){
            throw new PS_transaction_ApplicationException("AccountId parameter required");
        }
    }
    public void validateUpdateAccAddressInfo(final UpdateAccAddressInfoRequest request){
        if(request.getAccountId() == null || request.getAccountId().equals("")) {
            throw new PS_transaction_ApplicationException("AccountId parameter required");

        }
    }

}
