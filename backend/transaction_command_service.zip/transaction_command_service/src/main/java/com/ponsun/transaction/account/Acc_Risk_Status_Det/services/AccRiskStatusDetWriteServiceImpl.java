package com.ponsun.transaction.account.Acc_Risk_Status_Det.services;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.data.AccRiskStatusDetValidator;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDet;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDetRepository;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDetWrapper;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.CreateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.UpdateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccRiskStatusDetWriteServiceImpl implements AccRiskStatusDetWriteService {
    private final AccRiskStatusDetRepository repository;
    private final AccRiskStatusDetWrapper wrapper;
    private final AccRiskStatusDetValidator validator;
    private final AccInfoWrapper accInfoWrapper;
    @Override
    @Transactional

    public Response createAccRiskStatusDet(CreateAccRiskStatusDetRequest request) {
        try {
            this.validator.validateSaveAccRiskStatusDet(request);

            AccInfo accInfo = accInfoWrapper.findOneWithNotFoundDetection(request.getAccountId());
            if (accInfo == null) {
                throw new PS_transaction_ApplicationException("Account information not found for accountId: " + request.getAccountId());
            }

            final AccRiskStatusDet holderDetails = AccRiskStatusDet.create(request,accInfo);
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(holderDetails.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccRiskStatusDet(Integer id, UpdateAccRiskStatusDetRequest request) {
        try {
            this.validator.validateUpdateAccRiskStatusDet(request);
            final AccRiskStatusDet holderDetails = this.wrapper.findOneWithNotFoundDetection(id);
            holderDetails.update(request);
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(holderDetails.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccRiskStatusDet(Integer id) {
        try {
            final AccRiskStatusDet holderDetails = this.wrapper.findOneWithNotFoundDetection(id);
            holderDetails.setStatus(Status.ACTIVE);
            holderDetails.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccRiskStatusDet holderDetails = this.wrapper.findOneWithNotFoundDetection(id);
            holderDetails.setEuid(euid);
            holderDetails.setStatus(Status.DELETE);
            holderDetails.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(holderDetails.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }
}
