package com.ponsun.transaction.account.Acc_Info_det.domain;

import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info_det.requests.CreateAccountInfoDetRequest;
import com.ponsun.transaction.account.Acc_Info_det.requests.UpdateAccountInfoDetRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_info_det")
public class AccountInfoDet extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "accountId", referencedColumnName = "id", nullable = false)
    private AccInfo accInfo;

    @Column(name = "accountNumber")
    private String accountNumber;

    @Column(name = "customerId")
    private Integer customerId;

    @Column(name = "accountRisk" )
    private String accountRisk;

    @Column(name = "accountRiskEffectiveDate")
    private String accountRiskEffectiveDate;

    @Column(name = "accountRiskNextReviewDate")
    private String accountRiskNextReviewDate;

    @Column(name = "accountSegment" )
    private String accountSegment;

    @Column(name = "accountSegmentEffectiveDate" )
    private String accountSegmentEffectiveDate;

    @Column(name = "accountType" , columnDefinition = "TEXT")
    private String accountType;

    @Column(name = "applicationNumber", columnDefinition = "TEXT")
    private String applicationNumber;

    @Column(name = "applicationSignedDate")
    private String applicationSignedDate;

    @Column(name = "asOfDate" )
    private String asOfDate;

    @Column(name = "bankCode", columnDefinition = "TEXT")
    private String bankCode;

    @Column(name = "bankName", columnDefinition = "TEXT")
    private String bankName;

    @Column(name = "bankbranchname" , columnDefinition = "TEXT")
    private String bankbranchname;

    @Column(name = "channel")
    private String channel;

    @Column(name = "clientStatus")
    private String clientStatus;

    @Column(name = "creditorBusinessUnit")
    private String creditorBusinessUnit;

    @Column(name = "creditorRMEmail" )
    private String creditorRMEmail;

    @Column(name = "currency")
    private String currency;

    @Column(name = "dpid")
    private Integer dpid;

    @Column(name = "fundedType")
    private String fundedType;

    @Column(name = "grossAnnualPremiumwithTax")
    private double grossAnnualPremiumwithTax;

    @Column(name = "grossAnnualPremiumwithoutTax")
    private double grossAnnualPremiumwithoutTax;

    @Column(name = "ifscCode", columnDefinition = "TEXT")
    private String ifscCode;

    @Column(name = "incomeMultiplier")
    private double incomeMultiplier;

    @Column(name = "insurancePurpose", columnDefinition = "TEXT")
    private String insurancePurpose;

    @Column(name = "intermediaryCode", columnDefinition = "TEXT")
    private String intermediaryCode;

    @Column(name = "introducerEmployeeCode" , columnDefinition = "TEXT")
    private String introducerEmployeeCode;

    @Column(name = "micrCode" , columnDefinition = "TEXT")
    private String micrCode;

    @Column(name = "modalPremium")
    private double modalPremium;

    @Column(name = "moduleApplicable" , columnDefinition = "TEXT")
    private String moduleApplicable;

    @Column(name = "parentCompany")
    private String parentCompany;

    @Column(name = "personalEmail")
    private String personalEmail;

    @Column(name = "personalMobileISD")
    private String personalMobileISD;

    @Column(name = "personalMobileNumber")
    private String personalMobileNumber;

    @Column(name = "plotnoSurveynoHouseFlatno" , columnDefinition = "TEXT")
    private String plotnoSurveynoHouseFlatno;

    @Column(name = "policyEndDate" )
    private String policyEndDate;

    @Column(name = "policyTerm", columnDefinition = "TEXT")
    private String policyTerm;

    @Column(name = "policyType")
    private String policyType;

    @Column(name = "rateofInterest")
    private String rateofInterest;

    @Column(name = "sanctionDate")
    private String sanctionDate;

    @Column(name = "securityCount")
    private Integer securityCount;

    @Column(name = "securityDetails" , columnDefinition = "TEXT")
    private String securityDetails;

    @Column(name = "sumAssured")
    private double sumAssured;

    @Column(name = "transactionFrequency" , columnDefinition = "TEXT")
    private String transactionFrequency;

    @Column(name = "transactionId")
    private String transactionId;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccountInfoDet create(final CreateAccountInfoDetRequest request,AccInfo accInfo) {
        final AccountInfoDet accountInfoDet = new AccountInfoDet();
        accountInfoDet.setAccInfo(accInfo);
        accountInfoDet.setAccountNumber(request.getAccountNumber());
        accountInfoDet.setCustomerId(request.getCustomerId());
        accountInfoDet.setAccountRisk(request.getAccountRisk());
        accountInfoDet.setAccountRiskEffectiveDate(request.getAccountRiskEffectiveDate());
        accountInfoDet.setAccountRiskNextReviewDate(request.getAccountRiskNextReviewDate());
        accountInfoDet.setAccountSegment(request.getAccountSegment());
        accountInfoDet.setAccountSegmentEffectiveDate(request.getAccountSegmentEffectiveDate());
        accountInfoDet.setAccountType(request.getAccountType());
        accountInfoDet.setApplicationNumber(request.getApplicationNumber());
        accountInfoDet.setApplicationSignedDate(request.getApplicationSignedDate());
        accountInfoDet.setAsOfDate(request.getAsOfDate());
        accountInfoDet.setBankCode(request.getBankCode());
        accountInfoDet.setBankName(request.getBankName());
        accountInfoDet.setBankbranchname(request.getBankbranchname());
        accountInfoDet.setChannel(request.getChannel());
        accountInfoDet.setClientStatus(request.getClientStatus());
        accountInfoDet.setCreditorBusinessUnit(request.getCreditorBusinessUnit());
        accountInfoDet.setCreditorRMEmail(request.getCreditorRMEmail());
        accountInfoDet.setCurrency(request.getCurrency());
        accountInfoDet.setDpid(request.getDpid());
        accountInfoDet.setFundedType(request.getFundedType());
        accountInfoDet.setGrossAnnualPremiumwithTax(request.getGrossAnnualPremiumwithTax());
        accountInfoDet.setGrossAnnualPremiumwithoutTax(request.getGrossAnnualPremiumwithoutTax());
        accountInfoDet.setIfscCode(request.getIfscCode());
        accountInfoDet.setIncomeMultiplier(request.getIncomeMultiplier());
        accountInfoDet.setInsurancePurpose(request.getInsurancePurpose());
        accountInfoDet.setIntermediaryCode(request.getIntermediaryCode());
        accountInfoDet.setIntroducerEmployeeCode(request.getIntroducerEmployeeCode());
        accountInfoDet.setMicrCode(request.getMicrCode());
        accountInfoDet.setModalPremium(request.getModalPremium());
        accountInfoDet.setModuleApplicable(request.getModuleApplicable());
        accountInfoDet.setParentCompany(request.getParentCompany());
        accountInfoDet.setPersonalEmail(request.getPersonalEmail());
        accountInfoDet.setPersonalMobileISD(request.getPersonalMobileISD());
        accountInfoDet.setPersonalMobileNumber(request.getPersonalMobileNumber());
        accountInfoDet.setPlotnoSurveynoHouseFlatno(request.getPlotnoSurveynoHouseFlatno());
        accountInfoDet.setPolicyEndDate(request.getPolicyEndDate());
        accountInfoDet.setPolicyTerm(request.getPolicyTerm());
        accountInfoDet.setPolicyType(request.getPolicyType());
        accountInfoDet.setRateofInterest(request.getRateofInterest());
        accountInfoDet.setSanctionDate(request.getSanctionDate());
        accountInfoDet.setSecurityCount(request.getSecurityCount());
        accountInfoDet.setSecurityDetails(request.getSecurityDetails());
        accountInfoDet.setSumAssured(request.getSumAssured());
        accountInfoDet.setTransactionFrequency(request.getTransactionFrequency());
        accountInfoDet.setTransactionId(request.getTransactionId());
        accountInfoDet.setUid(request.getUid());
        accountInfoDet.setEuid(request.getEuid());
        accountInfoDet.setStatus(Status.ACTIVE);
        accountInfoDet.setCreatedAt(LocalDateTime.now());
        return accountInfoDet;
    }

    public void update(final UpdateAccountInfoDetRequest request) {
        this.setAccountNumber(request.getAccountNumber());
        this.setCustomerId(request.getCustomerId());
        this.setAccountRisk(request.getAccountRisk());
        this.setAccountRiskEffectiveDate(request.getAccountRiskEffectiveDate());
        this.setAccountRiskNextReviewDate(request.getAccountRiskNextReviewDate());
        this.setAccountSegment(request.getAccountSegment());
        this.setAccountSegmentEffectiveDate(request.getAccountSegmentEffectiveDate());
        this.setAccountType(request.getAccountType());
        this.setApplicationNumber(request.getApplicationNumber());
        this.setApplicationSignedDate(request.getApplicationSignedDate());
        this.setAsOfDate(request.getAsOfDate());
        this.setBankCode(request.getBankCode());
        this.setBankName(request.getBankName());
        this.setBankbranchname(request.getBankbranchname());
        this.setChannel(request.getChannel());
        this.setClientStatus(request.getClientStatus());
        this.setCreditorBusinessUnit(request.getCreditorBusinessUnit());
        this.setCreditorRMEmail(request.getCreditorRMEmail());
        this.setCurrency(request.getCurrency());
        this.setDpid(request.getDpid());
        this.setFundedType(request.getFundedType());
        this.setGrossAnnualPremiumwithTax(request.getGrossAnnualPremiumwithTax());
        this.setGrossAnnualPremiumwithoutTax(request.getGrossAnnualPremiumwithoutTax());
        this.setIfscCode(request.getIfscCode());
        this.setIncomeMultiplier(request.getIncomeMultiplier());
        this.setInsurancePurpose(request.getInsurancePurpose());
        this.setIntermediaryCode(request.getIntermediaryCode());
        this.setIntroducerEmployeeCode(request.getIntroducerEmployeeCode());
        this.setMicrCode(request.getMicrCode());
        this.setModalPremium(request.getModalPremium());
        this.setModuleApplicable(request.getModuleApplicable());
        this.setParentCompany(request.getParentCompany());
        this.setPersonalEmail(request.getPersonalEmail());
        this.setPersonalMobileISD(request.getPersonalMobileISD());
        this.setPersonalMobileNumber(request.getPersonalMobileNumber());
        this.setPlotnoSurveynoHouseFlatno(request.getPlotnoSurveynoHouseFlatno());
        this.setPolicyEndDate(request.getPolicyEndDate());
        this.setPolicyTerm(request.getPolicyTerm());
        this.setPolicyType(request.getPolicyType());
        this.setRateofInterest(request.getRateofInterest());
        this.setSanctionDate(request.getSanctionDate());
        this.setSecurityCount(request.getSecurityCount());
        this.setSecurityDetails(request.getSecurityDetails());
        this.setSumAssured(request.getSumAssured());
        this.setTransactionFrequency(request.getTransactionFrequency());
        this.setTransactionId(request.getTransactionId());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}
