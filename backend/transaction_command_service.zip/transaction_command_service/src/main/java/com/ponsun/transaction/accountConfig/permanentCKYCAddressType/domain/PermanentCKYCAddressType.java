package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.UpdatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.CreatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_permanent_CKYC_address_type")
public class PermanentCKYCAddressType extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static PermanentCKYCAddressType create(final CreatePermanentCKYCAddressTypeRequest request) {
        final PermanentCKYCAddressType PermanentCKYCAddressType = new PermanentCKYCAddressType();
        PermanentCKYCAddressType.setName(request.getName());
        PermanentCKYCAddressType.setCode(request.getCode());
        PermanentCKYCAddressType.setUid(request.getUid());
        PermanentCKYCAddressType.setEuid(request.getEuid());
        PermanentCKYCAddressType.setStatus(Status.ACTIVE);
        PermanentCKYCAddressType.setCreatedAt(LocalDateTime.now());
        return PermanentCKYCAddressType;
    }

    public void update(final UpdatePermanentCKYCAddressTypeRequest request) {
        this.setName(request.getName());
        this.setCode(request.getCode());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}
