package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.services;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.UpdatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.CreatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface PermanentCKYCAddressTypeWriteService {
    Response createAccAddressType(CreatePermanentCKYCAddressTypeRequest request);
    Response updateAccAddressType(Integer id, UpdatePermanentCKYCAddressTypeRequest request);
    Response unblockAccAddressType(Integer id);
    Response deactive(Integer id, Integer euid);

}

