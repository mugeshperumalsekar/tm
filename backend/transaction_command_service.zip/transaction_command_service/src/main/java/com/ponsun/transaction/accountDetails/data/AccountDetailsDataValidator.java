package com.ponsun.transaction.accountDetails.data;

import com.ponsun.transaction.accountDetails.request.CreateAccountDetailsRequest;
import com.ponsun.transaction.accountDetails.request.UpdateAccountDetailsRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountDetailsDataValidator {

    public void validateSaveAccountDetailsData(final CreateAccountDetailsRequest request)  {
        if(request.getSender() == null || request.getSender().equals("")){
           throw new PS_transaction_ApplicationException("Sender parameter required");
        }
    }
    public void validateUpdateAccountDetailsData(final UpdateAccountDetailsRequest request){
        if(request.getSender() == null || request.getBalance().equals("")){
            throw new PS_transaction_ApplicationException("Sender parameter required");
        }
    }
}
