package com.ponsun.transaction.accountConfig.productAccountType.services;

import com.ponsun.transaction.accountConfig.productAccountType.domain.ProductAccountType;

import java.util.List;

public interface ProductAccountTypeReadService {
    ProductAccountType fetchProductAccountById(Integer id);

    List<ProductAccountType> fetchAllProductAccount();

    List<ProductAccountType> fetchActiveProductAccountType();

    List<ProductAccountType> fetchDeActiveProductAccountType();
}
