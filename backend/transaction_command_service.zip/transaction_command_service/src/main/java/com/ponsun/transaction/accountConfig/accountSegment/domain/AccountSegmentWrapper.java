package com.ponsun.transaction.accountConfig.accountSegment.domain;
import com.ponsun.transaction.accountConfig.accountSegment.requests.AbstractAccountSegmentRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AccountSegmentWrapper extends AbstractAccountSegmentRequest {

    private final AccountSegmentRepository repository;

    @Transactional
    public AccountSegment findOneWithNotFoundDetection (final Integer id) {
    return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("AccountSegment Not found " + id));
}
    @Override
    public String toString(){
        return super.toString();
    }

}
