package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.data;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.CreatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.UpdatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PermanentCKYCAddressTypeValidator {
    public void validateSaveAccAddressType(final CreatePermanentCKYCAddressTypeRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("name parameter required");
        }
    }
    public void validateUpdateAccAddressType(final UpdatePermanentCKYCAddressTypeRequest request){
        if(request.getName() == null || request.getName().equals("")) {
            throw new PS_transaction_ApplicationException("name parameter required");

        }
    }
}

