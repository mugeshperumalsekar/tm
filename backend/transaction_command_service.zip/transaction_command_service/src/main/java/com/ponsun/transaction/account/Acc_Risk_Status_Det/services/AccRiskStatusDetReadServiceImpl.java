package com.ponsun.transaction.account.Acc_Risk_Status_Det.services;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDet;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDetRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccRiskStatusDetReadServiceImpl implements AccRiskStatusDetReadService {
    private final AccRiskStatusDetRepository repository;

    @Override
    @Transactional
    public AccRiskStatusDet fetchAccRiskStatusDetById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccRiskStatusDet> fetchAllAccRiskStatusDet() {
        return this.repository.findAll();
    }

    @Override
    public List<AccRiskStatusDet> fetchActiveAccRiskStatusDet() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccRiskStatusDet> fetchDeActiveAccRiskStatusDet() {
        return repository.findByStatus(Status.DELETE);
    }
}
