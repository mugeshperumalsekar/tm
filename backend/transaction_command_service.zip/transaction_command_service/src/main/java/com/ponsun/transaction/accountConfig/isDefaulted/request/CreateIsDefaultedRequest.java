package com.ponsun.transaction.accountConfig.isDefaulted.request;

import lombok.Data;

@Data
public class CreateIsDefaultedRequest extends AbstractIsDefaultedRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

