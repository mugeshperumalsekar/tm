package com.ponsun.transaction.adminconfiguration.AdminUser.api;
import com.ponsun.transaction.adminconfiguration.AdminUser.domain.User;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.CreateUserRequest;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.LoginUserDto;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.UpdateUserRequest;
import com.ponsun.transaction.adminconfiguration.AdminUser.services.UserReadPlatformService;
import com.ponsun.transaction.adminconfiguration.AdminUser.services.UserWritePlatformService;
import com.ponsun.transaction.infrastructure.utils.LoginResponse;
import com.ponsun.transaction.infrastructure.utils.Response;
import com.ponsun.transaction.securityconfiguration.services.JwtService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/users")
@Tag(name = "UserApiResource")
public class UserApiResource {

    private final UserWritePlatformService userWritePlatformService;
    private final UserReadPlatformService userReadPlatformService;
    private final JwtService jwtService;

    @PostMapping("/createUserRequest")
    public Response saveUser(@RequestBody CreateUserRequest createUserRequest) {
        log.debug("START saveUser request body {}",createUserRequest);
        Response response = this.userWritePlatformService.createUser(createUserRequest);
        log.debug("START saveUser response",response);
        return response;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> authenticate(@RequestBody LoginUserDto loginUserDto) {
        User authenticatedUser = this.userWritePlatformService.authenticate(loginUserDto);
        String jwtToken = jwtService.generateToken(authenticatedUser);
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setId(authenticatedUser.getId());
        loginResponse.setFullName(authenticatedUser.getFullName());
        loginResponse.setToken(jwtToken);
        loginResponse.setExpiresIn(jwtService.getExpirationTime());
        loginResponse.setRoleId(authenticatedUser.getRoleId());
        loginResponse.setEmail(authenticatedUser.getEmail());
        return ResponseEntity.ok(loginResponse);
    }

    @GetMapping
    public List<User> fetchAll() {
        return this.userReadPlatformService.fetchAllUsers();
    }

    @GetMapping("/{id}")
    public User fetchUserById(@PathVariable(name = "id") Integer id) {
        return this.userReadPlatformService.fetchUserById(id);
    }

    @PutMapping("/{id}")
    public Response updateUser(@PathVariable Integer id, @RequestBody UpdateUserRequest updateUserRequest) {
        log.debug("START updateUser request body {}",updateUserRequest);
        Response response = this.userWritePlatformService.updateUser(id, updateUserRequest);
        log.debug("START updateUser response",response);
        return response;
    }

    @PutMapping("/{id}/block")
    public Response blockUser(@PathVariable Integer id) {
        Response response = this.userWritePlatformService.blockUser(id);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockUser(@PathVariable Integer id) {
        Response response = this.userWritePlatformService.unblockUser(id);
        return response;
    }

}
