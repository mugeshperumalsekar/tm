package com.ponsun.transaction.accountConfig.accountRelation.domain;


import com.ponsun.transaction.accountConfig.accountRelation.request.AbstractAccountRelationRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AccountRelationWrapper extends AbstractAccountRelationRequest {
    private final AccountRelationRepository accountRelationRepository;

    @Transactional
    public AccountRelation findOneWithNotFoundDetection(final Integer id) {
        return this.accountRelationRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("AccountRelation Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }
}

