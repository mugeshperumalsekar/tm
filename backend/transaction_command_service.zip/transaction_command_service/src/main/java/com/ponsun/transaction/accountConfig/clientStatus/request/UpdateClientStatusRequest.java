package com.ponsun.transaction.accountConfig.clientStatus.request;

import lombok.Data;

@Data
public class UpdateClientStatusRequest extends AbstractClientStatusRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

