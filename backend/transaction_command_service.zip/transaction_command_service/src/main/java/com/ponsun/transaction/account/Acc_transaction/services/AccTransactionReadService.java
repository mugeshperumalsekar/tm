package com.ponsun.transaction.account.Acc_transaction.services;
import com.ponsun.transaction.account.Acc_transaction.data.AccTransactionData;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransaction;

import java.util.List;

public interface AccTransactionReadService {
    AccTransaction fetchAccTransactionById(Integer id);
    List<AccTransaction> fetchAllAccTransaction();
    List<AccTransaction> fetchActiveAccTransaction();
    List<AccTransaction> fetchDeActiveAccTransaction();
    List<AccTransactionData> fetchAllTransactionGroupByAccountId();

    void Iscalc(Integer id);
}
