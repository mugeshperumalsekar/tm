package com.ponsun.transaction.accountConfig.natureOfCredit.request;

import lombok.Data;

@Data
public class AbstractNatureOfCreditRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
