package com.ponsun.transaction.accountConfig.reasonCode.domain;

import com.ponsun.transaction.accountConfig.reasonCode.request.CreateReasonCodeRequest;
import com.ponsun.transaction.accountConfig.reasonCode.request.UpdateReasonCodeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_ReasonCode")
public class ReasonCode extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static ReasonCode create(final CreateReasonCodeRequest createReasonCodeRequest){
        final ReasonCode reasonCode = new ReasonCode();
        reasonCode.setName(createReasonCodeRequest.getName());
        reasonCode.setCode(createReasonCodeRequest.getCode());
        reasonCode.setUid(createReasonCodeRequest.getUid());
        reasonCode.setStatus(Status.ACTIVE);
        reasonCode.setCreatedAt(LocalDateTime.now());
        return reasonCode;
    }
    public void update(final UpdateReasonCodeRequest updateReasonCodeRequest){
        this.setName(updateReasonCodeRequest.getName());
        this.setCode(updateReasonCodeRequest.getCode());
        this.setEuid(updateReasonCodeRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

