package com.ponsun.transaction.accountConfig.lendingArrangement.api;



import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangement;
import com.ponsun.transaction.accountConfig.lendingArrangement.request.CreateLendingArrangementRequest;
import com.ponsun.transaction.accountConfig.lendingArrangement.request.UpdateLendingArrangementRequest;
import com.ponsun.transaction.accountConfig.lendingArrangement.services.LendingArrangementReadService;
import com.ponsun.transaction.accountConfig.lendingArrangement.services.LendingArrangementWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/LendingArrangement")
@Tag(name = "LendingArrangementApiResource")
public class LendingArrangementApiResources {
    private final LendingArrangementWriteService lendingArrangementWriteService;
    private final LendingArrangementReadService lendingArrangementReadService;

    @PostMapping("/CreateLendingArrangementRequest")
    public Response saveLendingArrangement(@RequestBody CreateLendingArrangementRequest createLendingArrangementRequest) {
        log.debug("START saveLendingArrangement request body {}",createLendingArrangementRequest);
        Response response = this.lendingArrangementWriteService.createLendingArrangement(createLendingArrangementRequest);
        log.debug("START saveLendingArrangement response",response);
        return response;
    }

    @GetMapping
    public List<LendingArrangement> fetchAll() {
        return this.lendingArrangementReadService.fetchAllLendingArrangement();
    }

    @GetMapping("/{id}")
    public LendingArrangement fetchLendingArrangementById(@PathVariable(name = "id") Integer id) {
        return this.lendingArrangementReadService.fetchLendingArrangementById(id);
    }

    @PutMapping("/{id}")
    public Response updateLendingArrangement(@PathVariable Integer id, @RequestBody UpdateLendingArrangementRequest updateLendingArrangementRequest) {
        log.debug("START updateLendingArrangement request body {}",updateLendingArrangementRequest);
        Response response = this.lendingArrangementWriteService.updateLendingArrangement(id, updateLendingArrangementRequest);
        log.debug("START updateLendingArrangement response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockLendingArrangement(@PathVariable Integer id){
        Response response = this.lendingArrangementWriteService.unblockLendingArrangement(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.lendingArrangementWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<LendingArrangement> fetchActiveLendingArrangement() {
        return lendingArrangementReadService.fetchActiveLendingArrangement();
    }
    @GetMapping("DeActive")
    public List<LendingArrangement> fetchDeLendingArrangement() {
        return lendingArrangementReadService.fetchDeActiveLendingArrangement();
    }

}

