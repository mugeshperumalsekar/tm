package com.ponsun.transaction.accountConfig.natureOfCredit.data;


import com.ponsun.transaction.accountConfig.natureOfCredit.request.CreateNatureOfCreditRequest;
import com.ponsun.transaction.accountConfig.natureOfCredit.request.UpdateNatureOfCreditRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class NatureOfCreditValidator {
    public void validateSaveNatureOfCredit(final CreateNatureOfCreditRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateNatureOfCredit(final UpdateNatureOfCreditRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");


        }
    }
}
