package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.services;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentCKYCAddressTypeRepository;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentCKYCAddressType;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@RequiredArgsConstructor
@Slf4j
public class PermanentCKYCAddressTypeReadServiceImpl implements PermanentCKYCAddressTypeReadService {
    private final PermanentCKYCAddressTypeRepository repository;

    @Override
    @Transactional
    public PermanentCKYCAddressType fetchAccAddressTypeById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<PermanentCKYCAddressType> fetchAllAccAddressType() {
        return this.repository.findAll();
    }

    @Override
    public List<PermanentCKYCAddressType> fetchActivePermanentCKYCAddressType() {
        return this.repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<PermanentCKYCAddressType> fetchDeActivePermanentCKYCAddressType() {
        return this.repository.findByStatus(Status.DELETE);
    }
}
