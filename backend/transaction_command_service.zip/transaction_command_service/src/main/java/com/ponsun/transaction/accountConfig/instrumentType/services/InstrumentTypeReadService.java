package com.ponsun.transaction.accountConfig.instrumentType.services;

import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentType;

import java.util.List;

public interface InstrumentTypeReadService {

    InstrumentType fetchInstrumentTypeById(Integer id);

    List<InstrumentType> fetchAllInstrumentType();

    List<InstrumentType> fetchActiveInstrumentType();

    List<InstrumentType> fetchDeActiveInstrumentType();
}
