package com.ponsun.transaction.accountConfig.debtSubType.request;

import lombok.Data;

@Data
public class UpdateDebtSubTypeRequest extends AbstractDebtSubTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
