package com.ponsun.transaction.accountConfig.transactionFrequency.data;
import lombok.Data;
@Data
public class TransactionFrequencyData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public TransactionFrequencyData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static TransactionFrequencyData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new TransactionFrequencyData(id,name,code,uid,euid);
    }
}

