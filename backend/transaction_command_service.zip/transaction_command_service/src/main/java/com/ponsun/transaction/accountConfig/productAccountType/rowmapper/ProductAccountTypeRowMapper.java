package com.ponsun.transaction.accountConfig.productAccountType.rowmapper;

import com.ponsun.transaction.accountConfig.productAccountType.data.ProductAccountTypeData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
@Data
@Service
@Slf4j
public class ProductAccountTypeRowMapper implements RowMapper<ProductAccountTypeData> {
    public final String schema;
    public ProductAccountTypeRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM tm_config_product_account_type pct ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("pct.id as id ,");
        builder.append("pct.name as name ,");
        builder.append("pct.code as code ,");
        builder.append("pct.uid as uid ,");
        builder.append("pct.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public ProductAccountTypeData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final String name = rs.getString("name");
        final String code = rs.getString("code");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new ProductAccountTypeData(id, name, code, uid, euid);
    }
}
