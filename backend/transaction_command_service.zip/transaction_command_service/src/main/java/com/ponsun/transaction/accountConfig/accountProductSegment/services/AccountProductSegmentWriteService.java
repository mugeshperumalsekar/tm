package com.ponsun.transaction.accountConfig.accountProductSegment.services;

import com.ponsun.transaction.accountConfig.accountProductSegment.requests.UpdateAccountProductSegmentRequest;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.CreateAccountProductSegmentRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccountProductSegmentWriteService {
    Response createAccProductSegment(CreateAccountProductSegmentRequest request);
    Response updateAccProductSegment(Integer id, UpdateAccountProductSegmentRequest request);
    Response unblockAccProductSegment(Integer id);
    Response deactive(Integer id, Integer euid);

}

