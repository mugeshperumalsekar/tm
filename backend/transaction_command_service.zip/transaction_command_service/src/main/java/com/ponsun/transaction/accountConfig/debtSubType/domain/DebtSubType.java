package com.ponsun.transaction.accountConfig.debtSubType.domain;

import com.ponsun.transaction.accountConfig.debtSubType.request.UpdateDebtSubTypeRequest;
import com.ponsun.transaction.accountConfig.debtSubType.request.CreateDebtSubTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_DebtSubType")
public class DebtSubType extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static DebtSubType create(final CreateDebtSubTypeRequest createDebtSubTypeRequest){
        final DebtSubType debtSubType = new DebtSubType();
        debtSubType.setName(createDebtSubTypeRequest.getName());
        debtSubType.setCode(createDebtSubTypeRequest.getCode());
        debtSubType.setUid(createDebtSubTypeRequest.getUid());
        debtSubType.setStatus(Status.ACTIVE);
        debtSubType.setCreatedAt(LocalDateTime.now());
        return debtSubType;
    }
    public void update(final UpdateDebtSubTypeRequest updateDebtSubTypeRequest){
        this.setName(updateDebtSubTypeRequest.getName());
        this.setCode(updateDebtSubTypeRequest.getCode());
        this.setEuid(updateDebtSubTypeRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

