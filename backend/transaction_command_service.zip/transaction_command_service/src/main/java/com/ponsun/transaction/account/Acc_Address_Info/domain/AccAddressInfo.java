package com.ponsun.transaction.account.Acc_Address_Info.domain;

import com.ponsun.transaction.account.Acc_Address_Info.requests.CreateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Address_Info.requests.UpdateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;
import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_adress_info")
public class AccAddressInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "accountId", referencedColumnName = "id", nullable = false)
    private AccInfo accInfo; // Assuming Account is the entity representing tm_acc_info

    @Column(name = "customerId")
    private Integer customerId;

    @Column(name = "correspondenceAddressCity" , columnDefinition = "TEXT")
    private String correspondenceAddressCity;

    @Column(name = "correspondenceAddressCountry")
    private String correspondenceAddressCountry;

    @Column(name = "correspondenceAddressDistrict" , columnDefinition = "TEXT")
    private String correspondenceAddressDistrict;

    @Column(name = "correspondenceAddressLine1" , columnDefinition = "TEXT")
    private String correspondenceAddressLine1;

    @Column(name = "correspondenceAddressLine2" , columnDefinition = "TEXT")
    private String correspondenceAddressLine2;

    @Column(name = "correspondenceAddressLine3" , columnDefinition = "TEXT")
    private String correspondenceAddressLine3;

    @Column(name = "correspondenceAddressPinCode")
    private String correspondenceAddressPinCode;

    @Column(name = "correspondenceAddressProof")
    private String correspondenceAddressProof;

    @Column(name = "correspondenceAddressState" , columnDefinition = "TEXT")
    private String correspondenceAddressState;

    @Column(name = "permanentAddressCity" , columnDefinition = "TEXT")
    private String permanentAddressCity;

    @Column(name = "permanentAddressCountry")
    private String permanentAddressCountry;

    @Column(name = "permanentAddressDistrict" , columnDefinition = "TEXT")
    private String permanentAddressDistrict;

    @Column(name = "permanentAddressLine1" , columnDefinition = "TEXT")
    private String permanentAddressLine1;

    @Column(name = "permanentAddressLine2" , columnDefinition = "TEXT")
    private String permanentAddressLine2;

    @Column(name = "permanentAddressLine3" , columnDefinition = "TEXT")
    private String permanentAddressLine3;

    @Column(name = "permanentAddressPinCode")
    private String permanentAddressPinCode;

    @Column(name = "permanentAddressProof")
    private String permanentAddressProof;

    @Column(name = "permanentAddressState" , columnDefinition = "TEXT")
    private String permanentAddressState;

    @Column(name = "permanentCKYCAddressType" , columnDefinition = "TEXT")
    private String permanentCKYCAddressType;

//    @Column(name = "accountId")
//    private Integer accountId;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccAddressInfo create(final CreateAccAddressInfoRequest request, AccInfo accInfo) {
        final AccAddressInfo accAddressInfo = new AccAddressInfo();
        accAddressInfo.setAccInfo(accInfo);
        accAddressInfo.setCustomerId(request.getCustomerId());
        accAddressInfo.setCorrespondenceAddressCity(request.getCorrespondenceAddressCity());
        accAddressInfo.setCorrespondenceAddressCountry(request.getCorrespondenceAddressCountry());
        accAddressInfo.setCorrespondenceAddressDistrict(request.getCorrespondenceAddressDistrict());
        accAddressInfo.setCorrespondenceAddressLine1(request.getCorrespondenceAddressLine1());
        accAddressInfo.setCorrespondenceAddressLine2(request.getCorrespondenceAddressLine2());
        accAddressInfo.setCorrespondenceAddressLine3(request.getCorrespondenceAddressLine3());
        accAddressInfo.setCorrespondenceAddressPinCode(request.getCorrespondenceAddressPinCode());
        accAddressInfo.setCorrespondenceAddressProof(request.getCorrespondenceAddressProof());
        accAddressInfo.setCorrespondenceAddressState(request.getCorrespondenceAddressState());
        accAddressInfo.setPermanentAddressCity(request.getPermanentAddressCity());
        accAddressInfo.setPermanentAddressCountry(request.getPermanentAddressCountry());
        accAddressInfo.setPermanentAddressDistrict(request.getPermanentAddressDistrict());
        accAddressInfo.setPermanentAddressLine1(request.getPermanentAddressLine1());
        accAddressInfo.setPermanentAddressLine2(request.getPermanentAddressLine2());
        accAddressInfo.setPermanentAddressLine3(request.getPermanentAddressLine3());
        accAddressInfo.setPermanentAddressPinCode(request.getPermanentAddressPinCode());
        accAddressInfo.setPermanentAddressProof(request.getPermanentAddressProof());
        accAddressInfo.setPermanentAddressState(request.getPermanentAddressState());
        accAddressInfo.setPermanentCKYCAddressType(request.getPermanentCKYCAddressType());
        accAddressInfo.setUid(request.getUid());
        accAddressInfo.setEuid(request.getEuid());
        accAddressInfo.setStatus(Status.ACTIVE);
        accAddressInfo.setCreatedAt(LocalDateTime.now());
        return accAddressInfo;
    }
    public void update(final UpdateAccAddressInfoRequest request) {
        this.setCustomerId(request.getCustomerId());
        this.setCorrespondenceAddressCity(request.getCorrespondenceAddressCity());
        this.setCorrespondenceAddressCountry(request.getCorrespondenceAddressCountry());
        this.setCorrespondenceAddressDistrict(request.getCorrespondenceAddressDistrict());
        this.setCorrespondenceAddressLine1(request.getCorrespondenceAddressLine1());
        this.setCorrespondenceAddressLine2(request.getCorrespondenceAddressLine2());
        this.setCorrespondenceAddressLine3(request.getCorrespondenceAddressLine3());
        this.setCorrespondenceAddressPinCode(request.getCorrespondenceAddressPinCode());
        this.setCorrespondenceAddressProof(request.getCorrespondenceAddressProof());
        this.setCorrespondenceAddressState(request.getCorrespondenceAddressState());
        this.setPermanentAddressCity(request.getPermanentAddressCity());
        this.setPermanentAddressCountry(request.getPermanentAddressCountry());
        this.setPermanentAddressDistrict(request.getPermanentAddressDistrict());
        this.setPermanentAddressLine1(request.getPermanentAddressLine1());
        this.setPermanentAddressLine2(request.getPermanentAddressLine2());
        this.setPermanentAddressLine3(request.getPermanentAddressLine3());
        this.setPermanentAddressPinCode(request.getPermanentAddressPinCode());
        this.setPermanentAddressProof(request.getPermanentAddressProof());
        this.setPermanentAddressState(request.getPermanentAddressState());
        this.setPermanentCKYCAddressType(request.getPermanentCKYCAddressType());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}


