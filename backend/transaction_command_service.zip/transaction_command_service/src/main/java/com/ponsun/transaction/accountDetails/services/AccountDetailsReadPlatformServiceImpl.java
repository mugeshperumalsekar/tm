package com.ponsun.transaction.accountDetails.services;

import com.ponsun.transaction.accountDetails.domain.AccountDetails;
import com.ponsun.transaction.accountDetails.domain.AccountDetailsRepository;
import com.ponsun.transaction.accountDetails.domain.AccountDetailsRepositoryWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountDetailsReadPlatformServiceImpl implements AccountDetailsReadPlatformService{

    private final AccountDetailsRepositoryWrapper accountDetailsRepositoryWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final AccountDetailsRepository accountDetailsRepository;
    @Override
    public AccountDetails fetchAccountDetailsById(Integer id){
        return this.accountDetailsRepository.findById(id).get();
    }
    @Override
    public List<AccountDetails> fetchAllAccountDetails(){ return this.accountDetailsRepository.findAll();}
}
