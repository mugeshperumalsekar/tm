package com.ponsun.transaction.account.Acc_transaction.data;
import com.ponsun.transaction.transactionConfig.precalcthreshold.domain.PreCalcThreshold;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AccTransactionData {

    private Integer id;
    private Integer accountId;
    private double amt;
    private String applicationNumber;
    private String cardSubtype;
    private String cardType;
    private String clientBankName;
    private String clientBankCode;
    private String clientBankAccountNo;
    private String counterPartyProductAccountType;
    private String counterPartyProductAccountNumber;
    private String instrumentType;
    private String instrumentNo;
    private String originalCurrency;
    private String organisationPoolAccount;
    private String transactionType;
    private Integer transactionCount;
    private PreCalcThreshold preCalcThreshold;
    private Integer isCalc;
    private Integer segmentId;
    private Integer customerId;
    private Integer CustomerTypeId;
    private Integer customerCategoryId;
    private Integer customerRiskId;
    private String customerRisk;
    private Integer accountRiskId;
    private LocalDateTime createdAt;
    private Integer instrumentTypeId;
    private Integer voucherTypeId;
    private Integer payTypeId;
    private String userId;
    private String uid;
    private Integer euid;

    private Integer sumCountCrntDay;
    private Integer sumCountPreDay;
    private Integer sumCountCrntMonth;
    private Integer sumCountPrevOneMonth;
    private Integer sumCountPrevThreeMonth;
    private Integer sumCountPrevSixMonth;
    private Integer sumCountPrevNineMonth;
    private Integer sumCountPrevTwelveMonth;
    private Integer avgCountCrntDay;
    private Integer avgCountPreDay;
    private Integer avgCountCrntMonth;
    private Integer avgCountPrevOneMonth;
    private Integer avgCountPrevThreeMonth;
    private Integer avgCountPrevSixMonth;
    private Integer avgCountPrevNineMonth;
    private Integer avgCountPrevTwelveMonth;
    private Integer maxCountCrntDay;
    private Integer maxCountPreDay;
    private Integer maxCountCrntMonth;
    private Integer maxCountPrevOneMonth;
    private Integer maxCountPrevThreeMonth;
    private Integer maxCountPrevSixMonth;
    private Integer maxCountPrevNineMonth;
    private Integer maxCountPrevTwelveMonth;

    private Double sumAmtCrntDay;
    private Double sumAmtPrevDay;
    private Double sumAmtCrntMonth;
    private Double sumAmtPrevOneMonth;
    private Double sumAmtPrevThreeMonth;
    private Double sumAmtPrevSixMonth;
    private Double sumAmtPrevNineMonth;
    private Double sumAmtPrevTwelveMonth;

    private Double maxAmtCrntDay;
    private Double maxAmtPrevDay;
    private Double maxAmtCrntMonth;
    private Double maxAmtPrevOneMonth;
    private Double maxAmtPrevThreeMonth;
    private Double maxAmtPrevSixMonth;
    private Double maxAmtPrevNineMonth;
    private Double maxAmtPrevTwelveMonth;

    private Double avgAmtCrntDay;
    private Double avgAmtPrevDay;
    private Double avgAmtCrntMonth;
    private Double avgAmtPrevOneMonth;
    private Double avgAmtPrevThreeMonth;
    private Double avgAmtPrevSixMonth;
    private Double avgAmtPrevNineMonth;
    private Double avgAmtPrevTwelveMonth;


    public AccTransactionData(Integer id, Integer accountId, double amt, String applicationNumber, String cardSubtype, String cardType, String clientBankName, String clientBankCode, String clientBankAccountNo, String counterPartyProductAccountType, String counterPartyProductAccountNumber, String instrumentType, String instrumentNo, String originalCurrency, String organisationPoolAccount, String transactionType, Integer transactionCount, Integer isCalc, Integer segmentId, Integer customerId, Integer customerTypeId, Integer customerCategoryId, Integer customerRiskId, String customerRisk, Integer accountRiskId, LocalDateTime createdAt, Integer instrumentTypeId, Integer voucherTypeId, Integer payTypeId,String userId, String uid, Integer euid,
                              final Integer sumCountCrntDay, final Integer sumCountPreDay, final Integer sumCountCrntMonth, final Integer sumCountPrevOneMonth, final Integer sumCountPrevThreeMonth, final Integer sumCountPrevSixMonth, final Integer sumCountPrevNineMonth, final Integer sumCountPrevTwelveMonth, final Integer avgCountCrntDay, final Integer avgCountPreDay, final Integer avgCountCrntMonth, final Integer avgCountPrevOneMonth, final Integer avgCountPrevThreeMonth, final Integer avgCountPrevSixMonth, final Integer avgCountPrevNineMonth, final Integer avgCountPrevTwelveMonth, final Integer maxCountCrntDay, final Integer maxCountPreDay, final Integer maxCountCrntMonth, final Integer maxCountPrevOneMonth, final Integer maxCountPrevThreeMonth, final Integer maxCountPrevSixMonth, final Integer maxCountPrevNineMonth, final Integer maxCountPrevTwelveMonth,
                              final Double sumAmtCrntDay, final Double maxAmtCrntDay, final Double avgAmtCrntDay, final Double sumAmtCrntMonth, final Double maxAmtCrntMonth, final Double avgAmtCrntMonth,
                              final Double sumAmtPrevDay,final Double maxAmtPrevDay,final Double avgAmtPrevDay,final Double sumAmtPrevOneMonth ,Double sumAmtPrevThreeMonth ,Double sumAmtPrevSixMonth ,Double sumAmtPrevNineMonth ,Double sumAmtPrevTwelveMonth ,Double maxAmtPrevOneMonth ,Double maxAmtPrevThreeMonth ,Double maxAmtPrevSixMonth ,Double maxAmtPrevNineMonth ,Double maxAmtPrevTwelveMonth ,Double avgAmtPrevOneMonth ,Double avgAmtPrevThreeMonth ,Double avgAmtPrevSixMonth ,Double avgAmtPrevNineMonth ,Double avgAmtPrevTwelveMonth) {
        this.id = id;
        this.accountId = accountId;
        this.amt = amt;
        this.applicationNumber = applicationNumber;
        this.cardSubtype = cardSubtype;
        this.cardType = cardType;
        this.clientBankName = clientBankName;
        this.clientBankCode = clientBankCode;
        this.clientBankAccountNo = clientBankAccountNo;
        this.counterPartyProductAccountType = counterPartyProductAccountType;
        this.counterPartyProductAccountNumber = counterPartyProductAccountNumber;
        this.instrumentType = instrumentType;
        this.instrumentNo = instrumentNo;
        this.originalCurrency = originalCurrency;
        this.organisationPoolAccount = organisationPoolAccount;
        this.transactionType = transactionType;
        this.transactionCount = transactionCount;
        this.isCalc = isCalc;
        this.segmentId = segmentId;
        this.customerId = customerId;
        CustomerTypeId = customerTypeId;
        this.customerCategoryId = customerCategoryId;
        this.customerRiskId = customerRiskId;
        this.customerRisk = customerRisk;
        this.accountRiskId = accountRiskId;
        this.createdAt = createdAt;
        this.instrumentTypeId = instrumentTypeId;
        this.voucherTypeId = voucherTypeId;
        this.payTypeId = payTypeId;
        this.userId = userId;
        this.uid = uid;
        this.euid = euid;

        this.sumCountCrntDay = sumCountCrntDay;
        this.sumCountPreDay = sumCountPreDay;
        this.sumCountCrntMonth = sumCountCrntMonth;
        this.sumCountPrevOneMonth = sumCountPrevOneMonth;
        this.sumCountPrevThreeMonth = sumCountPrevThreeMonth;
        this.sumCountPrevSixMonth = sumCountPrevSixMonth;
        this.sumCountPrevNineMonth = sumCountPrevNineMonth;
        this.sumCountPrevTwelveMonth = sumCountPrevTwelveMonth;
        this.avgCountCrntDay = avgCountCrntDay;
        this.avgCountPreDay = avgCountPreDay;
        this.avgCountCrntMonth = avgCountCrntMonth;
        this.avgCountPrevOneMonth = avgCountPrevOneMonth;
        this.avgCountPrevThreeMonth = avgCountPrevThreeMonth;
        this.avgCountPrevSixMonth = avgCountPrevSixMonth;
        this.avgCountPrevNineMonth = avgCountPrevNineMonth;
        this.avgCountPrevTwelveMonth = avgCountPrevTwelveMonth;
        this.maxCountCrntDay = maxCountCrntDay;
        this.maxCountPreDay = maxCountPreDay;
        this.maxCountCrntMonth = maxCountCrntMonth;
        this.maxCountPrevOneMonth = maxCountPrevOneMonth;
        this.maxCountPrevThreeMonth = maxCountPrevThreeMonth;
        this.maxCountPrevSixMonth = maxCountPrevSixMonth;
        this.maxCountPrevNineMonth = maxCountPrevNineMonth;
        this.maxCountPrevTwelveMonth = maxCountPrevTwelveMonth;

        this.sumAmtCrntDay = sumAmtCrntDay;
        this.maxAmtCrntDay = maxAmtCrntDay;
        this.avgAmtCrntDay = avgAmtCrntDay;
        this.sumAmtCrntMonth = sumAmtCrntMonth;
        this.maxAmtCrntMonth = maxAmtCrntMonth;
        this.avgAmtCrntMonth = avgAmtCrntMonth;

        this.sumAmtPrevDay=sumAmtPrevDay;
        this.maxAmtPrevDay=maxAmtPrevDay;
        this.avgAmtPrevDay=avgAmtPrevDay;

        this.sumAmtPrevOneMonth=sumAmtPrevOneMonth;
        this.sumAmtPrevThreeMonth=sumAmtPrevThreeMonth;
        this.sumAmtPrevSixMonth=sumAmtPrevSixMonth;
        this.sumAmtPrevNineMonth=sumAmtPrevNineMonth;
        this.sumAmtPrevTwelveMonth=sumAmtPrevTwelveMonth;
        this.maxAmtPrevOneMonth=maxAmtPrevOneMonth;
        this.maxAmtPrevThreeMonth=maxAmtPrevThreeMonth;
        this.maxAmtPrevSixMonth=maxAmtPrevSixMonth;
        this.maxAmtPrevNineMonth=maxAmtPrevNineMonth;
        this.maxAmtPrevTwelveMonth=maxAmtPrevTwelveMonth;
        this.avgAmtPrevOneMonth=avgAmtPrevOneMonth;
        this.avgAmtPrevThreeMonth=avgAmtPrevThreeMonth;
        this.avgAmtPrevSixMonth=avgAmtPrevSixMonth;
        this.avgAmtPrevNineMonth=avgAmtPrevNineMonth;
        this.avgAmtPrevTwelveMonth=avgAmtPrevTwelveMonth;
    }

    public static AccTransactionData newInstance(Integer id, Integer accountId, double amt, String applicationNumber, String cardSubtype, String cardType, String clientBankName, String clientBankCode, String clientBankAccountNo, String counterPartyProductAccountType, String counterPartyProductAccountNumber, String instrumentType, String instrumentNo, String originalCurrency, String organisationPoolAccount, String transactionType, Integer transactionCount, Integer isCalc, Integer segmentId, Integer customerId, Integer customerTypeId,
                                                 Integer customerCategoryId, Integer customerRiskId, String customerRisk, Integer accountRiskId, LocalDateTime createdAt, Integer instrumentTypeId, Integer voucherTypeId, Integer payTypeId,String userId, String uid, Integer euid,
                                                 Integer sumCountCrntDay, Integer sumCountPreDay, Integer sumCountCrntMonth, Integer sumCountPrevOneMonth, Integer sumCountPrevThreeMonth, Integer sumCountPrevSixMonth, Integer sumCountPrevNineMonth, Integer sumCountPrevTwelveMonth, Integer avgCountCrntDay, Integer avgCountPreDay, Integer avgCountCrntMonth, Integer avgCountPrevOneMonth, Integer avgCountPrevThreeMonth, Integer avgCountPrevSixMonth, Integer avgCountPrevNineMonth, Integer avgCountPrevTwelveMonth, Integer maxCountCrntDay, Integer maxCountPreDay, Integer maxCountCrntMonth, Integer maxCountPrevOneMonth, Integer maxCountPrevThreeMonth, Integer maxCountPrevSixMonth, Integer maxCountPrevNineMonth, Integer maxCountPrevTwelveMonth,
                                                 Double sumAmtCrntDay, Double maxAmtCrntDay, Double avgAmtCrntDay, Double sumAmtCrntMonth, Double maxAmtCrntMonth, Double avgAmtCrntMonth,Double sumAmtPrevDay, Double maxAmtPrevDay, Double avgAmtPrevDay,  Double sumAmtPrevOneMonth ,Double sumAmtPrevThreeMonth ,Double sumAmtPrevSixMonth ,Double sumAmtPrevNineMonth ,Double sumAmtPrevTwelveMonth ,Double maxAmtPrevOneMonth ,Double maxAmtPrevThreeMonth ,Double maxAmtPrevSixMonth ,Double maxAmtPrevNineMonth ,Double maxAmtPrevTwelveMonth ,Double avgAmtPrevOneMonth ,Double avgAmtPrevThreeMonth ,Double avgAmtPrevSixMonth ,Double avgAmtPrevNineMonth ,Double avgAmtPrevTwelveMonth) {
        return new AccTransactionData(
                id, accountId, amt, applicationNumber, cardSubtype, cardType, clientBankName, clientBankCode, clientBankAccountNo,
                counterPartyProductAccountType, counterPartyProductAccountNumber, instrumentType, instrumentNo, originalCurrency,
                organisationPoolAccount, transactionType, transactionCount, isCalc, segmentId, customerId, customerTypeId,
                customerCategoryId, customerRiskId, customerRisk, accountRiskId, createdAt, instrumentTypeId,voucherTypeId,payTypeId,userId, uid, euid,
                sumCountCrntDay, sumCountPreDay, sumCountCrntMonth, sumCountPrevOneMonth, sumCountPrevThreeMonth, sumCountPrevSixMonth, sumCountPrevNineMonth, sumCountPrevTwelveMonth, avgCountCrntDay, avgCountPreDay, avgCountCrntMonth, avgCountPrevOneMonth, avgCountPrevThreeMonth, avgCountPrevSixMonth, avgCountPrevNineMonth, avgCountPrevTwelveMonth, maxCountCrntDay, maxCountPreDay, maxCountCrntMonth, maxCountPrevOneMonth, maxCountPrevThreeMonth, maxCountPrevSixMonth, maxCountPrevNineMonth, maxCountPrevTwelveMonth,
                sumAmtCrntDay,maxAmtCrntDay,avgAmtCrntDay,sumAmtCrntMonth,maxAmtCrntMonth,avgAmtCrntMonth ,
                sumAmtPrevDay, maxAmtPrevDay, avgAmtPrevDay, sumAmtPrevOneMonth ,sumAmtPrevThreeMonth ,sumAmtPrevSixMonth ,sumAmtPrevNineMonth ,sumAmtPrevTwelveMonth ,maxAmtPrevOneMonth ,maxAmtPrevThreeMonth ,maxAmtPrevSixMonth ,maxAmtPrevNineMonth ,maxAmtPrevTwelveMonth ,avgAmtPrevOneMonth ,avgAmtPrevThreeMonth ,avgAmtPrevSixMonth ,avgAmtPrevNineMonth ,avgAmtPrevTwelveMonth);
    }

}
