package com.ponsun.transaction.accountConfig.natureOfCredit.services;

import com.ponsun.transaction.accountConfig.natureOfCredit.domain.NatureOfCredit;

import java.util.List;

public interface NatureOfCreditReadService {
    List<NatureOfCredit> fetchAllNatureOfCredit();

    NatureOfCredit fetchNatureOfCreditById(Integer id);

    List<NatureOfCredit> fetchActiveNatureOfCredit();

    List<NatureOfCredit> fetchDeActiveNatureOfCredit();
}
