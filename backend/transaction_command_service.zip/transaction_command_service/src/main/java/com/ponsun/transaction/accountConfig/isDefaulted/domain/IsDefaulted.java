package com.ponsun.transaction.accountConfig.isDefaulted.domain;

import com.ponsun.transaction.accountConfig.isDefaulted.request.CreateIsDefaultedRequest;
import com.ponsun.transaction.accountConfig.isDefaulted.request.UpdateIsDefaultedRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_IsDefaulted")
public class IsDefaulted extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static IsDefaulted create(final CreateIsDefaultedRequest createIsDefaultedRequest){
        final IsDefaulted isDefaulted = new IsDefaulted();
        isDefaulted.setName(createIsDefaultedRequest.getName());
        isDefaulted.setCode(createIsDefaultedRequest.getCode());
        isDefaulted.setUid(createIsDefaultedRequest.getUid());
        isDefaulted.setStatus(Status.ACTIVE);
        isDefaulted.setCreatedAt(LocalDateTime.now());
        return isDefaulted;
    }
    public void update(final UpdateIsDefaultedRequest updateIsDefaultedRequest){
        this.setName(updateIsDefaultedRequest.getName());
        this.setCode(updateIsDefaultedRequest.getCode());
        this.setEuid(updateIsDefaultedRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

