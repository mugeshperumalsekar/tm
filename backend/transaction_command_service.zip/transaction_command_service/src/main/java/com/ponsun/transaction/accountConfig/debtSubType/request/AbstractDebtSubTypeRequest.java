package com.ponsun.transaction.accountConfig.debtSubType.request;

import lombok.Data;

@Data
public class AbstractDebtSubTypeRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
