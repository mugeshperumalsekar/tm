package com.ponsun.transaction.account.Acc_Info.data;
import com.ponsun.transaction.account.Acc_Info.requests.CreateAccInfoRequest;
import com.ponsun.transaction.account.Acc_Info.requests.UpdateAccInfoRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccInfoValidator {
    public void validateSaveAccInfo(final CreateAccInfoRequest request){
        if (request.getProductAccountNumber()== null || request.getProductAccountNumber().equals("")){
            throw new PS_transaction_ApplicationException("ProductAccountNumber parameter required");
        }
    }
    public void validateUpdateAccInfo(final UpdateAccInfoRequest request){
        if(request.getProductAccountNumber() == null || request.getProductAccountNumber().equals("")) {
            throw new PS_transaction_ApplicationException("ProductAccountNumber parameter required");

        }
    }
}
