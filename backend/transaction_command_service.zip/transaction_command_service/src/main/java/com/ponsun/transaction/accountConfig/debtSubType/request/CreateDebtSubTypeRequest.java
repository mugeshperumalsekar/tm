package com.ponsun.transaction.accountConfig.debtSubType.request;

import lombok.Data;

@Data
public class CreateDebtSubTypeRequest extends AbstractDebtSubTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

