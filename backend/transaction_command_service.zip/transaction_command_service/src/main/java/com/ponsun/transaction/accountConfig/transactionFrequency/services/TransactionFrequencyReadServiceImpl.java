package com.ponsun.transaction.accountConfig.transactionFrequency.services;

import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequency;
import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequencyRepository;
import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequencyWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionFrequencyReadServiceImpl implements TransactionFrequencyReadService {
    private final TransactionFrequencyWrapper transactionFrequencyWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final TransactionFrequencyRepository transactionFrequencyRepository;

    @Override
    public TransactionFrequency fetchTransactionFrequencyById(Integer id) {
        return this.transactionFrequencyRepository.findById(id).get();
    }

    @Override
    public List<TransactionFrequency> fetchActiveTransactionFrequency() {
        return this.transactionFrequencyRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<TransactionFrequency> fetchDeActiveTransactionFrequency() {
        return this.transactionFrequencyRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<TransactionFrequency> fetchAllTransactionFrequency() {
        return this.transactionFrequencyRepository.findAll();
    }
}
