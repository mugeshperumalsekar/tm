package com.ponsun.transaction.accountConfig.insurancePurpose.domain;


import com.ponsun.transaction.accountConfig.insurancePurpose.request.AbstractInsurancePurposeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class InsurancePurposeWrapper extends AbstractInsurancePurposeRequest {
    private final InsurancePurposeRepository InsurancePurposeRepository;
    @Transactional
    public InsurancePurpose findOneWithNotFoundDetection(final Integer id) {
        return this.InsurancePurposeRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("InsurancePurpose Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }

}

