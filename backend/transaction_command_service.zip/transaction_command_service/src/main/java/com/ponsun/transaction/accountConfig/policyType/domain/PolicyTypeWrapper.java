package com.ponsun.transaction.accountConfig.policyType.domain;


import com.ponsun.transaction.accountConfig.policyType.request.AbstractPolicyTypeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PolicyTypeWrapper extends AbstractPolicyTypeRequest {
    private final PolicyTypeRepository policyTypeRepository;

    @Transactional
    public PolicyType findOneWithNotFoundDetection(final Integer id) {
        return this.policyTypeRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("PolicyType Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }
}

