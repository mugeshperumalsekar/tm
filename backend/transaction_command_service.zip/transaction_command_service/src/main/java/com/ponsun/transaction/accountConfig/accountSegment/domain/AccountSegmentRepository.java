package com.ponsun.transaction.accountConfig.accountSegment.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountSegmentRepository extends JpaRepository<AccountSegment,Integer> {

    List<AccountSegment> findByStatus (Status string);
}
