package com.ponsun.transaction.accountConfig.reasonCode.request;

import lombok.Data;

@Data
public class CreateReasonCodeRequest extends AbstractReasonCodeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

