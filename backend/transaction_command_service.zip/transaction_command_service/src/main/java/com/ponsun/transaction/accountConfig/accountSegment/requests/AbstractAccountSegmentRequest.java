package com.ponsun.transaction.accountConfig.accountSegment.requests;

import lombok.Data;

@Data
public class AbstractAccountSegmentRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
