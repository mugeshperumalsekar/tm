package com.ponsun.transaction.accountConfig.regAMLRisk.data;
import lombok.Data;
@Data
public class RegAMLRiskData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;


    public RegAMLRiskData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static RegAMLRiskData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new RegAMLRiskData(id,name,code,uid,euid);
    }
}

