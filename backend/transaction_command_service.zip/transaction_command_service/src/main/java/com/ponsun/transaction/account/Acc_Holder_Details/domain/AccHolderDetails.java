package com.ponsun.transaction.account.Acc_Holder_Details.domain;

import com.ponsun.transaction.account.Acc_Holder_Details.requests.CreateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.UpdateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_holder_details")
public class AccHolderDetails extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "accountId", referencedColumnName = "id", nullable = false)
    private AccInfo accInfo; // Assuming Account is the entity representing tm_acc_info

    @Column(name = "customerId")
    private Integer customerId;

    @Column(name = "borrowerDetails", columnDefinition = "TEXT")
    private String borrowerDetails;

    @Column(name = "branchReceiptDate" )
    private String branchReceiptDate;

    @Column(name = "dateofDefault" )
    private String dateofDefault;

    @Column(name = "dateofFilingofSuit" )
    private String dateofFilingofSuit;

    @Column(name = "dateofLastRepayment")
    private String dateofLastRepayment;

    @Column(name = "debtSubType")
    private String debtSubType;

    @Column(name = "defaultAmount")
    private double defaultAmount;

    @Column(name = "defaultRemarks" , columnDefinition = "TEXT")
    private String defaultRemarks;

    @Column(name = "disbursementDate")
    private String disbursementDate;

    @Column(name = "drawingPower")
    private double drawingPower;

    @Column(name = "emiAmount")
    private double emiAmount;

    @Column(name = "finalEMIDate" )
    private String finalEMIDate;

    @Column(name = "firstHolderRecordIdentifier" , columnDefinition = "TEXT")
    private String firstHolderRecordIdentifier;

    @Column(name = "firstHolderRelation" ,  columnDefinition = "TEXT")
    private String firstHolderRelation;

    @Column(name = "firstHolderSourceSystemCustomerCode")
    private String firstHolderSourceSystemCustomerCode;

    @Column(name = "firstHolderSourceSystemName")
    private String firstHolderSourceSystemName;

    @Column(name = "firstPremiumReceiptDate")
    private String firstPremiumReceiptDate;

    @Column(name = "interestOutstanding")
    private double interestOutstanding;

    @Column(name = "isDefaulted" , columnDefinition = "TEXT")
    private String isDefaulted;

    @Column(name = "isFamilyDeclaration")
    private String isFamilyDeclaration;

    @Column(name = "isWhiteListed")
    private String isWhiteListed;

    @Column(name = "lendingArrangement" , columnDefinition = "TEXT")
    private String lendingArrangement;

    @Column(name = "loginDate" )
    private String loginDate;

    @Column(name = "natureofCredit", columnDefinition = "TEXT")
    private String natureofCredit;

    @Column(name = "networthMultiplier")
    private double networthMultiplier;

    @Column(name = "oldProductAccountNumber" )
    private String oldProductAccountNumber;

    @Column(name = "preferredtransactionmode")
    private String preferredtransactionmode;

    @Column(name = "relatedPartyCount")
    private Integer relatedPartyCount;

    @Column(name = "remarks" , columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "riskCommencementDate")
    private Integer riskCommencementDate;

    @Column(name = "sanctionedAmount")
    private double sanctionedAmount;

    @Column(name = "secondHolderFirstname")
    private String secondHolderFirstname;

    @Column(name = "secondHolderMiddlename")
    private String secondHolderMiddlename;

    @Column(name = "secondHolderLastname")
    private String secondHolderLastname;

    @Column(name = "secondHolderPan")
    private String secondHolderPan;

    @Column(name = "thirdHolderFirstname")
    private String thirdHolderFirstname;

    @Column(name = "thirdHolderMiddlename")
    private String thirdHolderMiddlename;

    @Column(name = "thirdHolderLastname")
    private String thirdHolderLastname;

    @Column(name = "thirdHolderPan")
    private String thirdHolderPan;

    @Column(name = "totalOutstandingAmount")
    private double totalOutstandingAmount;

//    @Column(name = "accountId")
//    private Integer accountId;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;
    public static AccHolderDetails create(final CreateAccHolderDetailsRequest request, AccInfo accInfo) {
        final AccHolderDetails accHolderDetails = new AccHolderDetails();
        accHolderDetails.setAccInfo(accInfo);
        accHolderDetails.setCustomerId(request.getCustomerId());
        accHolderDetails.setBorrowerDetails(request.getBorrowerDetails());
        accHolderDetails.setBranchReceiptDate(request.getBranchReceiptDate());
        accHolderDetails.setDateofDefault(request.getDateofDefault());
        accHolderDetails.setDateofFilingofSuit(request.getDateofFilingofSuit());
        accHolderDetails.setDateofLastRepayment(request.getDateofLastRepayment());
        accHolderDetails.setDebtSubType(request.getDebtSubType());
        accHolderDetails.setDefaultAmount(request.getDefaultAmount());
        accHolderDetails.setDefaultRemarks(request.getDefaultRemarks());
        accHolderDetails.setDisbursementDate(request.getDisbursementDate());
        accHolderDetails.setDrawingPower(request.getDrawingPower());
        accHolderDetails.setEmiAmount(request.getEmiAmount());
        accHolderDetails.setFinalEMIDate(request.getFinalEMIDate());
        accHolderDetails.setFirstHolderRecordIdentifier(request.getFirstHolderRecordIdentifier());
        accHolderDetails.setFirstHolderRelation(request.getFirstHolderRelation());
        accHolderDetails.setFirstHolderSourceSystemCustomerCode(request.getFirstHolderSourceSystemCustomerCode());
        accHolderDetails.setFirstHolderSourceSystemName(request.getFirstHolderSourceSystemName());
        accHolderDetails.setFirstPremiumReceiptDate(request.getFirstPremiumReceiptDate());
        accHolderDetails.setInterestOutstanding(request.getInterestOutstanding());
        accHolderDetails.setIsDefaulted(request.getIsDefaulted());
        accHolderDetails.setIsFamilyDeclaration(request.getIsFamilyDeclaration());
        accHolderDetails.setIsWhiteListed(request.getIsWhiteListed());
        accHolderDetails.setLendingArrangement(request.getLendingArrangement());
        accHolderDetails.setLoginDate(request.getLoginDate());
        accHolderDetails.setNatureofCredit(request.getNatureofCredit());
        accHolderDetails.setNetworthMultiplier(request.getNetworthMultiplier());
        accHolderDetails.setOldProductAccountNumber(request.getOldProductAccountNumber());
        accHolderDetails.setPreferredtransactionmode(request.getPreferredtransactionmode());
        accHolderDetails.setRelatedPartyCount(request.getRelatedPartyCount());
        accHolderDetails.setRemarks(request.getRemarks());
        accHolderDetails.setRiskCommencementDate(request.getRiskCommencementDate());
        accHolderDetails.setSanctionedAmount(request.getSanctionedAmount());
        accHolderDetails.setSecondHolderFirstname(request.getSecondHolderFirstname());
        accHolderDetails.setSecondHolderLastname(request.getSecondHolderLastname());
        accHolderDetails.setSecondHolderMiddlename(request.getSecondHolderMiddlename());
        accHolderDetails.setSecondHolderPan(request.getSecondHolderPan());
        accHolderDetails.setThirdHolderFirstname(request.getThirdHolderFirstname());
        accHolderDetails.setThirdHolderLastname(request.getThirdHolderLastname());
        accHolderDetails.setThirdHolderMiddlename(request.getThirdHolderMiddlename());
        accHolderDetails.setThirdHolderPan(request.getThirdHolderPan());
        accHolderDetails.setTotalOutstandingAmount(request.getTotalOutstandingAmount());
        accHolderDetails.setUid(request.getUid());
        accHolderDetails.setEuid(request.getEuid());
        accHolderDetails.setStatus(Status.ACTIVE);
        accHolderDetails.setCreatedAt(LocalDateTime.now());
        return accHolderDetails;
    }
    public void update(final UpdateAccHolderDetailsRequest request) {
        this.setCustomerId(request.getCustomerId());
        this.setBorrowerDetails(request.getBorrowerDetails());
        this.setBranchReceiptDate(request.getBranchReceiptDate());
        this.setDateofDefault(request.getDateofDefault());
        this.setDateofFilingofSuit(request.getDateofFilingofSuit());
        this.setDateofLastRepayment(request.getDateofLastRepayment());
        this.setDebtSubType(request.getDebtSubType());
        this.setDefaultAmount(request.getDefaultAmount());
        this.setDefaultRemarks(request.getDefaultRemarks());
        this.setDisbursementDate(request.getDisbursementDate());
        this.setDrawingPower(request.getDrawingPower());
        this.setEmiAmount(request.getEmiAmount());
        this.setFinalEMIDate(request.getFinalEMIDate());
        this.setFirstHolderRecordIdentifier(request.getFirstHolderRecordIdentifier());
        this.setFirstHolderRelation(request.getFirstHolderRelation());
        this.setFirstHolderSourceSystemCustomerCode(request.getFirstHolderSourceSystemCustomerCode());
        this.setFirstHolderSourceSystemName(request.getFirstHolderSourceSystemName());
        this.setFirstPremiumReceiptDate(request.getFirstPremiumReceiptDate());
        this.setInterestOutstanding(request.getInterestOutstanding());
        this.setIsDefaulted(request.getIsDefaulted());
        this.setIsFamilyDeclaration(request.getIsFamilyDeclaration());
        this.setIsWhiteListed(request.getIsWhiteListed());
        this.setLendingArrangement(request.getLendingArrangement());
        this.setLoginDate(request.getLoginDate());
        this.setNatureofCredit(request.getNatureofCredit());
        this.setNetworthMultiplier(request.getNetworthMultiplier());
        this.setOldProductAccountNumber(request.getOldProductAccountNumber());
        this.setPreferredtransactionmode(request.getPreferredtransactionmode());
        this.setRelatedPartyCount(request.getRelatedPartyCount());
        this.setRemarks(request.getRemarks());
        this.setRiskCommencementDate(request.getRiskCommencementDate());
        this.setSanctionedAmount(request.getSanctionedAmount());
        this.setSecondHolderFirstname(request.getSecondHolderFirstname());
        this.setSecondHolderLastname(request.getSecondHolderLastname());
        this.setSecondHolderMiddlename(request.getSecondHolderMiddlename());
        this.setSecondHolderPan(request.getSecondHolderPan());
        this.setThirdHolderFirstname(request.getThirdHolderFirstname());
        this.setThirdHolderLastname(request.getThirdHolderLastname());
        this.setThirdHolderMiddlename(request.getThirdHolderMiddlename());
        this.setThirdHolderPan(request.getThirdHolderPan());
        this.setTotalOutstandingAmount(request.getTotalOutstandingAmount());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }

}
