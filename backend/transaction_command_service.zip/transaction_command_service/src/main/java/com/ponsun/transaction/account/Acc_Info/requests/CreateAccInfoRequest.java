package com.ponsun.transaction.account.Acc_Info.requests;

import lombok.Data;

@Data
public class CreateAccInfoRequest extends AbstractAccInfoRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
