package com.ponsun.transaction.account.Acc_Info.rowmapper;

import com.ponsun.transaction.account.Acc_Info.data.AccInfoData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Service
@Slf4j
@Data
public class AccInfoRowMapper implements RowMapper<AccInfoData> {
    private final String schema;

    public AccInfoRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM tm_acc_info api ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("api.id as id, ");
        builder.append("api.customerId as customerId, ");
        builder.append("api.productAccOpeningDate as productAccOpeningDate, ");
        builder.append("api.productAccountNumber as productAccountNumber, ");
        builder.append("api.productAccountReasonCodeDescription as productAccountReasonCodeDescription, ");
        builder.append("api.productAccountStatus as productAccountStatus, ");
        builder.append("api.productAccountStatusDescription as productAccountStatusDescription, ");
        builder.append("api.productAccountStatusEffectiveDate as productAccountStatusEffectiveDate, ");
        builder.append("api.productAccountStatusReasonCode as productAccountStatusReasonCode, ");
        builder.append("api.productAccountType as productAccountType, ");
        builder.append("api.productApplicationDate as productApplicationDate, ");
        builder.append("api.productSegments as productSegments, ");
        builder.append("api.rmCode as rmCode, ");
        builder.append("api.rmType as rmType, ");
        builder.append("api.tags as tags, ");
        builder.append("api.underwritingDate as underwritingDate, ");
        builder.append("api.uid as uid, ");
        builder.append("api.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccInfoData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer customerId = rs.getInt("customerId");
        final String productAccOpeningDate = rs.getString("productAccOpeningDate");
        final String productAccountNumber = rs.getString("productAccountNumber");
        final String productAccountReasonCodeDescription = rs.getString("productAccountReasonCodeDescription");
        final String productAccountStatus = rs.getString("productAccountStatus");
        final String productAccountStatusDescription = rs.getString("productAccountStatusDescription");
        final String productAccountStatusEffectiveDate = rs.getString("productAccountStatusEffectiveDate");
        final String productAccountStatusReasonCode = rs.getString("productAccountStatusReasonCode");
        final String productAccountType = rs.getString("productAccountType");
        final String productApplicationDate = rs.getString("productApplicationDate");
        final String productSegments = rs.getString("productSegments");
        final String rmCode = rs.getString("rmCode");
        final String rmType = rs.getString("rmType");
        final String tags = rs.getString("tags");
        final String underwritingDate = rs.getString("underwritingDate");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new AccInfoData( id,customerId, productAccOpeningDate, productAccountNumber, productAccountReasonCodeDescription, productAccountStatus, productAccountStatusDescription, productAccountStatusEffectiveDate, productAccountStatusReasonCode, productAccountType, productApplicationDate, productSegments, rmCode, rmType, tags, underwritingDate, uid, euid);
    }
}