package com.ponsun.transaction.accountConfig.clientStatus.domain;


import com.ponsun.transaction.accountConfig.clientStatus.request.AbstractClientStatusRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ClientStatusWrapper extends AbstractClientStatusRequest {
    private final ClientStatusRepository ClientStatusRepository;

    @Transactional
    public ClientStatus findOneWithNotFoundDetection(final Integer id) {
        return this.ClientStatusRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("ClientStatus Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }

}

