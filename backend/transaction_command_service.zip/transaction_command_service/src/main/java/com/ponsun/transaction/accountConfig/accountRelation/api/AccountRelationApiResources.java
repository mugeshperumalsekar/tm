package com.ponsun.transaction.accountConfig.accountRelation.api;


import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelation;
import com.ponsun.transaction.accountConfig.accountRelation.request.CreateAccountRelationRequest;
import com.ponsun.transaction.accountConfig.accountRelation.request.UpdateAccountRelationRequest;
import com.ponsun.transaction.accountConfig.accountRelation.services.AccountRelationReadService;
import com.ponsun.transaction.accountConfig.accountRelation.services.AccountRelationWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccountRelation")
@Tag(name = "AccountRelationApiResource")
public class AccountRelationApiResources {
    private final AccountRelationWriteService accountRelationWriteService;
    private final AccountRelationReadService accountRelationReadService;

    @PostMapping("/CreateAccountRelationRequest")
    public Response saveAccountRelation(@RequestBody CreateAccountRelationRequest createAccountRelationRequest) {
        log.debug("START saveAccountRelation request body {}",createAccountRelationRequest);
        Response response = this.accountRelationWriteService.createAccountRelation(createAccountRelationRequest);
        log.debug("START saveAccountRelation response",response);
        return response;
    }

    @GetMapping
    public List<AccountRelation> fetchAll() {
        return this.accountRelationReadService.fetchAllAccountRelation();
    }

    @GetMapping("/{id}")
    public AccountRelation fetchAccountRelationById(@PathVariable(name = "id") Integer id) {
        return this.accountRelationReadService.fetchAccountRelationById(id);
    }

    @PutMapping("/{id}")
    public Response updateAccountRelation(@PathVariable Integer id, @RequestBody UpdateAccountRelationRequest updateAccountRelationRequest) {
        log.debug("START updateAccountRelation request body {}",updateAccountRelationRequest);
        Response response = this.accountRelationWriteService.updateAccountRelation(id, updateAccountRelationRequest);
        log.debug("START updateAccountRelation response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccountRelation(@PathVariable Integer id){
        Response response = this.accountRelationWriteService.unblockAccountRelation(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.accountRelationWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccountRelation> fetchActiveAccountRelation() {
        return accountRelationReadService.fetchActiveAccountRelation();
    }
    @GetMapping("DeActive")
    public List<AccountRelation> fetchDeAccountRelation() {
        return accountRelationReadService.fetchDeActiveAccountRelation();
    }
    
}

