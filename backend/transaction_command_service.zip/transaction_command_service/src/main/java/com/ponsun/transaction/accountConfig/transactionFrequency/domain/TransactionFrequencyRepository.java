package com.ponsun.transaction.accountConfig.transactionFrequency.domain;

import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TransactionFrequencyRepository extends JpaRepository<TransactionFrequency, Integer> {
    Optional<TransactionFrequency> findById(Integer id);

    List<TransactionFrequency> findByStatus (Status string);

}