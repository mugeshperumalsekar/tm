package com.ponsun.transaction.account.Acc_Risk_Status_Det.services;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.CreateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.UpdateAccRiskStatusDetRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccRiskStatusDetWriteService {
    Response createAccRiskStatusDet(CreateAccRiskStatusDetRequest request);
    Response updateAccRiskStatusDet(Integer id, UpdateAccRiskStatusDetRequest request);
    Response unblockAccRiskStatusDet(Integer id);
    Response deactive(Integer id, Integer euid);
}
