package com.ponsun.transaction.accountConfig.instrumentType.services;

import com.ponsun.transaction.accountConfig.instrumentType.data.InstrumentTypeValidator;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentType;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentTypeRepository;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentTypeWrapper;
import com.ponsun.transaction.accountConfig.instrumentType.requests.CreateInstrumentTypeRequest;
import com.ponsun.transaction.accountConfig.instrumentType.requests.UpdateInstrumentTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class InstrumentTypeWriteServiceImpl implements InstrumentTypeWriteService {
    private final InstrumentTypeRepository repository;
    private final InstrumentTypeWrapper wrapper;
    private final InstrumentTypeValidator validator;

    @Override
    @Transactional
    public Response createInstrumentType(CreateInstrumentTypeRequest request) {
        try {
            this.validator.validateSaveInstrumentType(request);
            final InstrumentType instrumentType = InstrumentType.create(request);
            this.repository.saveAndFlush(instrumentType);
            return Response.of(Long.valueOf(instrumentType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response updateInstrumentType(Integer id, UpdateInstrumentTypeRequest request) {
        try {
            this.validator.validateUpdateInstrumentType(request);
            final InstrumentType instrumentType = this.wrapper.findOneWithNotFoundDetection(id);
            instrumentType.update(request);
            this.repository.saveAndFlush(instrumentType);
            return Response.of(Long.valueOf(instrumentType.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockInstrumentType(Integer id) {
        try {
            final InstrumentType instrumentType = this.wrapper.findOneWithNotFoundDetection(id);
            instrumentType.setStatus(Status.ACTIVE);
            instrumentType.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(instrumentType);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid){
        try{
            InstrumentType instrumentType = this.wrapper.findOneWithNotFoundDetection(id);
            instrumentType.setEuid(euid);
            instrumentType.setStatus(Status.DELETE);
            instrumentType.setUpdatedAt(LocalDateTime.now());

            return Response.of(Long.valueOf(instrumentType.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

}
