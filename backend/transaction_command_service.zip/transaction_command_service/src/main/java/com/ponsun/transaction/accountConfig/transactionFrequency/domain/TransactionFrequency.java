package com.ponsun.transaction.accountConfig.transactionFrequency.domain;

import com.ponsun.transaction.accountConfig.transactionFrequency.request.CreateTransactionFrequencyRequest;
import com.ponsun.transaction.accountConfig.transactionFrequency.request.UpdateTransactionFrequencyRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_TransactionFrequency")
public class TransactionFrequency extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static TransactionFrequency create(final CreateTransactionFrequencyRequest createTransactionFrequencyRequest){
        final TransactionFrequency transactionFrequency = new TransactionFrequency();
        transactionFrequency.setName(createTransactionFrequencyRequest.getName());
        transactionFrequency.setCode(createTransactionFrequencyRequest.getCode());
        transactionFrequency.setUid(createTransactionFrequencyRequest.getUid());
        transactionFrequency.setStatus(Status.ACTIVE);
        transactionFrequency.setCreatedAt(LocalDateTime.now());
        return transactionFrequency;
    }
    public void update(final UpdateTransactionFrequencyRequest updateTransactionFrequencyRequest){
        this.setName(updateTransactionFrequencyRequest.getName());
        this.setCode(updateTransactionFrequencyRequest.getCode());
        this.setEuid(updateTransactionFrequencyRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

