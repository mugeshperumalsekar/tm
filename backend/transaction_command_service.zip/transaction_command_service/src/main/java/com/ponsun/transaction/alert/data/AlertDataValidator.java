package com.ponsun.transaction.alert.data;


import com.ponsun.transaction.alert.request.CreateAlertRequest;
import com.ponsun.transaction.alert.request.UpdateAlertRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AlertDataValidator {

    public void validateSaveAlertData(final CreateAlertRequest request)   {
        if(request.getBankAccount() == null || request.getBankAccount().equals("")){
            throw new PS_transaction_ApplicationException("BankAccount parameter required");
        }
    }
    public void validateUpdateAlertData(final UpdateAlertRequest request)   {
        if(request.getBankAccount() == null || request.getBankAccount().equals("")){
            throw new PS_transaction_ApplicationException("BankAccount parameter required");
        }
    }
    
}
