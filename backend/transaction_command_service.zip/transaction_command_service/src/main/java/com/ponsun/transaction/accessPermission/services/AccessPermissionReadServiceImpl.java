package com.ponsun.transaction.accessPermission.services;

import com.ponsun.transaction.accessPermission.data.AccessPermissionData;
import com.ponsun.transaction.accessPermission.data.RoleAccessDto;
import com.ponsun.transaction.accessPermission.rowmapper.RolePermissionRowMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AccessPermissionReadServiceImpl implements AccessPermissionReadService{
    private final RolePermissionRowMapper rolePermissionRowMapper;
    private final JdbcTemplate jdbcTemplate;

    public List<AccessPermissionData> fetchAllMenuListBasedOnRole(Integer userId){
        String qry = "SELECT "+ rolePermissionRowMapper.tableSchema();
        String whereClause = " WHERE rpm.uid = " + userId + " AND rpm.STATUS = 'A' GROUP BY rpm.mod_id ORDER BY rpm.uid ASC";
        qry = qry + whereClause;
        final List<RoleAccessDto> roleAccessDtoList = jdbcTemplate.query(qry ,rolePermissionRowMapper, new Object[] {});
        List<AccessPermissionData> finalList = new ArrayList<>();
        if(!roleAccessDtoList.isEmpty()){
            for(RoleAccessDto dto : roleAccessDtoList ){
                Integer modId = dto.modId();
                String subMenuQry = "SELECT "+ rolePermissionRowMapper.tableSchema() + " WHERE rpm.mod_id = " + modId + " AND rpm.uid = "+ userId + " AND rpm.STATUS = 'A'";
                final List<RoleAccessDto> roleAccessDtos= jdbcTemplate.query(subMenuQry ,rolePermissionRowMapper);
                List<AccessPermissionData> subMenuItemList = new ArrayList<>();
                if(roleAccessDtos.size() > 1){
                    for(RoleAccessDto subMenu:roleAccessDtos ){
                        AccessPermissionData subMenuItem = new AccessPermissionData(subMenu.uId(),subMenu.modDetName(),subMenu.modDetName(),subMenu.link());
                        subMenuItemList.add(subMenuItem);
                    }
                }
                AccessPermissionData menuItem = new AccessPermissionData(dto.uId(),dto.modName(),dto.modName(),dto.link(),subMenuItemList);
                finalList.add((menuItem));
            }
        }
        return finalList;
    }
}
