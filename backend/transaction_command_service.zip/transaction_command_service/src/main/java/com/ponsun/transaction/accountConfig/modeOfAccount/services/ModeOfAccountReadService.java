package com.ponsun.transaction.accountConfig.modeOfAccount.services;


import com.ponsun.transaction.accountConfig.modeOfAccount.domain.ModeOfAccount;

import java.util.List;

public interface ModeOfAccountReadService {
    List<ModeOfAccount> fetchAllModeOfAccount();

    ModeOfAccount fetchModeOfAccountById(Integer id);

    List<ModeOfAccount> fetchActiveType();

    List<ModeOfAccount> fetchDeActiveType();
}
