package com.ponsun.transaction.accountConfig.reasonCode.domain;


import com.ponsun.transaction.accountConfig.reasonCode.request.AbstractReasonCodeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ReasonCodeWrapper extends AbstractReasonCodeRequest {
    private final ReasonCodeRepository reasonCodeRepository;

    @Transactional
    public ReasonCode findOneWithNotFoundDetection(final Integer id) {
        return this.reasonCodeRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("ReasonCode Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }
}

