package com.ponsun.transaction.accessPermission.rowmapper;
import com.ponsun.transaction.accessPermission.data.RoleAccessDto;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class RolePermissionRowMapper implements RowMapper<RoleAccessDto> {
    private final String schema;

    public RolePermissionRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM admin_user_rights rpm ");
        builder.append("LEFT JOIN admin_config_module acm ON rpm.mod_id = acm.id ");
        builder.append("LEFT JOIN admin_config_module_det cmd ON rpm.mod_det_id = cmd.id" );
        this.schema = builder.toString();
    }
    public String schema() {
        return this.schema;
    }

    public String  tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("rpm.uid as uid, ");
        builder.append("rpm.mod_id as modId, ");
        builder.append("rpm.mod_det_id as modDetId, ");
        builder.append("acm.name as modName,");
        builder.append("cmd.name as modDetName ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public RoleAccessDto mapRow(ResultSet rs, int rowNum) throws SQLException {
        final String uid = rs.getString("uid");
        final Integer modId = rs.getInt("modId");
        final Integer modDetId = rs.getInt("modDetId");
        final String modName = rs.getString("modName");
        final String modDetName = rs.getString("modDetName");
        final String path =   modDetName != null ? "/" + modDetName : null;
        return new RoleAccessDto(uid, modId, modDetId, modName, modDetName, path);
    }

}
