package com.ponsun.transaction.accountConfig.instrumentType.data;

import lombok.Data;

@Data
public class InstrumentTypeData {
    private Integer id;
    private String name;
    private String transType;
    private String code;
    private Integer uid;
    private Integer euid;

    public InstrumentTypeData(Integer id, String name,String transType, String code, Integer uid, Integer euid) {
        this.id = id;
        this.name = name;
        this.transType = transType;
        this.code = code;
        this.uid = uid;
        this.euid = euid;
    }
    public static InstrumentTypeData newInstance(Integer id, String name,String transType, String code, Integer uid, Integer euid){
        return new InstrumentTypeData(id,name,transType,code,uid,euid);
    }
}
