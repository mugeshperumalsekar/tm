package com.ponsun.transaction.account.Acc_Info.services;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;

import java.util.List;

public interface AccInfoReadService {

    AccInfo fetchAccInfoById(Integer id);

    List<AccInfo> fetchAllAccInfo();

    List<AccInfo> fetchActiveAccInfo();
    List<AccInfo> fetchDeActiveAccInfo();
}
