package com.ponsun.transaction.account.Acc_transaction.services;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.account.Acc_transaction.data.AccTransactionValidator;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransaction;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransactionRepository;
import com.ponsun.transaction.account.Acc_transaction.domain.AccTransactionWrapper;
import com.ponsun.transaction.account.Acc_transaction.requests.CreateAccTransactionRequest;
import com.ponsun.transaction.account.Acc_transaction.requests.UpdateAccTransactionRequest;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentType;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentTypeWrapper;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccTransactionWriteServiceImpl implements AccTransactionWriteService{
    private final AccTransactionRepository repository;
    private final AccTransactionWrapper wrapper;
    private final AccTransactionValidator validator;
    private final AccInfoWrapper accInfoWrapper;
    private final InstrumentTypeWrapper instrumentTypeWrapper;

    @Override
    @Transactional

    public Response createAccTransaction(CreateAccTransactionRequest request) {
        try {
            this.validator.validateSaveAccTransaction(request);

            final AccInfo accInfo = accInfoWrapper.findOneWithNotFoundDetection(request.getAccountId());
            final InstrumentType instrumentType = instrumentTypeWrapper.findOneWithNotFoundDetection(request.getInstrumentTypeId());

            if (accInfo == null){
                throw new PS_transaction_ApplicationException("Account information not found for accountId: " + request.getAccountId());
            }

            final AccTransaction accTransaction = AccTransaction.create(request,accInfo,instrumentType);
            this.repository.saveAndFlush(accTransaction);
            return Response.of(Long.valueOf(accTransaction.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccTransaction(Integer id, UpdateAccTransactionRequest request) {
        try {
            this.validator.validateUpdateAccTransaction(request);
            final AccTransaction accTransaction = this.wrapper.findOneWithNotFoundDetection(id);
            final InstrumentType instrumentType = instrumentTypeWrapper.findOneWithNotFoundDetection(request.getInstrumentTypeId());
            accTransaction.update(request,instrumentType);
            this.repository.saveAndFlush(accTransaction);
            return Response.of(Long.valueOf(accTransaction.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public void updateCalulatedThresholdAccTransaction(Integer id) {
        try {
            final AccTransaction accTransaction = this.wrapper.findOneWithNotFoundDetection(id);
            accTransaction.setIsCalc(1);
            this.repository.saveAndFlush(accTransaction);
            System.out.println("AccTransaction updated with id: "+ id);
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccTransaction(Integer id) {
        try {
            final AccTransaction accTransaction = this.wrapper.findOneWithNotFoundDetection(id);
            accTransaction.setStatus(Status.ACTIVE);
            accTransaction.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accTransaction);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccTransaction accTransaction = this.wrapper.findOneWithNotFoundDetection(id);
            accTransaction.setEuid(euid);
            accTransaction.setStatus(Status.DELETE);
            accTransaction.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accTransaction);
            return Response.of(Long.valueOf(accTransaction.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
