package com.ponsun.transaction.accountConfig.regAMLRisk.request;

import lombok.Data;

@Data
public class CreateRegAMLRiskRequest extends AbstractRegAMLRiskRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}

