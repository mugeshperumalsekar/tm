package com.ponsun.transaction.accountConfig.accountProductSegment.services;

import com.ponsun.transaction.accountConfig.accountProductSegment.requests.UpdateAccountProductSegmentRequest;
import com.ponsun.transaction.accountConfig.accountProductSegment.data.AccountProductSegmentValidator;
import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountProductSegment;
import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountProductSegmentRepository;
import com.ponsun.transaction.accountConfig.accountProductSegment.domain.AccountAccountProductSegmentWrapper;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.CreateAccountProductSegmentRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountProductSegmentWriteServiceImpl implements AccountProductSegmentWriteService {
    private final AccountProductSegmentRepository repository;
    private final AccountAccountProductSegmentWrapper wrapper;
    private final AccountProductSegmentValidator validator;

    @Override
    @Transactional
    public Response createAccProductSegment(CreateAccountProductSegmentRequest request) {
        try {
            this.validator.validateSaveAccProductSegment(request);
            final AccountProductSegment accountProductSegment = AccountProductSegment.create(request);
            this.repository.saveAndFlush(accountProductSegment);
            return Response.of(Long.valueOf(accountProductSegment.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response updateAccProductSegment(Integer id, UpdateAccountProductSegmentRequest request) {
        try {
            this.validator.validateUpdateAccProductSegment(request);
            final AccountProductSegment accountProductSegment = this.wrapper.findOneWithNotFoundDetection(id);
            accountProductSegment.update(request);
            this.repository.saveAndFlush(accountProductSegment);
            return Response.of(Long.valueOf(accountProductSegment.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccProductSegment(Integer id) {
        try {
            final AccountProductSegment accountProductSegment = this.wrapper.findOneWithNotFoundDetection(id);
            accountProductSegment.setStatus(Status.ACTIVE);
            accountProductSegment.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accountProductSegment);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid){
        try{
            AccountProductSegment accountProductSegment = this.wrapper.findOneWithNotFoundDetection(id);
            accountProductSegment.setEuid(euid);
            accountProductSegment.setStatus(Status.DELETE);
            accountProductSegment.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accountProductSegment);
            return Response.of(Long.valueOf(accountProductSegment.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

}
