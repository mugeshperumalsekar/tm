package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.api;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentCKYCAddressType;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.CreatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests.UpdatePermanentCKYCAddressTypeRequest;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.services.PermanentCKYCAddressTypeReadService;
import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.services.PermanentCKYCAddressTypeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/PermanentCKYCAddressType")
@Tag(name = "PermanentCKYCAddressTypeApiResources")
public class PermanentCKYCAddressTypeApiResources {
    private final PermanentCKYCAddressTypeWriteService writeService;
    private final PermanentCKYCAddressTypeReadService readService;

    @PostMapping("/CreateAccAddressTypeRequest")
    public Response createAccAddressType(@RequestBody CreatePermanentCKYCAddressTypeRequest request) {
        Response response = this.writeService.createAccAddressType(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccAddressType(@PathVariable Integer id, @RequestBody UpdatePermanentCKYCAddressTypeRequest request) {
        Response response = this.writeService.updateAccAddressType(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public PermanentCKYCAddressType fetchById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccAddressTypeById(id);
    }
    @GetMapping
    public List<PermanentCKYCAddressType> fetchAll() {
        return this.readService.fetchAllAccAddressType();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccAddressType(@PathVariable Integer id){
        Response response = this.writeService.unblockAccAddressType(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<PermanentCKYCAddressType> fetchActivePermanentCKYCAddressType() {
        return readService.fetchActivePermanentCKYCAddressType();
    }
    @GetMapping("DeActive")
    public List<PermanentCKYCAddressType> fetchDePermanentCKYCAddressType() {
        return readService.fetchDeActivePermanentCKYCAddressType();
    }
}
