package com.ponsun.transaction.account.Acc_Risk_Status_Det.api;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDet;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.CreateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.requests.UpdateAccRiskStatusDetRequest;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.services.AccRiskStatusDetReadService;
import com.ponsun.transaction.account.Acc_Risk_Status_Det.services.AccRiskStatusDetWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccRiskStatusDet")
@Tag(name = "AccRiskStatusDetApiResources")
public class AccRiskStatusDetApiResources {
    private final AccRiskStatusDetWriteService writeService;
    private final AccRiskStatusDetReadService readService;

    @PostMapping("/CreateAccRiskStatusDetRequest")
    public Response createAccAccRiskStatusDet(@RequestBody CreateAccRiskStatusDetRequest request) {
        Response response = this.writeService.createAccRiskStatusDet(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccRiskStatusDet(@PathVariable Integer id, @RequestBody UpdateAccRiskStatusDetRequest request) {
        Response response = this.writeService.updateAccRiskStatusDet(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccRiskStatusDet fetchAccRiskStatusDetById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccRiskStatusDetById(id);
    }
    @GetMapping
    public List<AccRiskStatusDet> fetchAll() {
        return this.readService.fetchAllAccRiskStatusDet();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccRiskStatusDet(@PathVariable Integer id){
        Response response = this.writeService.unblockAccRiskStatusDet(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccRiskStatusDet> fetchActiveAccRiskStatusDet() {
        return readService.fetchActiveAccRiskStatusDet();
    }

    @GetMapping("DeActive")
    public List<AccRiskStatusDet> fetchDeAccRiskStatusDet() {
        return readService.fetchDeActiveAccRiskStatusDet();
    }

}
