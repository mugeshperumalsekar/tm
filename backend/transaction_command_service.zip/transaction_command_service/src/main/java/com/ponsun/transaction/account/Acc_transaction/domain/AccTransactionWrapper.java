package com.ponsun.transaction.account.Acc_transaction.domain;
import com.ponsun.transaction.account.Acc_transaction.requests.AbstractAccTransactionRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AccTransactionWrapper extends AbstractAccTransactionRequest {
    private final AccTransactionRepository repository;
    @Transactional
    public AccTransaction findOneWithNotFoundDetection (final Integer id) {
        return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("AccTransaction Not found " + id));
    }
    @Transactional
    public List<AccTransaction> findAllGroupByAccountId(){
        return this.repository.fetchDataGroupByAccountId();
    }
    @Transactional
    public List<AccTransaction> findAllWithAccountIdAndInstrumentType(final Integer accountId){
        return this.repository.findByAccountId(accountId);
    }
    @Override
    public String toString(){
        return super.toString();
    }
}
