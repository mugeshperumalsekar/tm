package com.ponsun.transaction.accountConfig.lendingArrangement.request;

import lombok.Data;

@Data
public class UpdateLendingArrangementRequest extends AbstractLendingArrangementRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

