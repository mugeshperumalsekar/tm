package com.ponsun.transaction.accountConfig.regAMLRisk.domain;

import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.customerConfig.Segment.domain.Segment;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
public interface RegAMLRiskRepository extends JpaRepository<RegAMLRisk, Integer> {
    Optional<RegAMLRisk> findById(Integer id);
    List<RegAMLRisk>  findByStatus (Status string);

    @Query(value = "SELECT r FROM RegAMLRisk r WHERE r.status = 'A'")
    List<RegAMLRisk> fetchAll(Pageable pageable);


    @Query("SELECT x FROM RegAMLRisk x WHERE x.id = :id AND x.status = 'A'")
    Optional<RegAMLRisk> findByIdAndStatus(@Param("id") Integer id);

    @Query("SELECT x FROM RegAMLRisk x WHERE LOWER(x.name) = LOWER(:risk) AND x.status = 'A'")
    Optional<RegAMLRisk> findByRisk(@Param("risk") String risk);

    @Query("SELECT x FROM RegAMLRisk x WHERE x.id IN :ids")
    List<RegAMLRisk> findRisksByIds(@Param("ids") List<Integer> ids);


}