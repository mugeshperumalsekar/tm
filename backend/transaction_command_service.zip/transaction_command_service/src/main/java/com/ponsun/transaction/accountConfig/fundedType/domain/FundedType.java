package com.ponsun.transaction.accountConfig.fundedType.domain;

import com.ponsun.transaction.accountConfig.fundedType.request.UpdateFundedTypeRequest;
import com.ponsun.transaction.accountConfig.fundedType.request.CreateFundedTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_FundedType")
public class FundedType extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static FundedType create(final CreateFundedTypeRequest createFundedTypeRequest){
        final FundedType fundedType = new FundedType();
        fundedType.setName(createFundedTypeRequest.getName());
        fundedType.setCode(createFundedTypeRequest.getCode());
        fundedType.setUid(createFundedTypeRequest.getUid());
        fundedType.setStatus(Status.ACTIVE);
        fundedType.setCreatedAt(LocalDateTime.now());
        return fundedType;
    }
    public void update(final UpdateFundedTypeRequest updateFundedTypeRequest){
        this.setName(updateFundedTypeRequest.getName());
        this.setCode(updateFundedTypeRequest.getCode());
        this.setEuid(updateFundedTypeRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

