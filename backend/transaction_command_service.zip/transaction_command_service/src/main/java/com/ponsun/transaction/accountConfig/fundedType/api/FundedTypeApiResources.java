package com.ponsun.transaction.accountConfig.fundedType.api;


import com.ponsun.transaction.accountConfig.fundedType.domain.FundedType;
import com.ponsun.transaction.accountConfig.fundedType.request.CreateFundedTypeRequest;
import com.ponsun.transaction.accountConfig.fundedType.request.UpdateFundedTypeRequest;
import com.ponsun.transaction.accountConfig.fundedType.services.FundedTypeReadService;
import com.ponsun.transaction.accountConfig.fundedType.services.FundedTypeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/FundedType")
@Tag(name = "FundedTypeApiResource")
public class FundedTypeApiResources {
    private final FundedTypeWriteService fundedTypeWriteService;
    private final FundedTypeReadService fundedTypeReadService;

    @PostMapping("/CreateFundedTypeRequest")
    public Response saveFundedType(@RequestBody CreateFundedTypeRequest createFundedTypeRequest) {
        log.debug("START saveFundedType request body {}",createFundedTypeRequest);
        Response response = this.fundedTypeWriteService.createFundedType(createFundedTypeRequest);
        log.debug("START saveFundedType response",response);
        return response;
    }

    @GetMapping
    public List<FundedType> fetchAll() {
        return this.fundedTypeReadService.fetchAllFundedType();
    }

    @GetMapping("/{id}")
    public FundedType fetchFundedTypeById(@PathVariable(name = "id") Integer id) {
        return this.fundedTypeReadService.fetchFundedTypeById(id);
    }

    @PutMapping("/{id}")
    public Response updateFundedType(@PathVariable Integer id, @RequestBody UpdateFundedTypeRequest updateFundedTypeRequest) {
        log.debug("START updateFundedType request body {}",updateFundedTypeRequest);
        Response response = this.fundedTypeWriteService.updateFundedType(id, updateFundedTypeRequest);
        log.debug("START updateFundedType response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockFundedType(@PathVariable Integer id){
        Response response = this.fundedTypeWriteService.unblockFundedType(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.fundedTypeWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<FundedType> fetchActiveFundedType() {
        return fundedTypeReadService.fetchActiveFundedType();
    }
    @GetMapping("DeActive")
    public List<FundedType> fetchDeFundedType() {
        return fundedTypeReadService.fetchDeActiveFundedType();
    }
    
}

