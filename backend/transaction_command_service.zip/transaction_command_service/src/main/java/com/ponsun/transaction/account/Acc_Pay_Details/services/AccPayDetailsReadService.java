package com.ponsun.transaction.account.Acc_Pay_Details.services;
import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetails;

import java.util.List;

public interface AccPayDetailsReadService {

    AccPayDetails fetchAccPayDetailsById(Integer id);

    List<AccPayDetails> fetchAllAccPayDetails();

    List<AccPayDetails> fetchActiveAccPayDetails();
    List<AccPayDetails> fetchDeActiveAccPayDetails();
}
