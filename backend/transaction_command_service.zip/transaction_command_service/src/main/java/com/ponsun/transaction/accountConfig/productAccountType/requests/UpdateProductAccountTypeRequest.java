package com.ponsun.transaction.accountConfig.productAccountType.requests;

import lombok.Data;

@Data
public class UpdateProductAccountTypeRequest extends AbstractProductAccountTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
