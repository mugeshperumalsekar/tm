package com.ponsun.transaction.accountConfig.debtSubType.services;

import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubType;
import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubTypeRepository;
import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubTypeWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DebtSubTypeReadServiceImpl implements DebtSubTypeReadService {
    private final DebtSubTypeWrapper debtSubTypeWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final DebtSubTypeRepository debtSubTypeRepository;

    @Override
    public DebtSubType fetchDebtSubTypeById(Integer id) {
        return this.debtSubTypeRepository.findById(id).get();
    }

    @Override
    public List<DebtSubType> fetchActiveDebtSubType() {
        return this.debtSubTypeRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<DebtSubType> fetchDeActiveDebtSubType() {
        return this.debtSubTypeRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<DebtSubType> fetchAllDebtSubType() {
        return this.debtSubTypeRepository.findAll();
    }
}
