package com.ponsun.transaction.account.Acc_Pay_Details.services;

import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetails;
import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetailsRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccPayDetailsReadServiceImpl implements AccPayDetailsReadService {
    private final AccPayDetailsRepository repository;

    @Override
    @Transactional
    public AccPayDetails fetchAccPayDetailsById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccPayDetails> fetchAllAccPayDetails() {
        return this.repository.findAll();
    }

    @Override
    public List<AccPayDetails> fetchActiveAccPayDetails() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccPayDetails> fetchDeActiveAccPayDetails() {
        return repository.findByStatus(Status.DELETE);
    }
}
