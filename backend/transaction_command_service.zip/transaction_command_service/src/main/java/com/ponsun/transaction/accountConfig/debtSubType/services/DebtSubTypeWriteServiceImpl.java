package com.ponsun.transaction.accountConfig.debtSubType.services;


import com.ponsun.transaction.accountConfig.debtSubType.data.DebtSubTypeValidator;
import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubType;
import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubTypeRepository;
import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubTypeWrapper;
import com.ponsun.transaction.accountConfig.debtSubType.request.CreateDebtSubTypeRequest;
import com.ponsun.transaction.accountConfig.debtSubType.request.UpdateDebtSubTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class DebtSubTypeWriteServiceImpl implements DebtSubTypeWriteService {

    private final DebtSubTypeRepository debtSubTypeRepository;
    private final DebtSubTypeWrapper debtSubTypeWrapper;
    private final DebtSubTypeValidator debtSubTypeValidator;

    @Override
    @Transactional
    public Response createDebtSubType(CreateDebtSubTypeRequest createDebtSubTypeRequest) {
        try {
            this.debtSubTypeValidator.validateSaveDebtSubType(createDebtSubTypeRequest);
            final DebtSubType debtSubType = DebtSubType.create(createDebtSubTypeRequest);
            this.debtSubTypeRepository.saveAndFlush(debtSubType);
            return Response.of(Long.valueOf(debtSubType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateDebtSubType(Integer id, UpdateDebtSubTypeRequest updateDebtSubTypeRequest) {
        try {
            this.debtSubTypeValidator.validateUpdateDebtSubType(updateDebtSubTypeRequest);
            final DebtSubType debtSubType = this.debtSubTypeWrapper.findOneWithNotFoundDetection(id);
            debtSubType.update(updateDebtSubTypeRequest);
            this.debtSubTypeRepository.saveAndFlush(debtSubType);
            return Response.of(Long.valueOf(debtSubType.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockDebtSubType(Integer id) {
        try {
            final DebtSubType debtSubType = this.debtSubTypeWrapper.findOneWithNotFoundDetection(id);
            debtSubType.setStatus(Status.ACTIVE);
            debtSubType.setUpdatedAt(LocalDateTime.now());
            this.debtSubTypeRepository.saveAndFlush(debtSubType);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            DebtSubType debtSubType = this.debtSubTypeWrapper.findOneWithNotFoundDetection(id);
            debtSubType.setEuid(euid);
            debtSubType.setStatus(Status.DELETE);
            debtSubType.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(debtSubType.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
