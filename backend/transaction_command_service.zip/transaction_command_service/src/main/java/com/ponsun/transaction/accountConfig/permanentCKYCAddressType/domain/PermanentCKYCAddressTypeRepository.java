package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PermanentCKYCAddressTypeRepository extends JpaRepository<PermanentCKYCAddressType,Integer> {
    List<PermanentCKYCAddressType> findByStatus (Status string);

}
