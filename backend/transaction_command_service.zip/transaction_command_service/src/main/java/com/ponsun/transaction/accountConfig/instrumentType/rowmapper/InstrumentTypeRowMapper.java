package com.ponsun.transaction.accountConfig.instrumentType.rowmapper;

import com.ponsun.transaction.accountConfig.instrumentType.data.InstrumentTypeData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
@Data
@Service
@Slf4j
public class InstrumentTypeRowMapper implements RowMapper<InstrumentTypeData> {
    public final String schema;
    public InstrumentTypeRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM tm_config_instrument_type cit ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("cit.id as id ,");
        builder.append("cit.name as name ,");
        builder.append("cit.trans_type as transType ,");
        builder.append("cit.code as code ,");
        builder.append("cit.uid as uid ,");
        builder.append("cit.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public InstrumentTypeData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final String name = rs.getString("name");
        final String transType = rs.getString("transType");
        final String code = rs.getString("code");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new InstrumentTypeData(id, name,transType, code, uid, euid);
    }
}
