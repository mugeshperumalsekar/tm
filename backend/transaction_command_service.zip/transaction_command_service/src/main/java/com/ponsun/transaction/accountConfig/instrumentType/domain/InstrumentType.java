package com.ponsun.transaction.accountConfig.instrumentType.domain;

import com.ponsun.transaction.accountConfig.instrumentType.requests.UpdateInstrumentTypeRequest;
import com.ponsun.transaction.accountConfig.instrumentType.requests.CreateInstrumentTypeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.common.entity.TransactionType;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_instrument_type")
public class InstrumentType extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "trans_type")
    private String transType;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static InstrumentType create(final CreateInstrumentTypeRequest request) {
        final InstrumentType instrumentType = new InstrumentType();
        instrumentType.setName(request.getName());
        instrumentType.setTransType(TransactionType.NONCASH.getCode());
        if(request.getName().equalsIgnoreCase("cash")){
            instrumentType.setTransType(TransactionType.CASH.getCode());
        }
        instrumentType.setCode(request.getCode());
        instrumentType.setUid(request.getUid());
        instrumentType.setEuid(request.getEuid());
        instrumentType.setStatus(Status.ACTIVE);
        instrumentType.setCreatedAt(LocalDateTime.now());
        return instrumentType;
    }

    public void update(final UpdateInstrumentTypeRequest request) {
        this.setName(request.getName());
        this.setTransType(TransactionType.NONCASH.getCode());
        if(request.getName().equalsIgnoreCase("cash")){
            this.setTransType(TransactionType.CASH.getCode());
        }
        this.setCode(request.getCode());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}
