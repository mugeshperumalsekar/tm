package com.ponsun.transaction.account.Acc_Address_Info.rowmapper;

import com.ponsun.transaction.account.Acc_Address_Info.data.AccAddressInfoData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Service
@Slf4j
@Data
public class AccAddressInfoRowMapper implements RowMapper<AccAddressInfoData> {
    private final String schema;

    public AccAddressInfoRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM tm_acc_adress_info aci ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("ahd.id as id, ");
        builder.append("ahd.customerId as customerId, ");
        builder.append("ahd.branchReceiptDate as branchReceiptDate, ");
        builder.append("ahd.dateofDefault as dateofDefault, ");
        builder.append("ahd.dateofFilingofSuit as dateofFilingofSuit, ");
        builder.append("ahd.dateofLastRepayment as dateofLastRepayment, ");
        builder.append("ahd.debtSubType as debtSubType, ");
        builder.append("ahd.defaultAmount as defaultAmount, ");
        builder.append("ahd.defaultRemarks as defaultRemarks, ");
        builder.append("ahd.disbursementDate as disbursementDate, ");
        builder.append("ahd.drawingPower as drawingPower, ");
        builder.append("ahd.emiAmount as emiAmount, ");
        builder.append("ahd.finalEMIDate as finalEMIDate, ");
        builder.append("ahd.firstHolderRecordIdentifier as firstHolderRecordIdentifier, ");
        builder.append("ahd.firstHolderRelation as firstHolderRelation, ");
        builder.append("ahd.firstHolderSourceSystemCustomerCode as firstHolderSourceSystemCustomerCode, ");
        builder.append("ahd.firstHolderSourceSystemName as firstHolderSourceSystemName, ");
        builder.append("ahd.firstPremiumReceiptDate as firstPremiumReceiptDate, ");
        builder.append("ahd.interestOutstanding as interestOutstanding, ");
        builder.append("ahd.isDefaulted as isDefaulted, ");
        builder.append("ahd.isFamilyDeclaration as isFamilyDeclaration, ");
        builder.append("ahd.isWhiteListed as isWhiteListed, ");
        builder.append("ahd.lendingArrangement as lendingArrangement, ");
        builder.append("ahd.loginDate as loginDate, ");
        builder.append("ahd.natureofCredit as natureofCredit, ");
        builder.append("ahd.networthMultiplier as networthMultiplier, ");
        builder.append("ahd.oldProductAccountNumber as oldProductAccountNumber, ");
        builder.append("ahd.preferredtransactionmode as preferredtransactionmode, ");
        builder.append("ahd.relatedPartyCount as relatedPartyCount, ");
        builder.append("ahd.remarks as remarks, ");
        builder.append("ahd.riskCommencementDate as riskCommencementDate, ");
        builder.append("ahd.sanctionedAmount as sanctionedAmount, ");
        builder.append("ahd.secondHolderFirstname as secondHolderFirstname, ");
        builder.append("ahd.secondHolderMiddlename as secondHolderMiddlename, ");
        builder.append("ahd.secondHolderLastname as secondHolderLastname, ");
        builder.append("ahd.secondHolderPan as secondHolderPan, ");
        builder.append("ahd.thirdHolderFirstname as thirdHolderFirstname, ");
        builder.append("ahd.thirdHolderMiddlename as thirdHolderMiddlename, ");
        builder.append("ahd.thirdHolderLastname as thirdHolderLastname, ");
        builder.append("ahd.thirdHolderPan as thirdHolderPan, ");
        builder.append("ahd.totalOutstandingAmount as totalOutstandingAmount, ");
        builder.append("ahd.accountId as accountId, ");
        builder.append("ahd.uid as uid, ");
        builder.append("ahd.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccAddressInfoData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer customerId = rs.getInt("customerId");
        final String correspondenceAddressCity = rs.getString("correspondenceAddressCity");
        final String correspondenceAddressCountry = rs.getString("correspondenceAddressCountry");
        final String correspondenceAddressDistrict = rs.getString("correspondenceAddressDistrict");
        final String correspondenceAddressLine1 = rs.getString("correspondenceAddressLine1");
        final String correspondenceAddressLine2 = rs.getString("correspondenceAddressLine2");
        final String correspondenceAddressLine3 = rs.getString("correspondenceAddressLine3");
        final String correspondenceAddressPinCode = rs.getString("correspondenceAddressPinCode");
        final String correspondenceAddressProof = rs.getString("correspondenceAddressProof");
        final String correspondenceAddressState = rs.getString("correspondenceAddressState");
        final String permanentAddressCity = rs.getString("permanentAddressCity");
        final String permanentAddressCountry = rs.getString("permanentAddressCountry");
        final String permanentAddressDistrict = rs.getString("permanentAddressDistrict");
        final String permanentAddressLine1 = rs.getString("permanentAddressLine1");
        final String permanentAddressLine2 = rs.getString("permanentAddressLine2");
        final String permanentAddressLine3 = rs.getString("permanentAddressLine3");
        final String permanentAddressPinCode = rs.getString("permanentAddressPinCode");
        final String permanentAddressProof = rs.getString("permanentAddressProof");
        final String permanentAddressState = rs.getString("permanentAddressState");
        final String permanentCKYCAddressType = rs.getString("permanentCKYCAddressType");
        final Integer accountId = rs.getInt("accountId");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new AccAddressInfoData( id,customerId, correspondenceAddressCity, correspondenceAddressCountry, correspondenceAddressDistrict, correspondenceAddressLine1, correspondenceAddressLine2, correspondenceAddressLine3, correspondenceAddressPinCode, correspondenceAddressProof, correspondenceAddressState, permanentAddressCity, permanentAddressCountry, permanentAddressDistrict, permanentAddressLine1, permanentAddressLine2, permanentAddressLine3, permanentAddressPinCode, permanentAddressProof, permanentAddressState, permanentCKYCAddressType, accountId, uid, euid);
    }
}