package com.ponsun.transaction.account.Acc_Address_Info.requests;

import lombok.Data;

@Data
public class CreateAccAddressInfoRequest extends AbstractAccAddressInfoRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
