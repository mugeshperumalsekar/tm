package com.ponsun.transaction.account.Acc_Pay_Details.data;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.CreateAccPayDetailsRequest;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.UpdateAccPayDetailsRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccPayDetailsValidator {
    public void validateSaveAccPayDetails(final CreateAccPayDetailsRequest request){
        if (request.getAccountId()== null || request.getAccountId().equals("")){
            throw new PS_transaction_ApplicationException("AccountId parameter required");
        }
    }
    public void validateUpdateAccPayDetails(final UpdateAccPayDetailsRequest request){
        if(request.getAccountId() == null || request.getAccountId().equals("")) {
            throw new PS_transaction_ApplicationException("AccountId parameter required");

        }
    }
}
