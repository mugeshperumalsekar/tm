package com.ponsun.transaction.accountConfig.transactionFrequency.services;


import com.ponsun.transaction.accountConfig.transactionFrequency.data.TransactionFrequencyValidator;
import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequency;
import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequencyRepository;
import com.ponsun.transaction.accountConfig.transactionFrequency.domain.TransactionFrequencyWrapper;
import com.ponsun.transaction.accountConfig.transactionFrequency.request.CreateTransactionFrequencyRequest;
import com.ponsun.transaction.accountConfig.transactionFrequency.request.UpdateTransactionFrequencyRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionFrequencyWriteServiceImpl implements TransactionFrequencyWriteService {

    private final TransactionFrequencyRepository transactionFrequencyRepository;
    private final TransactionFrequencyWrapper transactionFrequencyWrapper;
    private final TransactionFrequencyValidator transactionFrequencyValidator;

    @Override
    @Transactional
    public Response createTransactionFrequency(CreateTransactionFrequencyRequest createTransactionFrequencyRequest) {
        try {
            this.transactionFrequencyValidator.validateSaveTransactionFrequency(createTransactionFrequencyRequest);
            final TransactionFrequency transactionFrequency = TransactionFrequency.create(createTransactionFrequencyRequest);
            this.transactionFrequencyRepository.saveAndFlush(transactionFrequency);
            return Response.of(Long.valueOf(transactionFrequency.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateTransactionFrequency(Integer id, UpdateTransactionFrequencyRequest updateTransactionFrequencyRequest) {
        try {
            this.transactionFrequencyValidator.validateUpdateTransactionFrequency(updateTransactionFrequencyRequest);
            final TransactionFrequency transactionFrequency = this.transactionFrequencyWrapper.findOneWithNotFoundDetection(id);
            transactionFrequency.update(updateTransactionFrequencyRequest);
            this.transactionFrequencyRepository.saveAndFlush(transactionFrequency);
            return Response.of(Long.valueOf(transactionFrequency.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockTransactionFrequency(Integer id) {
        try {
            final TransactionFrequency transactionFrequency = this.transactionFrequencyWrapper.findOneWithNotFoundDetection(id);
            transactionFrequency.setStatus(Status.ACTIVE);
            transactionFrequency.setUpdatedAt(LocalDateTime.now());
            this.transactionFrequencyRepository.saveAndFlush(transactionFrequency);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            TransactionFrequency transactionFrequency = this.transactionFrequencyWrapper.findOneWithNotFoundDetection(id);
            transactionFrequency.setEuid(euid);
            transactionFrequency.setStatus(Status.DELETE);
            transactionFrequency.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(transactionFrequency.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
