package com.ponsun.transaction.accountConfig.accountRelation.domain;

import com.ponsun.transaction.accountConfig.accountRelation.request.CreateAccountRelationRequest;
import com.ponsun.transaction.accountConfig.accountRelation.request.UpdateAccountRelationRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_AccountRelation")
public class AccountRelation extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccountRelation create(final CreateAccountRelationRequest createAccountRelationRequest){
        final AccountRelation accountRelation = new AccountRelation();
        accountRelation.setName(createAccountRelationRequest.getName());
        accountRelation.setCode(createAccountRelationRequest.getCode());
        accountRelation.setUid(createAccountRelationRequest.getUid());
        accountRelation.setStatus(Status.ACTIVE);
        accountRelation.setCreatedAt(LocalDateTime.now());
        return accountRelation;
    }
    public void update(final UpdateAccountRelationRequest updateAccountRelationRequest){
        this.setName(updateAccountRelationRequest.getName());
        this.setCode(updateAccountRelationRequest.getCode());
        this.setEuid(updateAccountRelationRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

