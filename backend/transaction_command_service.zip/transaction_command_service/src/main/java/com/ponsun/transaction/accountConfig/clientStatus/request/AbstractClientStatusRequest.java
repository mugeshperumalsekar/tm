package com.ponsun.transaction.accountConfig.clientStatus.request;

import lombok.Data;

@Data
public class AbstractClientStatusRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
