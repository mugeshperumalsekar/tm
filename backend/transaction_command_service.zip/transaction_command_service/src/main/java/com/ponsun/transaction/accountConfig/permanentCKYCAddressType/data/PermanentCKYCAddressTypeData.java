package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.data;

import lombok.Data;

@Data
public class PermanentCKYCAddressTypeData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;

    public PermanentCKYCAddressTypeData(Integer id, String name, String code, Integer uid, Integer euid) {
        this.id = id;
        this.name = name;
        this.code = code;
        this.uid = uid;
        this.euid = euid;
    }
    public static PermanentCKYCAddressTypeData newInstance(Integer id, String name, String code, Integer uid, Integer euid){
        return new PermanentCKYCAddressTypeData(id,name,code,uid,euid);
    }
}
