package com.ponsun.transaction.accountConfig.insurancePurpose.data;
import lombok.Data;
@Data
public class InsurancePurposeData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public InsurancePurposeData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static InsurancePurposeData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new InsurancePurposeData(id,name,code,uid,euid);
    }
}

