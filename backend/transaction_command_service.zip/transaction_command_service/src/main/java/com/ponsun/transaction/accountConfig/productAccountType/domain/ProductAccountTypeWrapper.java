package com.ponsun.transaction.accountConfig.productAccountType.domain;
import com.ponsun.transaction.accountConfig.productAccountType.requests.AbstractProductAccountTypeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProductAccountTypeWrapper extends AbstractProductAccountTypeRequest {

    private final ProductAccountTypeRepository repository;

    @Transactional
    public ProductAccountType findOneWithNotFoundDetection (final Integer id) {
    return this.repository.findById(id).orElseThrow(() -> new EntityNotFoundException("ProductAccountType Not found " + id));
}
    @Override
    public String toString(){
        return super.toString();
    }

}
