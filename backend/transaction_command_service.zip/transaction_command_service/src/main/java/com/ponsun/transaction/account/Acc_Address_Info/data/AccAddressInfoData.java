package com.ponsun.transaction.account.Acc_Address_Info.data;
import lombok.Data;

@Data
public class AccAddressInfoData {
    private Integer id;
    private Integer customerId;
    private String correspondenceAddressCity;
    private String correspondenceAddressCountry;
    private String correspondenceAddressDistrict;
    private String correspondenceAddressLine1;
    private String correspondenceAddressLine2;
    private String correspondenceAddressLine3;
    private String correspondenceAddressPinCode;
    private String correspondenceAddressProof;
    private String correspondenceAddressState;
    private String permanentAddressCity;
    private String permanentAddressCountry;
    private String permanentAddressDistrict;
    private String permanentAddressLine1;
    private String permanentAddressLine2;
    private String permanentAddressLine3;
    private String permanentAddressPinCode;
    private String permanentAddressProof;
    private String permanentAddressState;
    private String permanentCKYCAddressType;
    private Integer accountId;
    private Integer uid;
    private Integer euid;

    public AccAddressInfoData(Integer id,Integer customerId, String correspondenceAddressCity, String correspondenceAddressCountry, String correspondenceAddressDistrict, String correspondenceAddressLine1, String correspondenceAddressLine2, String correspondenceAddressLine3, String correspondenceAddressPinCode, String correspondenceAddressProof, String correspondenceAddressState, String permanentAddressCity, String permanentAddressCountry, String permanentAddressDistrict, String permanentAddressLine1, String permanentAddressLine2, String permanentAddressLine3, String permanentAddressPinCode, String permanentAddressProof, String permanentAddressState, String permanentCKYCAddressType, Integer accountId, Integer uid, Integer euid) {
        this.id = id;
        this.customerId=customerId;
        this.correspondenceAddressCity = correspondenceAddressCity;
        this.correspondenceAddressCountry = correspondenceAddressCountry;
        this.correspondenceAddressDistrict = correspondenceAddressDistrict;
        this.correspondenceAddressLine1 = correspondenceAddressLine1;
        this.correspondenceAddressLine2 = correspondenceAddressLine2;
        this.correspondenceAddressLine3 = correspondenceAddressLine3;
        this.correspondenceAddressPinCode = correspondenceAddressPinCode;
        this.correspondenceAddressProof = correspondenceAddressProof;
        this.correspondenceAddressState = correspondenceAddressState;
        this.permanentAddressCity = permanentAddressCity;
        this.permanentAddressCountry = permanentAddressCountry;
        this.permanentAddressDistrict = permanentAddressDistrict;
        this.permanentAddressLine1 = permanentAddressLine1;
        this.permanentAddressLine2 = permanentAddressLine2;
        this.permanentAddressLine3 = permanentAddressLine3;
        this.permanentAddressPinCode = permanentAddressPinCode;
        this.permanentAddressProof = permanentAddressProof;
        this.permanentAddressState = permanentAddressState;
        this.permanentCKYCAddressType = permanentCKYCAddressType;
        this.accountId = accountId;
        this.uid = uid;
        this.euid = euid;
    }
    public static AccAddressInfoData newInstance(Integer id,Integer customerId, String correspondenceAddressCity, String correspondenceAddressCountry, String correspondenceAddressDistrict, String correspondenceAddressLine1, String correspondenceAddressLine2, String correspondenceAddressLine3, String correspondenceAddressPinCode, String correspondenceAddressProof, String correspondenceAddressState, String permanentAddressCity, String permanentAddressCountry, String permanentAddressDistrict, String permanentAddressLine1, String permanentAddressLine2, String permanentAddressLine3, String permanentAddressPinCode, String permanentAddressProof, String permanentAddressState, String permanentCKYCAddressType, Integer accountId, Integer uid, Integer euid){
        return new AccAddressInfoData( id,customerId, correspondenceAddressCity, correspondenceAddressCountry, correspondenceAddressDistrict, correspondenceAddressLine1, correspondenceAddressLine2, correspondenceAddressLine3, correspondenceAddressPinCode, correspondenceAddressProof, correspondenceAddressState, permanentAddressCity, permanentAddressCountry, permanentAddressDistrict, permanentAddressLine1, permanentAddressLine2, permanentAddressLine3, permanentAddressPinCode, permanentAddressProof, permanentAddressState, permanentCKYCAddressType, accountId, uid, euid);
    }
}
