package com.ponsun.transaction.account.Acc_Risk_Status_Det.rowmapper;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.data.AccRiskStatusDetData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Service
@Slf4j
@Data
public class AccRiskStatusDetRowMapper implements RowMapper<AccRiskStatusDetData> {
    private final String schema;

    public AccRiskStatusDetRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM tm_acc_risk_status_det ar ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("ar.id as id, ");
        builder.append("ar.accountId as accountId, ");
        builder.append("ar.customerId as customerId, ");
        builder.append("ar.accountRisk as accountRisk, ");
        builder.append("ar.accountRiskEffectiveDate as accountRiskEffectiveDate, ");
        builder.append("ar.accountRiskNextReviewDate as accountRiskNextReviewDate, ");
        builder.append("ar.clientStatus as clientStatus, ");
        builder.append("ar.accountNumber as accountNumber, ");
        builder.append("ar.uid as uid, ");
        builder.append("ar.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccRiskStatusDetData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer accountId = rs.getInt("accountId");
        final Integer customerId = rs.getInt("customerId");
        final String accountRisk = rs.getString("accountRisk");
        final String accountRiskEffectiveDate = rs.getString("accountRiskEffectiveDate");
        final String accountRiskNextReviewDate = rs.getString("accountRiskNextReviewDate");
        final String clientStatus = rs.getString("clientStatus");
        final String accountNumber = rs.getString("accountNumber");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new AccRiskStatusDetData(id,accountId,customerId,accountRisk,accountRiskEffectiveDate,accountRiskNextReviewDate,clientStatus,accountNumber,uid,euid);
    }
}