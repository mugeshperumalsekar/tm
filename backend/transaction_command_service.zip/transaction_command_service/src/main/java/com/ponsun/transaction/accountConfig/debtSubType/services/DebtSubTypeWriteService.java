package com.ponsun.transaction.accountConfig.debtSubType.services;

import com.ponsun.transaction.accountConfig.debtSubType.request.CreateDebtSubTypeRequest;
import com.ponsun.transaction.accountConfig.debtSubType.request.UpdateDebtSubTypeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface DebtSubTypeWriteService {
    Response createDebtSubType(CreateDebtSubTypeRequest createDebtSubTypeRequest);

    Response updateDebtSubType(Integer id, UpdateDebtSubTypeRequest updateDebtSubTypeRequest);

    Response unblockDebtSubType(Integer id);

    Response deActivate(Integer id, Integer euid);
}
