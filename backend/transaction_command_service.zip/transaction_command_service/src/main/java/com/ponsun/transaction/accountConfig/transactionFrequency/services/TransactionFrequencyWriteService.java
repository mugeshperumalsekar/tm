package com.ponsun.transaction.accountConfig.transactionFrequency.services;

import com.ponsun.transaction.accountConfig.transactionFrequency.request.CreateTransactionFrequencyRequest;
import com.ponsun.transaction.accountConfig.transactionFrequency.request.UpdateTransactionFrequencyRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface TransactionFrequencyWriteService {
    Response createTransactionFrequency(CreateTransactionFrequencyRequest createTransactionFrequencyRequest);

    Response updateTransactionFrequency(Integer id, UpdateTransactionFrequencyRequest updateTransactionFrequencyRequest);

    Response unblockTransactionFrequency(Integer id);

    Response deActivate(Integer id, Integer euid);
}
