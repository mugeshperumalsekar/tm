package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.requests;

import lombok.Data;

@Data
public class UpdatePermanentCKYCAddressTypeRequest extends AbstractPermanentCKYCAddressTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
