package com.ponsun.transaction.account.Acc_Holder_Details.services;

import com.ponsun.transaction.account.Acc_Holder_Details.data.AccHolderDetailsValidator;
import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetails;
import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetailsRepository;
import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetailsWrapper;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.CreateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.UpdateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccHolderDetailsWriteServiceImpl implements AccHolderDetailsWriteService {
    private final AccHolderDetailsRepository repository;
    private final AccHolderDetailsWrapper wrapper;
    private final AccHolderDetailsValidator validator;
    private final AccInfoWrapper accInfoWrapper;
    @Override
    @Transactional

    public Response createAccHolderDetails(CreateAccHolderDetailsRequest request) {
        try {
            this.validator.validateSaveAccHolderDetails(request);

            AccInfo accInfo = accInfoWrapper.findOneWithNotFoundDetection(request.getAccountId());
            if (accInfo == null) {
                throw new PS_transaction_ApplicationException("Account information not found for accountId: " + request.getAccountId());
            }

            final AccHolderDetails holderDetails = AccHolderDetails.create(request,accInfo);
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(holderDetails.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccHolderDetails(Integer id, UpdateAccHolderDetailsRequest request) {
        try {
            this.validator.validateUpdateAccHolderDetails(request);
            final AccHolderDetails holderDetails = this.wrapper.findOneWithNotFoundDetection(id);
            holderDetails.update(request);
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(holderDetails.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccHolderDetails(Integer id) {
        try {
            final AccHolderDetails holderDetails = this.wrapper.findOneWithNotFoundDetection(id);
            holderDetails.setStatus(Status.ACTIVE);
            holderDetails.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccHolderDetails holderDetails = this.wrapper.findOneWithNotFoundDetection(id);
            holderDetails.setEuid(euid);
            holderDetails.setStatus(Status.DELETE);
            holderDetails.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(holderDetails);
            return Response.of(Long.valueOf(holderDetails.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }
}
