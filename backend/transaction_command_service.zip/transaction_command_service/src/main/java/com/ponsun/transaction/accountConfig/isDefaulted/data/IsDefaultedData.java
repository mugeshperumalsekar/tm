package com.ponsun.transaction.accountConfig.isDefaulted.data;
import lombok.Data;
@Data
public class IsDefaultedData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public IsDefaultedData (final Integer id, final String name,final String code, final Integer uid,final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static IsDefaultedData newInstance (final Integer id, final String name,final String code, final Integer uid, final Integer euid ) {
        return new IsDefaultedData(id,name,code,uid,euid);
    }
}

