package com.ponsun.transaction.accountConfig.accountProductSegment.data;

import com.ponsun.transaction.accountConfig.accountProductSegment.requests.CreateAccountProductSegmentRequest;
import com.ponsun.transaction.accountConfig.accountProductSegment.requests.UpdateAccountProductSegmentRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AccountProductSegmentValidator {
    public void validateSaveAccProductSegment(final CreateAccountProductSegmentRequest request){
        if (request.getId()== null || request.getId().equals("")){
            throw new PS_transaction_ApplicationException("id parameter required");
        }
    }
    public void validateUpdateAccProductSegment(final UpdateAccountProductSegmentRequest request){
        if(request.getId() == null || request.getId().equals("")) {
            throw new PS_transaction_ApplicationException("id parameter required");

        }
    }
}
