package com.ponsun.transaction.account.Acc_Info.services;

import com.ponsun.transaction.account.Acc_Info.data.AccInfoValidator;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoRepository;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.account.Acc_Info.requests.CreateAccInfoRequest;
import com.ponsun.transaction.account.Acc_Info.requests.UpdateAccInfoRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccInfoWriteServiceImpl implements AccInfoWriteService {
    private final AccInfoRepository repository;
    private final AccInfoWrapper wrapper;
    private final AccInfoValidator validator;

    @Override
    @Transactional

    public Response createAccInfo(CreateAccInfoRequest request) {
        try {
            this.validator.validateSaveAccInfo(request);
            final AccInfo accInfo = AccInfo.create(request);
            this.repository.saveAndFlush(accInfo);
            return Response.of(Long.valueOf(accInfo.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccInfo(Integer id, UpdateAccInfoRequest request) {
        try {
            this.validator.validateUpdateAccInfo(request);
            final AccInfo accInfo = this.wrapper.findOneWithNotFoundDetection(id);
            accInfo.update(request);
            this.repository.saveAndFlush(accInfo);
            return Response.of(Long.valueOf(accInfo.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccInfo(Integer id) {
        try {
            final AccInfo accInfo = this.wrapper.findOneWithNotFoundDetection(id);
            accInfo.setStatus(Status.ACTIVE);
            accInfo.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accInfo);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccInfo accInfo = this.wrapper.findOneWithNotFoundDetection(id);
            accInfo.setEuid(euid);
            accInfo.setStatus(Status.DELETE);
            accInfo.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(accInfo);
            return Response.of(Long.valueOf(accInfo.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }
}
