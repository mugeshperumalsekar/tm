package com.ponsun.transaction.accountConfig.policyType.request;

import lombok.Data;

@Data
public class UpdatePolicyTypeRequest extends AbstractPolicyTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}