package com.ponsun.transaction.account.Acc_Holder_Details.services;

import com.ponsun.transaction.account.Acc_Holder_Details.requests.CreateAccHolderDetailsRequest;
import com.ponsun.transaction.account.Acc_Holder_Details.requests.UpdateAccHolderDetailsRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccHolderDetailsWriteService {
    Response createAccHolderDetails(CreateAccHolderDetailsRequest request);
    Response updateAccHolderDetails(Integer id, UpdateAccHolderDetailsRequest request);
    Response unblockAccHolderDetails(Integer id);
    Response deactive(Integer id, Integer euid);
}
