package com.ponsun.transaction.accountConfig.lendingArrangement.request;

import lombok.Data;

@Data
public class CreateLendingArrangementRequest  extends AbstractLendingArrangementRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

