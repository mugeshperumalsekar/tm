package com.ponsun.transaction.accountConfig.regAMLRisk.api;


import com.ponsun.transaction.accountConfig.regAMLRisk.request.CreateRegAMLRiskRequest;
import com.ponsun.transaction.accountConfig.regAMLRisk.request.UpdateRegAMLRiskRequest;
import com.ponsun.transaction.accountConfig.regAMLRisk.services.RegAMLRiskReadService;
import com.ponsun.transaction.accountConfig.regAMLRisk.services.RegAMLRiskWriteService;
import com.ponsun.transaction.accountConfig.regAMLRisk.domain.RegAMLRisk;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/RegAMLRisk")
@Tag(name = "RegAMLRiskApiResource")
public class RegAMLRiskApiResources {
    private final RegAMLRiskWriteService regAMLRiskWriteService;
    private final RegAMLRiskReadService regAMLRiskReadService;

    @PostMapping("/CreateRegAMLRiskRequest")
    public Response saveRegAMLRisk(@RequestBody CreateRegAMLRiskRequest createRegAMLRiskRequest) {
        log.debug("START saveRegAMLRisk request body {}",createRegAMLRiskRequest);
        Response response = this.regAMLRiskWriteService.createRegAMLRisk(createRegAMLRiskRequest);
        log.debug("START saveRegAMLRisk response",response);
        return response;
    }

    @GetMapping
    public List<RegAMLRisk> fetchAll() {
        return this.regAMLRiskReadService.fetchAllRegAMLRisk();
    }

    @GetMapping("/{id}")
    public RegAMLRisk fetchRegAMLRiskById(@PathVariable(name = "id") Integer id) {
        return this.regAMLRiskReadService.fetchRegAMLRiskById(id);
    }

    @PutMapping("/{id}")
    public Response updateRegAMLRisk(@PathVariable Integer id, @RequestBody UpdateRegAMLRiskRequest updateRegAMLRiskRequest) {
        log.debug("START updateRegAMLRisk request body {}",updateRegAMLRiskRequest);
        Response response = this.regAMLRiskWriteService.updateRegAMLRisk(id, updateRegAMLRiskRequest);
        log.debug("START updateRegAMLRisk response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockRegAMLRisk(@PathVariable Integer id){
        Response response = this.regAMLRiskWriteService.unblockRegAMLRisk(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.regAMLRiskWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<RegAMLRisk> fetchActiveRegAMLRisk() {
        return regAMLRiskReadService.fetchActiveRegAMLRisk();
    }
    @GetMapping("DeActive")
    public List<RegAMLRisk> fetchDeRegAMLRisk() {
        return regAMLRiskReadService.fetchDeActiveRegAMLRisk();
    }

}

