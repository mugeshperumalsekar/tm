package com.ponsun.transaction.accountConfig.clientStatus.data;



import com.ponsun.transaction.accountConfig.clientStatus.request.CreateClientStatusRequest;
import com.ponsun.transaction.accountConfig.clientStatus.request.UpdateClientStatusRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ClientStatusValidator {
    public void validateSaveClientStatus(final CreateClientStatusRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateClientStatus(final UpdateClientStatusRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");


        }
    }
}
