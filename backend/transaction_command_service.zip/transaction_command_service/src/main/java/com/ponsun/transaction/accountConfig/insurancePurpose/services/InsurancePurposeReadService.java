package com.ponsun.transaction.accountConfig.insurancePurpose.services;

import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurpose;

import java.util.List;

public interface InsurancePurposeReadService {
    List<InsurancePurpose> fetchAllInsurancePurpose();

    InsurancePurpose fetchInsurancePurposeById(Integer id);

    List<InsurancePurpose> fetchActiveInsurancePurpose();

    List<InsurancePurpose> fetchDeActiveInsurancePurpose();
}
