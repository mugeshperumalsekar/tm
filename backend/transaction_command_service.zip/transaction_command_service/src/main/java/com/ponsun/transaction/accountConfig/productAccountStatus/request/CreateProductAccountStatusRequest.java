package com.ponsun.transaction.accountConfig.productAccountStatus.request;

import lombok.Data;

@Data
public class CreateProductAccountStatusRequest extends AbstractProductAccountStatusRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}