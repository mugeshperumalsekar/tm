package com.ponsun.transaction.account.Acc_Risk_Status_Det.domain;
import com.ponsun.transaction.common.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AccRiskStatusDetRepository extends JpaRepository<AccRiskStatusDet,Integer> {
    List<AccRiskStatusDet> findByStatus(Status string);
    @Query("SELECT x FROM AccRiskStatusDet x WHERE x.id = :id AND x.status = 'A'")
    Optional<AccRiskStatusDet> findByIdAndStatus(@Param("id") Integer id);


}
