package com.ponsun.transaction.accountConfig.modeOfAccount.request;

import lombok.Data;

@Data
public class CreateModeOfAccountRequest extends AbstractModeOfAccountRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
