package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.rowmapper;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.data.PermanentCKYCAddressTypeData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
@Data
@Service
@Slf4j
public class PermanentCKYCAddressTypeRowMapper implements RowMapper<PermanentCKYCAddressTypeData> {
    public final String schema;
    public PermanentCKYCAddressTypeRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM tm_config_permanent_CKYC_address_type pat ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("pat.id as id ,");
        builder.append("pat.name as name ,");
        builder.append("pat.code as code ,");
        builder.append("pat.uid as uid ,");
        builder.append("pat.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public PermanentCKYCAddressTypeData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final String name = rs.getString("name");
        final String code = rs.getString("code");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new PermanentCKYCAddressTypeData(id, name, code, uid, euid);
    }
}
