package com.ponsun.transaction.accountConfig.accountRelation.services;

import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelation;
import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelationRepository;
import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelationWrapper;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountRelationReadServiceImpl implements AccountRelationReadService {
    private final AccountRelationWrapper accountRelationWrapper;
    private final JdbcTemplate jdbcTemplate;
    private final AccountRelationRepository accountRelationRepository;

    @Override
    public AccountRelation fetchAccountRelationById(Integer id) {
        return this.accountRelationRepository.findById(id).get();
    }

    @Override
    public List<AccountRelation> fetchActiveAccountRelation() {
        return this.accountRelationRepository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<AccountRelation> fetchDeActiveAccountRelation() {
        return this.accountRelationRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<AccountRelation> fetchAllAccountRelation() {
        return this.accountRelationRepository.findAll();
    }
}
