package com.ponsun.transaction.accountConfig.isDefaulted.data;


import com.ponsun.transaction.accountConfig.isDefaulted.request.CreateIsDefaultedRequest;
import com.ponsun.transaction.accountConfig.isDefaulted.request.UpdateIsDefaultedRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class IsDefaultedValidator {
    public void validateSaveIsDefaulted(final CreateIsDefaultedRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateIsDefaulted(final UpdateIsDefaultedRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
