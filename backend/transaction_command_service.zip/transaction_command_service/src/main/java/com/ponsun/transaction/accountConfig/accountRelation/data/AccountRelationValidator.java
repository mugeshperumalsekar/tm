package com.ponsun.transaction.accountConfig.accountRelation.data;


import com.ponsun.transaction.accountConfig.accountRelation.request.CreateAccountRelationRequest;
import com.ponsun.transaction.accountConfig.accountRelation.request.UpdateAccountRelationRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountRelationValidator {
    public void validateSaveAccountRelation(final CreateAccountRelationRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateAccountRelation(final UpdateAccountRelationRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
