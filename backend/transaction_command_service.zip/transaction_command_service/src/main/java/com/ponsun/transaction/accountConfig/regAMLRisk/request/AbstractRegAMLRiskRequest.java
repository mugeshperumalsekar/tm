package com.ponsun.transaction.accountConfig.regAMLRisk.request;

import lombok.Data;

@Data
public class AbstractRegAMLRiskRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
