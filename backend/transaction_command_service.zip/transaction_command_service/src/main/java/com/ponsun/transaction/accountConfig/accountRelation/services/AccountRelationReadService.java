package com.ponsun.transaction.accountConfig.accountRelation.services;

import com.ponsun.transaction.accountConfig.accountRelation.domain.AccountRelation;

import java.util.List;

public interface AccountRelationReadService {
    List<AccountRelation> fetchAllAccountRelation();

    AccountRelation fetchAccountRelationById(Integer id);

    List<AccountRelation> fetchActiveAccountRelation();

    List<AccountRelation> fetchDeActiveAccountRelation();
}
