package com.ponsun.transaction.accountConfig.modeOfAccount.data;


import com.ponsun.transaction.accountConfig.modeOfAccount.request.CreateModeOfAccountRequest;
import com.ponsun.transaction.accountConfig.modeOfAccount.request.UpdateModeOfAccountRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ModeOfAccountValidator {
    public void validateSaveModeOfAccount(final CreateModeOfAccountRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateModeOfAccount(final UpdateModeOfAccountRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
