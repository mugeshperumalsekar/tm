package com.ponsun.transaction.accountConfig.policyType.services;

import com.ponsun.transaction.accountConfig.policyType.request.UpdatePolicyTypeRequest;
import com.ponsun.transaction.accountConfig.policyType.request.CreatePolicyTypeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface PolicyTypeWriteService {
    Response createPolicyType(CreatePolicyTypeRequest createPolicyTypeRequest);

    Response updatePolicyType(Integer id, UpdatePolicyTypeRequest updatePolicyTypeRequest);

    Response unblockPolicyType(Integer id);

    Response deActivate(Integer id, Integer euid);
}
