package com.ponsun.transaction.accountConfig.insurancePurpose.api;


import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurpose;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.CreateInsurancePurposeRequest;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.UpdateInsurancePurposeRequest;
import com.ponsun.transaction.accountConfig.insurancePurpose.services.InsurancePurposeReadService;
import com.ponsun.transaction.accountConfig.insurancePurpose.services.InsurancePurposeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/InsurancePurpose")
@Tag(name = "InsurancePurposeApiResource")
public class InsurancePurposeApiResources {
    private final InsurancePurposeWriteService insurancePurposeWriteService;
    private final InsurancePurposeReadService insurancePurposeReadService;

    @PostMapping("/CreateInsurancePurposeRequest")
    public Response saveInsurancePurpose(@RequestBody CreateInsurancePurposeRequest createInsurancePurposeRequest) {
        log.debug("START saveInsurancePurpose request body {}",createInsurancePurposeRequest);
        Response response = this.insurancePurposeWriteService.createInsurancePurpose(createInsurancePurposeRequest);
        log.debug("START saveInsurancePurpose response",response);
        return response;
    }

    @GetMapping
    public List<InsurancePurpose> fetchAll() {
        return this.insurancePurposeReadService.fetchAllInsurancePurpose();
    }

    @GetMapping("/{id}")
    public InsurancePurpose fetchInsurancePurposeById(@PathVariable(name = "id") Integer id) {
        return this.insurancePurposeReadService.fetchInsurancePurposeById(id);
    }

    @PutMapping("/{id}")
    public Response updateInsurancePurpose(@PathVariable Integer id, @RequestBody UpdateInsurancePurposeRequest updateInsurancePurposeRequest) {
        log.debug("START updateInsurancePurpose request body {}",updateInsurancePurposeRequest);
        Response response = this.insurancePurposeWriteService.updateInsurancePurpose(id, updateInsurancePurposeRequest);
        log.debug("START updateInsurancePurpose response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockInsurancePurpose(@PathVariable Integer id){
        Response response = this.insurancePurposeWriteService.unblockInsurancePurpose(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.insurancePurposeWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<InsurancePurpose> fetchActiveInsurancePurpose() {
        return insurancePurposeReadService.fetchActiveInsurancePurpose();
    }
    @GetMapping("DeActive")
    public List<InsurancePurpose> fetchDeInsurancePurpose() {
        return insurancePurposeReadService.fetchDeActiveInsurancePurpose();
    }

}

