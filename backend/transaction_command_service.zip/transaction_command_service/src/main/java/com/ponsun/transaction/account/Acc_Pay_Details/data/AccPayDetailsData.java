package com.ponsun.transaction.account.Acc_Pay_Details.data;
import lombok.Data;

@Data
public class AccPayDetailsData {
    private Integer id;
    private double amountofLastRepayment;
    private Integer customerId;
    private double amountoverdue;
    private Integer daysPastDue;
    private double otherChargesOutstanding;
    private Integer payTerm;
    private Integer tenureinMonths;
    private Integer accountId;
    private Integer uid;
    private Integer euid;

    public AccPayDetailsData(Integer id, double amountofLastRepayment,Integer customerId, double amountoverdue, Integer daysPastDue, double otherChargesOutstanding, Integer payTerm, Integer tenureinMonths, Integer accountId, Integer uid, Integer euid) {
        this.id = id;
        this.amountofLastRepayment = amountofLastRepayment;
        this.customerId=customerId;
        this.amountoverdue = amountoverdue;
        this.daysPastDue = daysPastDue;
        this.otherChargesOutstanding = otherChargesOutstanding;
        this.payTerm = payTerm;
        this.tenureinMonths = tenureinMonths;
        this.accountId = accountId;
        this.uid = uid;
        this.euid = euid;
    }
    public static AccPayDetailsData newInstnce(Integer id, double amountofLastRepayment,Integer customerId, double amountoverdue, Integer daysPastDue, double otherChargesOutstanding, Integer payTerm, Integer tenureinMonths, Integer accountId, Integer uid, Integer euid){
        return new AccPayDetailsData( id, amountofLastRepayment,customerId, amountoverdue, daysPastDue, otherChargesOutstanding, payTerm, tenureinMonths, accountId, uid, euid);
    }
}
