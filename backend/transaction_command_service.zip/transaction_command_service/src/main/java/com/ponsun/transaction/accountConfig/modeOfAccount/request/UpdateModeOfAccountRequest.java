package com.ponsun.transaction.accountConfig.modeOfAccount.request;

import lombok.Data;

@Data
public class UpdateModeOfAccountRequest extends AbstractModeOfAccountRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
