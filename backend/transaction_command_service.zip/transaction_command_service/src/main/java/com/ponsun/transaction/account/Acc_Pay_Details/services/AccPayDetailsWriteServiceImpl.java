package com.ponsun.transaction.account.Acc_Pay_Details.services;

import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoWrapper;
import com.ponsun.transaction.account.Acc_Pay_Details.data.AccPayDetailsValidator;
import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetails;
import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetailsRepository;
import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetailsWrapper;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.CreateAccPayDetailsRequest;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.UpdateAccPayDetailsRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccPayDetailsWriteServiceImpl implements AccPayDetailsWriteService {
    private final AccPayDetailsRepository repository;
    private final AccPayDetailsWrapper wrapper;
    private final AccPayDetailsValidator validator;
    private final AccInfoWrapper accInfoWrapper;

    @Override
    @Transactional

    public Response createAccPayDetails(CreateAccPayDetailsRequest request) {
        try {
            this.validator.validateSaveAccPayDetails(request);

            AccInfo accInfo = accInfoWrapper.findOneWithNotFoundDetection(request.getAccountId());
            if (accInfo == null){
                throw new PS_transaction_ApplicationException("Account information not found for accountId: " + request.getAccountId());
            }

            final AccPayDetails payDetails = AccPayDetails.create(request,accInfo);
            this.repository.saveAndFlush(payDetails);
            return Response.of(Long.valueOf(payDetails.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateAccPayDetails(Integer id, UpdateAccPayDetailsRequest request) {
        try {
            this.validator.validateUpdateAccPayDetails(request);
            final AccPayDetails payDetails = this.wrapper.findOneWithNotFoundDetection(id);
            payDetails.update(request);
            this.repository.saveAndFlush(payDetails);
            return Response.of(Long.valueOf(payDetails.getId()));

        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockAccPayDetails(Integer id) {
        try {
            final AccPayDetails payDetails = this.wrapper.findOneWithNotFoundDetection(id);
            payDetails.setStatus(Status.ACTIVE);
            payDetails.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(payDetails);
            return Response.of(Long.valueOf(id));
        }
        catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try{
            AccPayDetails payDetails = this.wrapper.findOneWithNotFoundDetection(id);
            payDetails.setEuid(euid);
            payDetails.setStatus(Status.DELETE);
            payDetails.setUpdatedAt(LocalDateTime.now());
            this.repository.saveAndFlush(payDetails);
            return Response.of(Long.valueOf(payDetails.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }    }
}
