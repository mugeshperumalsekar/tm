package com.ponsun.transaction.accountConfig.insurancePurpose.request;

import lombok.Data;

@Data
public class CreateInsurancePurposeRequest extends AbstractInsurancePurposeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

