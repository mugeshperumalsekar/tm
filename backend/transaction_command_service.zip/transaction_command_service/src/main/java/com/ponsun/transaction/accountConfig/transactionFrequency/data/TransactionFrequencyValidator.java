package com.ponsun.transaction.accountConfig.transactionFrequency.data;


import com.ponsun.transaction.accountConfig.transactionFrequency.request.CreateTransactionFrequencyRequest;
import com.ponsun.transaction.accountConfig.transactionFrequency.request.UpdateTransactionFrequencyRequest;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class TransactionFrequencyValidator {
    public void validateSaveTransactionFrequency(final CreateTransactionFrequencyRequest request){
        if (request.getName()== null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
    public void validateUpdateTransactionFrequency(final UpdateTransactionFrequencyRequest request){
        if(request.getName() == null || request.getName().equals("")){
            throw new PS_transaction_ApplicationException("Name parameter required");
        }
    }
}
