package com.ponsun.transaction.accountConfig.reasonCode.services;

import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCode;

import java.util.List;

public interface ReasonCodeReadService {
    List<ReasonCode> fetchAllReasonCode();

    ReasonCode fetchReasonCodeById(Integer id);

    List<ReasonCode> fetchActiveReasonCode();

    List<ReasonCode> fetchDeActiveReasonCode();
}
