package com.ponsun.transaction.accountConfig.productAccountStatus.services;

import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatus;
import com.ponsun.transaction.accountConfig.productAccountStatus.domain.ProductAccountStatusRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductAccountStatusReadServiceImpl implements ProductAccountStatusReadService {
    private final ProductAccountStatusRepository productAccountStatusRepository;

    @Override
    public ProductAccountStatus fetchProductAccountStatusById(Integer id) {
        return this.productAccountStatusRepository.findById(id).get();
    }

    @Override

    public List<ProductAccountStatus> fetchActiveProductAccountStatus() {
        return this.productAccountStatusRepository.findByStatus(Status.ACTIVE);
    }


    @Override
    public List<ProductAccountStatus> fetchDeActiveProductAccountStatus() {
        return this.productAccountStatusRepository.findByStatus(Status.DELETE);
    }

    @Override
    public List<ProductAccountStatus> fetchAllProductAccountStatus() {
        return this.productAccountStatusRepository.findAll();
    }
}
