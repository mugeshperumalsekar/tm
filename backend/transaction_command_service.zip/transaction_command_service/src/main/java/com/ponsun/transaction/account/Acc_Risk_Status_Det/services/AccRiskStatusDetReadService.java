package com.ponsun.transaction.account.Acc_Risk_Status_Det.services;

import com.ponsun.transaction.account.Acc_Risk_Status_Det.domain.AccRiskStatusDet;

import java.util.List;

public interface AccRiskStatusDetReadService {
    AccRiskStatusDet fetchAccRiskStatusDetById(Integer id);
    List<AccRiskStatusDet> fetchAllAccRiskStatusDet();
    List<AccRiskStatusDet> fetchActiveAccRiskStatusDet();
    List<AccRiskStatusDet> fetchDeActiveAccRiskStatusDet();

}
