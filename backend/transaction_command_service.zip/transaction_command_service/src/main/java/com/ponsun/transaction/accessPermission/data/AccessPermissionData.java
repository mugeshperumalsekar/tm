package com.ponsun.transaction.accessPermission.data;

import lombok.Data;

import java.util.List;

@Data
public class AccessPermissionData {
    private String name;
    private String code;
    private String link;
    private String header;
    private String uid;
    private String menu;
    private String icon;
    private String path;
    private List<AccessPermissionData> subMenu;


    public AccessPermissionData(final String name,final String code,final String link,final String uid,final String header){
        this.name = name;
        this.code = code;
        this.link = link;
        this.uid = uid;
       this.header = header;
    }
    public static AccessPermissionData newInstance(final String name,final String code,final String link,final String uid,final String header){
        return new AccessPermissionData(name,code,link,uid,header);
    }

    public AccessPermissionData(String uid, String menu, String icon, String path, List<AccessPermissionData> subMenu) {
        this.uid = uid;
        this.menu = menu;
        this.icon = icon;
        this.path = path;
        this.subMenu = subMenu;
    }

    public AccessPermissionData(String uid, String menu, String icon, String path) {
        this.uid = uid;
        this.menu = menu;
        this.icon = icon;
        this.path = path;
    }
}
