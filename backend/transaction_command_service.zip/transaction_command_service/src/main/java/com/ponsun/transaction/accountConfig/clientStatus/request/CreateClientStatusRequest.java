package com.ponsun.transaction.accountConfig.clientStatus.request;

import lombok.Data;

@Data
public class CreateClientStatusRequest extends AbstractClientStatusRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}

