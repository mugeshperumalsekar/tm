package com.ponsun.transaction.adminconfiguration.AdminUser.services;

import com.ponsun.transaction.adminconfiguration.AdminUser.domain.User;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.CreateUserRequest;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.LoginUserDto;
import com.ponsun.transaction.adminconfiguration.AdminUser.request.UpdateUserRequest;
import com.ponsun.transaction.infrastructure.utils.Response;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserWritePlatformService {

    Response createUser(CreateUserRequest createUserRequest);

    User authenticate(LoginUserDto input);

    @Transactional
    Response updateUser(Integer id, UpdateUserRequest updateUserRequest);

    @Transactional
    Response blockUser(Integer id);
    @Transactional
    Response unblockUser(Integer id);

}
