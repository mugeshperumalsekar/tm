package com.ponsun.transaction.account.Acc_transaction.domain;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_transaction.requests.CreateAccTransactionRequest;
import com.ponsun.transaction.account.Acc_transaction.requests.UpdateAccTransactionRequest;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentType;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_acc_transaction_testing")
public class AccTransaction extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "accountId", referencedColumnName = "id", nullable = false)
    private AccInfo accInfo;

    @Column(name = "amt")
    private double amt;

    @Column(name = "transStatus")
    private String transStatus;

    @Column(name = "applicationNumber")
    private String applicationNumber;

    @Column(name = "cardSubtype")
    private String cardSubtype;

    @Column(name = "cardType")
    private String cardType;

    @Column(name = "clientBankName")
    private String clientBankName;

    @Column(name = "clientBankCode")
    private String clientBankCode;

    @Column(name = "clientBankAccountNo")
    private String clientBankAccountNo;

    @Column(name = "counterPartyProductAccountType")
    private String counterPartyProductAccountType;

    @Column(name = "counterPartyProductAccountNumber")
    private String counterPartyProductAccountNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "instrumentTypeId", referencedColumnName = "id")
    private InstrumentType instrumentType;

    @Column(name = "instrumentNo")
    private String instrumentNo;

    @Column(name = "originalCurrency")
    private String originalCurrency;

    @Column(name = "organisationPoolAccount")
    private String organisationPoolAccount;

    @Column(name = "isCalc")
    private Integer isCalc;

    @Column(name = "remark" , columnDefinition = "TEXT")
    private String remark;

    @Column(name = "transactionDate")
    private LocalDateTime transactionDate;

    @Column(name = "circleDate")
    private LocalDateTime circleDate;

    @Column(name = "voucherTypeId")
    private Integer voucherTypeId;

    @Column(name = "type2Id")
    private Integer type2Id;

    @Column(name = "voucherNo")
    private String voucherNo;

    @Column(name = "userId")
    private String userId;

    @Column(name = "uid")
    private String uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccTransaction create(final CreateAccTransactionRequest request,AccInfo accInfo,InstrumentType instrumentType) {
        final AccTransaction accTransaction = new AccTransaction();
        accTransaction.setAccInfo(accInfo);
        accTransaction.setAmt(request.getAmt());
        accTransaction.setTransStatus(request.getTransStatus());
        accTransaction.setApplicationNumber(request.getApplicationNumber());
        accTransaction.setCardSubtype(request.getCardSubtype());
        accTransaction.setCardType(request.getCardType());
        accTransaction.setClientBankName(request.getClientBankName());
        accTransaction.setClientBankCode(request.getClientBankCode());
        accTransaction.setClientBankAccountNo(request.getClientBankAccountNo());
        accTransaction.setCounterPartyProductAccountType(request.getCounterPartyProductAccountType());
        accTransaction.setCounterPartyProductAccountNumber(request.getCounterPartyProductAccountNumber());
        accTransaction.setInstrumentType(instrumentType);
        accTransaction.setInstrumentNo(request.getInstrumentNo());
        accTransaction.setOriginalCurrency(request.getOriginalCurrency());
        accTransaction.setOrganisationPoolAccount(request.getOrganisationPoolAccount());
        accTransaction.setRemark(request.getRemark());
        accTransaction.setTransactionDate((request.getTransactionDate()));
        accTransaction.setVoucherTypeId(request.getVoucherTypeId());
        accTransaction.setType2Id(request.getType2Id());
        accTransaction.setVoucherNo(request.getVoucherNo());
        accTransaction.setUserId(request.getUserId());
        accTransaction.setUid(request.getUid());
        accTransaction.setEuid(request.getEuid());
        accTransaction.setStatus(Status.ACTIVE);
        accTransaction.setCreatedAt(LocalDateTime.now());
        return accTransaction;
    }
        public void update(final UpdateAccTransactionRequest request,InstrumentType instrumentType) {
            this.setAmt(request.getAmt());
            this.setTransStatus(request.getTransStatus());
            this.setApplicationNumber(request.getApplicationNumber());
            this.setCardSubtype(request.getCardSubtype());
            this.setCardType(request.getCardType());
            this.setClientBankName(request.getClientBankName());
            this.setClientBankCode(request.getClientBankCode());
            this.setClientBankAccountNo(request.getClientBankAccountNo());
            this.setCounterPartyProductAccountType(request.getCounterPartyProductAccountType());
            this.setCounterPartyProductAccountNumber(request.getCounterPartyProductAccountNumber());
            this.setInstrumentType(instrumentType);
            this.setInstrumentNo(request.getInstrumentNo());
            this.setOriginalCurrency(request.getOriginalCurrency());
            this.setOrganisationPoolAccount(request.getOrganisationPoolAccount());
            this.setRemark(request.getRemark());
            this.setTransactionDate((request.getTransactionDate()));
            this.setVoucherTypeId(request.getVoucherTypeId());
            this.setType2Id(request.getType2Id());
            this.setVoucherNo(request.getVoucherNo());
            this.setUid(request.getUid());
            this.setUserId(request.getUserId());
            this.setEuid(request.getEuid());
            this.setStatus(Status.ACTIVE);
            this.setUpdatedAt(LocalDateTime.now());
        }

}