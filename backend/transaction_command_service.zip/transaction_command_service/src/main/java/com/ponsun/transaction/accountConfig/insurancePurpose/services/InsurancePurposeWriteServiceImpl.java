package com.ponsun.transaction.accountConfig.insurancePurpose.services;


import com.ponsun.transaction.accountConfig.insurancePurpose.data.InsurancePurposeValidator;
import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurpose;
import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurposeRepository;
import com.ponsun.transaction.accountConfig.insurancePurpose.domain.InsurancePurposeWrapper;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.CreateInsurancePurposeRequest;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.UpdateInsurancePurposeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class InsurancePurposeWriteServiceImpl implements InsurancePurposeWriteService {

    private final InsurancePurposeRepository insurancePurposeRepository;
    private final InsurancePurposeWrapper insurancePurposeWrapper;
    private final InsurancePurposeValidator insurancePurposeValidator;

    @Override
    @Transactional
    public Response createInsurancePurpose(CreateInsurancePurposeRequest createInsurancePurposeRequest) {
        try {
            this.insurancePurposeValidator.validateSaveInsurancePurpose(createInsurancePurposeRequest);
            final InsurancePurpose insurancePurpose = InsurancePurpose.create(createInsurancePurposeRequest);
            this.insurancePurposeRepository.saveAndFlush(insurancePurpose);
            return Response.of(Long.valueOf(insurancePurpose.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateInsurancePurpose(Integer id, UpdateInsurancePurposeRequest updateInsurancePurposeRequest) {
        try {
            this.insurancePurposeValidator.validateUpdateInsurancePurpose(updateInsurancePurposeRequest);
            final InsurancePurpose insurancePurpose = this.insurancePurposeWrapper.findOneWithNotFoundDetection(id);
            insurancePurpose.update(updateInsurancePurposeRequest);
            this.insurancePurposeRepository.saveAndFlush(insurancePurpose);
            return Response.of(Long.valueOf(insurancePurpose.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockInsurancePurpose(Integer id) {
        try {
            final InsurancePurpose insurancePurpose = this.insurancePurposeWrapper.findOneWithNotFoundDetection(id);
            insurancePurpose.setStatus(Status.ACTIVE);
            insurancePurpose.setUpdatedAt(LocalDateTime.now());
            this.insurancePurposeRepository.saveAndFlush(insurancePurpose);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            InsurancePurpose insurancePurpose = this.insurancePurposeWrapper.findOneWithNotFoundDetection(id);
            insurancePurpose.setEuid(euid);
            insurancePurpose.setStatus(Status.DELETE);
            insurancePurpose.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(insurancePurpose.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
