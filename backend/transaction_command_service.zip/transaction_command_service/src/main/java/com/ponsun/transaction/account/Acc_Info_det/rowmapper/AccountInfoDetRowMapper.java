package com.ponsun.transaction.account.Acc_Info_det.rowmapper;

import com.ponsun.transaction.account.Acc_Info_det.data.AccountInfoDetData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Data
@Service
@Slf4j
public class AccountInfoDetRowMapper implements RowMapper<AccountInfoDetData> {
    private final String schema;
    public AccountInfoDetRowMapper(){
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM tm_acc_info_det aid ");
        this.schema = builder.toString();
    }
    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("aid.id as id, ");
        builder.append("aid.accountId as accountId, ");
        builder.append("aid.accountNumber as accountNumber, ");
        builder.append("aid.customerId as customerId, ");
        builder.append("aid.accountRisk as accountRisk, ");
        builder.append("aid.accountRiskEffectiveDate as accountRiskEffectiveDate, ");
        builder.append("aid.accountRiskNextReviewDate as accountRiskNextReviewDate, ");
        builder.append("aid.accountSegment as accountSegment, ");
        builder.append("aid.accountSegmentEffectiveDate as accountSegmentEffectiveDate, ");
        builder.append("aid.accountType as accountType, ");
        builder.append("aid.applicationNumber as applicationNumber, ");
        builder.append("aid.applicationSignedDate as applicationSignedDate, ");
        builder.append("aid.asOfDate as asOfDate, ");
        builder.append("aid.bankCode as bankCode, ");
        builder.append("aid.bankName as bankName, ");
        builder.append("aid.bankbranchname as bankbranchname, ");
        builder.append("aid.channel as channel, ");
        builder.append("aid.clientStatus as clientStatus, ");
        builder.append("aid.creditorBusinessUnit as creditorBusinessUnit, ");
        builder.append("aid.creditorRMEmail as creditorRMEmail, ");
        builder.append("aid.currency as currency, ");
        builder.append("aid.dpid as dpid, ");
        builder.append("aid.fundedType as fundedType, ");
        builder.append("aid.grossAnnualPremiumwithTax as grossAnnualPremiumwithTax, ");
        builder.append("aid.grossAnnualPremiumwithoutTax as grossAnnualPremiumwithoutTax, ");
        builder.append("aid.ifscCode as ifscCode, ");
        builder.append("aid.incomeMultiplier as incomeMultiplier, ");
        builder.append("aid.insurancePurpose as insurancePurpose, ");
        builder.append("aid.intermediaryCode as intermediaryCode, ");
        builder.append("aid.introducerEmployeeCode as introducerEmployeeCode, ");
        builder.append("aid.micrCode as micrCode, ");
        builder.append("aid.modalPremium as modalPremium, ");
        builder.append("aid.moduleApplicable as moduleApplicable, ");
        builder.append("aid.parentCompany as parentCompany, ");
        builder.append("aid.personalEmail as personalEmail, ");
        builder.append("aid.personalMobileISD as personalMobileISD, ");
        builder.append("aid.personalMobileNumber as personalMobileNumber, ");
        builder.append("aid.plotnoSurveynoHouseFlatno as plotnoSurveynoHouseFlatno, ");
        builder.append("aid.policyEndDate as policyEndDate, ");
        builder.append("aid.policyTerm as policyTerm, ");
        builder.append("aid.policyType as policyType, ");
        builder.append("aid.rateofInterest as rateofInterest, ");
        builder.append("aid.sanctionDate as sanctionDate, ");
        builder.append("aid.securityCount as securityCount, ");
        builder.append("aid.securityDetails as securityDetails, ");
        builder.append("aid.sumAssured as sumAssured, ");
        builder.append("aid.transactionFrequency as transactionFrequency, ");
        builder.append("aid.transactionId as transactionId, ");
        builder.append("aid.uid as uid, ");
        builder.append("aid.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccountInfoDetData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer accountId = rs.getInt("accountId");
        final String accountNumber = rs.getString("accountNumber");
        final Integer customerId = rs.getInt("customerId");
        final String accountRisk = rs.getString("accountRisk");
        final String accountRiskEffectiveDate = rs.getString("accountRiskEffectiveDate");
        final String accountRiskNextReviewDate = rs.getString("accountRiskNextReviewDate");
        final String accountSegment = rs.getString("accountSegment");
        final String accountSegmentEffectiveDate = rs.getString("accountSegmentEffectiveDate");
        final String accountType = rs.getString("accountType");
        final String applicationNumber = rs.getString("applicationNumber");
        final String applicationSignedDate = rs.getString("applicationSignedDate");
        final String asOfDate = rs.getString("asOfDate");
        final String bankCode = rs.getString("bankCode");
        final String bankName = rs.getString("bankName");
        final String bankbranchname = rs.getString("bankbranchname");
        final String channel = rs.getString("channel");
        final String clientStatus = rs.getString("clientStatus");
        final String creditorBusinessUnit = rs.getString("creditorBusinessUnit");
        final String creditorRMEmail = rs.getString("creditorRMEmail");
        final String currency = rs.getString("currency");
        final Integer dpid = rs.getInt("dpid");
        final String fundedType = rs.getString("fundedType");
        final double grossAnnualPremiumwithTax = rs.getDouble("grossAnnualPremiumwithTax");
        final double grossAnnualPremiumwithoutTax = rs.getDouble("grossAnnualPremiumwithoutTax");
        final String ifscCode = rs.getString("ifscCode");
        final double incomeMultiplier = rs.getDouble("incomeMultiplier");
        final String insurancePurpose = rs.getString("insurancePurpose");
        final String intermediaryCode = rs.getString("intermediaryCode");
        final String introducerEmployeeCode = rs.getString("introducerEmployeeCode");
        final String micrCode = rs.getString("micrCode");
        final double modalPremium = rs.getDouble("modalPremium");
        final String moduleApplicable = rs.getString("moduleApplicable");
        final String parentCompany = rs.getString("parentCompany");
        final String personalEmail = rs.getString("personalEmail");
        final String personalMobileISD = rs.getString("personalMobileISD");
        final String personalMobileNumber = rs.getString("personalMobileNumber");
        final String plotnoSurveynoHouseFlatno = rs.getString("plotnoSurveynoHouseFlatno");
        final String policyEndDate = rs.getString("policyEndDate");
        final String policyTerm = rs.getString("policyTerm");
        final String policyType = rs.getString("policyType");
        final String rateofInterest = rs.getString("rateofInterest");
        final String sanctionDate = rs.getString("sanctionDate");
        final Integer securityCount = rs.getInt("securityCount");
        final String securityDetails = rs.getString("securityDetails");
        final double sumAssured = rs.getDouble("sumAssured");
        final String transactionFrequency = rs.getString("transactionFrequency");
        final String transactionId = rs.getString("transactionId");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new AccountInfoDetData(id,accountId, accountNumber,customerId,accountRisk, accountRiskEffectiveDate, accountRiskNextReviewDate, accountSegment, accountSegmentEffectiveDate, accountType, applicationNumber, applicationSignedDate, asOfDate, bankCode, bankName, bankbranchname, channel, clientStatus, creditorBusinessUnit, creditorRMEmail, currency, dpid, fundedType,  grossAnnualPremiumwithTax, grossAnnualPremiumwithoutTax, ifscCode, incomeMultiplier, insurancePurpose, intermediaryCode, introducerEmployeeCode, micrCode, modalPremium, moduleApplicable, parentCompany, personalEmail, personalMobileISD, personalMobileNumber, plotnoSurveynoHouseFlatno, policyEndDate, policyTerm, policyType, rateofInterest, sanctionDate, securityCount, securityDetails, sumAssured, transactionFrequency, transactionId, uid, euid);
    }
}
