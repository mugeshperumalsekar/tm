package com.ponsun.transaction.account.Acc_Pay_Details.rowmapper;

import com.ponsun.transaction.account.Acc_Pay_Details.data.AccPayDetailsData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
@Service
@Slf4j
@Data
public class AccPayDetailsRowMapper  implements RowMapper<AccPayDetailsData> {
    private final String schema;

    public AccPayDetailsRowMapper() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("FROM tm_acc_pay_details apd ");
        this.schema = builder.toString();
    }

    public String tableSchema() {
        final StringBuilder builder = new StringBuilder(200);
        builder.append("apd.id as id, ");
        builder.append("apd.amountofLastRepayment as amountofLastRepayment, ");
        builder.append("apd.customerId as customerId, ");
        builder.append("apd.amountoverdue as amountoverdue, ");
        builder.append("apd.daysPastDue as daysPastDue, ");
        builder.append("apd.otherChargesOutstanding as otherChargesOutstanding, ");
        builder.append("apd.payTerm as payTerm, ");
        builder.append("apd.tenureinMonths as tenureinMonths, ");
        builder.append("apd.accountId as accountId, ");
        builder.append("apd.uid as uid, ");
        builder.append("apd.euid as euid ");
        builder.append(this.schema);
        return builder.toString();
    }

    @Override
    public AccPayDetailsData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final double amountofLastRepayment = rs.getDouble("amountofLastRepayment");
        final Integer customerId = rs.getInt("customerId");
        final double amountoverdue = rs.getDouble("amountoverdue");
        final Integer daysPastDue = rs.getInt("daysPastDue");
        final double otherChargesOutstanding = rs.getDouble("otherChargesOutstanding");
        final Integer payTerm = rs.getInt("payTerm");
        final Integer tenureinMonths = rs.getInt("tenureinMonths");
        final Integer accountId = rs.getInt("accountId");
        final Integer uid = rs.getInt("uid");
        final Integer euid = rs.getInt("euid");
        return new AccPayDetailsData(id, amountofLastRepayment,customerId, amountoverdue, daysPastDue, otherChargesOutstanding, payTerm, tenureinMonths, accountId, uid, euid);
    }
}