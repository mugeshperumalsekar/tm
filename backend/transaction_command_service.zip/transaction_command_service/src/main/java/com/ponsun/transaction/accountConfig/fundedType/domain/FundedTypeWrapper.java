package com.ponsun.transaction.accountConfig.fundedType.domain;


import com.ponsun.transaction.accountConfig.fundedType.request.AbstractFundedTypeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class FundedTypeWrapper extends AbstractFundedTypeRequest {
    private final FundedTypeRepository fundedTypeRepository;

    @Transactional
    public FundedType findOneWithNotFoundDetection(final Integer id) {
        return this.fundedTypeRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("FundedType Not found " + id));
    }
    @Override
    public String toString() {
        return super.toString();
    }
}

