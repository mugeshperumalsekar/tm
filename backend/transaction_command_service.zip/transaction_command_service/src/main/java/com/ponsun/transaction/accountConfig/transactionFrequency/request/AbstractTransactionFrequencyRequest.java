package com.ponsun.transaction.accountConfig.transactionFrequency.request;

import lombok.Data;

@Data
public class AbstractTransactionFrequencyRequest {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
}
