package com.ponsun.transaction.accountConfig.insurancePurpose.domain;

import com.ponsun.transaction.accountConfig.insurancePurpose.request.CreateInsurancePurposeRequest;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.UpdateInsurancePurposeRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_InsurancePurpose")
public class InsurancePurpose extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static InsurancePurpose create(final CreateInsurancePurposeRequest createInsurancePurposeRequest){
        final InsurancePurpose insurancePurpose = new InsurancePurpose();
        insurancePurpose.setName(createInsurancePurposeRequest.getName());
        insurancePurpose.setCode(createInsurancePurposeRequest.getCode());
        insurancePurpose.setUid(createInsurancePurposeRequest.getUid());
        insurancePurpose.setStatus(Status.ACTIVE);
        insurancePurpose.setCreatedAt(LocalDateTime.now());
        return insurancePurpose;
    }
    public void update(final UpdateInsurancePurposeRequest updateInsurancePurposeRequest){
        this.setName(updateInsurancePurposeRequest.getName());
        this.setCode(updateInsurancePurposeRequest.getCode());
        this.setEuid(updateInsurancePurposeRequest.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}

