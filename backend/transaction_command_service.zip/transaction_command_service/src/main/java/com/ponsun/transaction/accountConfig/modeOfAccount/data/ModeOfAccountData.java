package com.ponsun.transaction.accountConfig.modeOfAccount.data;
import lombok.Data;
@Data
public class ModeOfAccountData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;
    public ModeOfAccountData(final Integer id, final String name, final String code, final Integer uid, final Integer euid ) {
        this.id=id;
        this.name=name;
        this.code=code;
        this.uid=uid;
        this.euid=euid;

    }
    public static ModeOfAccountData newInstance (final Integer id, final String name, final String code, final Integer uid, final Integer euid ) {
        return new ModeOfAccountData(id,name,code,uid,euid);
    }
}

