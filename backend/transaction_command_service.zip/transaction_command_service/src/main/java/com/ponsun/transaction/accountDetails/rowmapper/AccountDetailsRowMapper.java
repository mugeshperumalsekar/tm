package com.ponsun.transaction.accountDetails.rowmapper;


import com.ponsun.transaction.accountDetails.data.AccountDetailsData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
@Data
@Service
@Slf4j
public class AccountDetailsRowMapper implements RowMapper<AccountDetailsData> {
    private final String schema;
    public AccountDetailsRowMapper(){
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM sender_receiver_details a ");
        this.schema = builder.toString();
    }
    public String tableSchema(){
        final StringBuilder builder = new StringBuilder(200);
        builder.append("a.id as id, ");
        builder.append("a.date as date, ");
        builder.append("a.senderCustomer as senderCustomer, ");
        builder.append("a.senderAccount as senderAccount ,");
        builder.append("a.sender as sender, ");
        builder.append("a.senderBankName as senderBankName, ");
        builder.append("a.receiverCustomer as receiverCustomer, ");
        builder.append("a.receiverAccount as receiverAccount, ");
        builder.append("a.receiver as receiver, ");
        builder.append("a.receiverBankName as receiverBankName, ");
        builder.append("a.description as description, ");
        builder.append("a.deposits as deposits, ");
        builder.append("a.withdrawals as withdrawals, ");
        builder.append("a.balance as balance ");

        builder.append(this.schema);
        return builder.toString();
    }
    @Override
    public AccountDetailsData mapRow(ResultSet rs, int rowNum) throws SQLException{
        final Integer id = rs.getInt("id");
        final Date    date = rs.getDate("date");
        final String  senderCustomer = rs.getString("senderCustomer");
        final String  senderAccount = rs.getString("senderAccount");
        final String  sender = rs.getString("sender");
        final String  senderBankName = rs.getString("senderBankName");
        final String  receiverCustomer = rs.getString("receiverCustomer");
        final String  receiverAccount = rs.getString("receiverAccount");
        final String  receiver = rs.getString("receiver");
        final String  receiverBankName = rs.getString("receiverBankName");
        final String  description = rs.getString("description");
        final String  deposits = rs.getString("deposits");
        final String  withdrawals = rs.getString("withdrawals");
        final String  balance = rs.getString("balance");
        return new AccountDetailsData(id,date,senderCustomer,senderAccount,sender,senderBankName,receiverCustomer,receiverAccount,receiver,receiverBankName,description,deposits,withdrawals,balance);
    }
}
