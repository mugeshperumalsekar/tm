package com.ponsun.transaction.account.Acc_Info_det.services;
import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDet;

import java.util.List;

public interface AccountInfoDetReadService {

    AccountInfoDet fetchAccountInfoDetById(Integer id);
    List<AccountInfoDet> fetchAllAccountInfoDet();
    List<AccountInfoDet> fetchActiveAccountInfoDet();
    List<AccountInfoDet> fetchDeActiveAccountInfoDet();
}
