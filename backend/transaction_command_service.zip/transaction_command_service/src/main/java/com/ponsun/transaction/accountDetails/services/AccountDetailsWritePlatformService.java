package com.ponsun.transaction.accountDetails.services;

import com.ponsun.transaction.accountDetails.request.CreateAccountDetailsRequest;
import com.ponsun.transaction.accountDetails.request.UpdateAccountDetailsRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccountDetailsWritePlatformService {
    Response createAccountDetails(CreateAccountDetailsRequest createAccountDetailsRequest);

    Response updateAccountDetails(Integer id, UpdateAccountDetailsRequest updateAccountDetailsRequest) ;

    Response blockAccountDetails(Integer id) ;

    Response unblockAccountDetails(Integer id)  ;

//    Response AlertGeneration();
}
