package com.ponsun.transaction.accountConfig.accountSegment.requests;

import lombok.Data;

@Data
public class UpdateAccountSegmentRequest extends AbstractAccountSegmentRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
