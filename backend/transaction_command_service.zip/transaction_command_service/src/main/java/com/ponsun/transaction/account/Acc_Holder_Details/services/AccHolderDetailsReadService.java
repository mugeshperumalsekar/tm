package com.ponsun.transaction.account.Acc_Holder_Details.services;
import com.ponsun.transaction.account.Acc_Holder_Details.domain.AccHolderDetails;

import java.util.List;

public interface AccHolderDetailsReadService {
    AccHolderDetails fetchAccHolderDetailsById(Integer id);
    List<AccHolderDetails> fetchAllAccHolderDetails();
    List<AccHolderDetails> fetchActiveAccHolderDetails();
    List<AccHolderDetails> fetchDeActiveAccHolderDetails();

}
