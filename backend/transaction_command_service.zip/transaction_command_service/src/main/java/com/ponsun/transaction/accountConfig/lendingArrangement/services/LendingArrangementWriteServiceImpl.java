package com.ponsun.transaction.accountConfig.lendingArrangement.services;


import com.ponsun.transaction.accountConfig.lendingArrangement.request.UpdateLendingArrangementRequest;
import com.ponsun.transaction.accountConfig.lendingArrangement.data.LendingArrangementValidator;
import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangement;
import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangementRepository;
import com.ponsun.transaction.accountConfig.lendingArrangement.domain.LendingArrangementWrapper;
import com.ponsun.transaction.accountConfig.lendingArrangement.request.CreateLendingArrangementRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.exceptions.PS_transaction_ApplicationException;
import com.ponsun.transaction.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class LendingArrangementWriteServiceImpl implements LendingArrangementWriteService {

    private final LendingArrangementRepository lendingArrangementRepository;
    private final LendingArrangementWrapper lendingArrangementWrapper;
    private final LendingArrangementValidator lendingArrangementValidator;


    @Transactional
    public Response createLendingArrangement(CreateLendingArrangementRequest createLendingArrangementRequest) {
        try {
            this.lendingArrangementValidator.validateSaveLendingArrangement(createLendingArrangementRequest);
            final LendingArrangement lendingArrangement = LendingArrangement.create(createLendingArrangementRequest);
            this.lendingArrangementRepository.saveAndFlush(lendingArrangement);
            return Response.of(Long.valueOf(lendingArrangement.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateLendingArrangement(Integer id, UpdateLendingArrangementRequest updateLendingArrangementRequest) {
        try {
            this.lendingArrangementValidator.validateUpdateLendingArrangement(updateLendingArrangementRequest);
            final LendingArrangement lendingArrangement = this.lendingArrangementWrapper.findOneWithNotFoundDetection(id);
            lendingArrangement.update(updateLendingArrangementRequest);
            this.lendingArrangementRepository.saveAndFlush(lendingArrangement);
            return Response.of(Long.valueOf(lendingArrangement.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response unblockLendingArrangement(Integer id) {
        try {
            final LendingArrangement lendingArrangement = this.lendingArrangementWrapper.findOneWithNotFoundDetection(id);
            lendingArrangement.setStatus(Status.ACTIVE);
            lendingArrangement.setUpdatedAt(LocalDateTime.now());
            this.lendingArrangementRepository.saveAndFlush(lendingArrangement);
            return Response.of(Long.valueOf(id));
        } catch (DataIntegrityViolationException e) {
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deActivate(Integer id, Integer euid){
        try{
            LendingArrangement lendingArrangement = this.lendingArrangementWrapper.findOneWithNotFoundDetection(id);
            lendingArrangement.setEuid(euid);
            lendingArrangement.setStatus(Status.DELETE);
            lendingArrangement.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(lendingArrangement.getId()));
        }catch (DataIntegrityViolationException e){
            throw new PS_transaction_ApplicationException(e.getMessage());
        }
    }
}
