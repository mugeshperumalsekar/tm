package com.ponsun.transaction.account.Acc_Info.services;

import com.ponsun.transaction.account.Acc_Info.domain.AccInfo;
import com.ponsun.transaction.account.Acc_Info.domain.AccInfoRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccInfoReadServiceImpl implements AccInfoReadService {
    private final AccInfoRepository repository;

    @Override
    @Transactional
    public AccInfo fetchAccInfoById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccInfo> fetchAllAccInfo() {
        return this.repository.findAll();
    }

    @Override
    public List<AccInfo> fetchActiveAccInfo() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccInfo> fetchDeActiveAccInfo() {
        return repository.findByStatus(Status.DELETE);
    }
}
