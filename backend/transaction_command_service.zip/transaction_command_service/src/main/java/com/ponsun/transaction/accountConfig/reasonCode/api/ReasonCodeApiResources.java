package com.ponsun.transaction.accountConfig.reasonCode.api;


import com.ponsun.transaction.accountConfig.reasonCode.domain.ReasonCode;
import com.ponsun.transaction.accountConfig.reasonCode.request.CreateReasonCodeRequest;
import com.ponsun.transaction.accountConfig.reasonCode.request.UpdateReasonCodeRequest;
import com.ponsun.transaction.accountConfig.reasonCode.services.ReasonCodeReadService;
import com.ponsun.transaction.accountConfig.reasonCode.services.ReasonCodeWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/ReasonCode")
@Tag(name = "ReasonCodeApiResource")
public class ReasonCodeApiResources {
    private final ReasonCodeWriteService reasonCodeWriteService;
    private final ReasonCodeReadService reasonCodeReadService;

    @PostMapping("/CreateReasonCodeRequest")
    public Response saveReasonCode(@RequestBody CreateReasonCodeRequest createReasonCodeRequest) {
        log.debug("START saveReasonCode request body {}",createReasonCodeRequest);
        Response response = this.reasonCodeWriteService.createReasonCode(createReasonCodeRequest);
        log.debug("START saveReasonCode response",response);
        return response;
    }

    @GetMapping
    public List<ReasonCode> fetchAll() {
        return this.reasonCodeReadService.fetchAllReasonCode();
    }

    @GetMapping("/{id}")
    public ReasonCode fetchReasonCodeById(@PathVariable(name = "id") Integer id) {
        return this.reasonCodeReadService.fetchReasonCodeById(id);
    }

    @PutMapping("/{id}")
    public Response updateReasonCode(@PathVariable Integer id, @RequestBody UpdateReasonCodeRequest updateReasonCodeRequest) {
        log.debug("START updateReasonCode request body {}",updateReasonCodeRequest);
        Response response = this.reasonCodeWriteService.updateReasonCode(id, updateReasonCodeRequest);
        log.debug("START updateReasonCode response",response);
        return response;
    }

    @PutMapping("/{id}/unblock")
    public Response unblockReasonCode(@PathVariable Integer id){
        Response response = this.reasonCodeWriteService.unblockReasonCode(id);
        return response;
    }
    @PutMapping("/{id}/deActivate")
    public Response deActivate(@PathVariable Integer id, Integer euid) {
        Response response = this.reasonCodeWriteService.deActivate(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<ReasonCode> fetchActiveReasonCode() {
        return reasonCodeReadService.fetchActiveReasonCode();
    }
    @GetMapping("DeActive")
    public List<ReasonCode> fetchDeReasonCode() {
        return reasonCodeReadService.fetchDeActiveReasonCode();
    }

}

