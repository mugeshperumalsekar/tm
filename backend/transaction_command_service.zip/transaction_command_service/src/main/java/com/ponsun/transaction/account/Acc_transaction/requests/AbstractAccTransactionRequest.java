package com.ponsun.transaction.account.Acc_transaction.requests;

import jakarta.persistence.Column;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AbstractAccTransactionRequest {

    private Integer id;
    private Integer accountId;
    private double amt;
    private String transStatus;
    private String applicationNumber;
    private String cardSubtype;
    private String cardType;
    private String clientBankName;
    private String clientBankCode;
    private String clientBankAccountNo;
    private String counterPartyProductAccountType;
    private String counterPartyProductAccountNumber;
    private Integer instrumentTypeId;
    private String instrumentNo;
    private String originalCurrency;
    private String organisationPoolAccount;
    private String remark;
    private LocalDateTime transactionDate;
    private Integer voucherTypeId;
    private Integer type2Id;
    private String voucherNo;
    private String userId;
    private String uid;
    private Integer euid;

}