package com.ponsun.transaction.account.Acc_Info_det.services;

import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDet;
import com.ponsun.transaction.account.Acc_Info_det.domain.AccountInfoDetRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountInfoDetReadServiceImpl implements AccountInfoDetReadService {
    private final AccountInfoDetRepository repository;

    @Override
    @Transactional
    public AccountInfoDet fetchAccountInfoDetById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    @Transactional
    public List<AccountInfoDet> fetchAllAccountInfoDet() {
        return this.repository.findAll();
    }

    @Override
    public List<AccountInfoDet> fetchActiveAccountInfoDet() {
        return repository.findByStatus(Status.ACTIVE);
    }
    @Override
    public List<AccountInfoDet> fetchDeActiveAccountInfoDet() {
        return repository.findByStatus(Status.DELETE);
    }
}


