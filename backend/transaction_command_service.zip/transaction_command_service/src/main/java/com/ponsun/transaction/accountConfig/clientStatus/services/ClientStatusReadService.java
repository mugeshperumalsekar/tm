package com.ponsun.transaction.accountConfig.clientStatus.services;

import com.ponsun.transaction.accountConfig.clientStatus.domain.ClientStatus;

import java.util.List;

public interface ClientStatusReadService {
    List<ClientStatus> fetchAllClientStatus();

    ClientStatus fetchClientStatusById(Integer id);

    List<ClientStatus> fetchActiveClientStatus();

    List<ClientStatus> fetchDeActiveClientStatus();
}
