package com.ponsun.transaction.account.Acc_Pay_Details.api;

import com.ponsun.transaction.account.Acc_Pay_Details.domain.AccPayDetails;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.CreateAccPayDetailsRequest;
import com.ponsun.transaction.account.Acc_Pay_Details.requests.UpdateAccPayDetailsRequest;
import com.ponsun.transaction.account.Acc_Pay_Details.services.AccPayDetailsReadService;
import com.ponsun.transaction.account.Acc_Pay_Details.services.AccPayDetailsWriteService;
import com.ponsun.transaction.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/AccPayDetails")
@Tag(name = "AccPayDetailsApiResources")
public class AccPayDetailsApiResources {
    private final AccPayDetailsWriteService writeService;
    private final AccPayDetailsReadService readService;

    @PostMapping("/CreateAccPayDetailsRequest")
    public Response createAccPayDetails(@RequestBody CreateAccPayDetailsRequest request) {
        Response response = this.writeService.createAccPayDetails(request);
        return response;
    }
    @PutMapping("/{id}")
    public Response updateAccPayDetails(@PathVariable Integer id, @RequestBody UpdateAccPayDetailsRequest request) {
        Response response = this.writeService.updateAccPayDetails(id, request);
        return response;
    }
    @GetMapping("/{id}")
    public AccPayDetails fetchAccPayDetailsById(@PathVariable(name = "id") Integer id) {
        return this.readService.fetchAccPayDetailsById(id);
    }
    @GetMapping
    public List<AccPayDetails> fetchAll() {
        return this.readService.fetchAllAccPayDetails();
    }

    @PutMapping("/{id}/unblock")
    public Response unblockAccPayDetails(@PathVariable Integer id){
        Response response = this.writeService.unblockAccPayDetails(id);
        return  response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.writeService.deactive(id, euid);
        return response;
    }

    @GetMapping("active")
    public List<AccPayDetails> fetchActiveAccPayDetails() {
        return readService.fetchActiveAccPayDetails();
    }
    @GetMapping("DeActive")
    public List<AccPayDetails> fetchDeAccPayDetails() {
        return readService.fetchDeActiveAccPayDetails();
    }

}
