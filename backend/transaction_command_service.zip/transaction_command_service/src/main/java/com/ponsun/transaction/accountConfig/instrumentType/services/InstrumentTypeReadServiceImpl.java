package com.ponsun.transaction.accountConfig.instrumentType.services;

import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentType;
import com.ponsun.transaction.accountConfig.instrumentType.domain.InstrumentTypeRepository;
import com.ponsun.transaction.common.entity.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@RequiredArgsConstructor
@Slf4j
public class InstrumentTypeReadServiceImpl implements InstrumentTypeReadService {
    private final InstrumentTypeRepository repository;

    @Override
    public InstrumentType fetchInstrumentTypeById(Integer id) {
        return this.repository.findById(id).get();
    }

    @Override
    public List<InstrumentType> fetchAllInstrumentType() {
        return this.repository.findAll();
    }

    @Override
    public List<InstrumentType> fetchActiveInstrumentType() {
        return this.repository.findByStatus(Status.ACTIVE);
    }

    @Override
    public List<InstrumentType> fetchDeActiveInstrumentType() {
        return this.repository.findByStatus(Status.DELETE);
    }
}
