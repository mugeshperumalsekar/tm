package com.ponsun.transaction.accountConfig.debtSubType.services;

import com.ponsun.transaction.accountConfig.debtSubType.domain.DebtSubType;

import java.util.List;

public interface DebtSubTypeReadService {
    List<DebtSubType> fetchAllDebtSubType();

    DebtSubType fetchDebtSubTypeById(Integer id);

    List<DebtSubType> fetchActiveDebtSubType();

    List<DebtSubType> fetchDeActiveDebtSubType();
}
