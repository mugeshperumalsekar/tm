package com.ponsun.transaction.accountConfig.instrumentType.domain;
import com.ponsun.transaction.accountConfig.instrumentType.requests.AbstractInstrumentTypeRequest;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class InstrumentTypeWrapper extends AbstractInstrumentTypeRequest {

    private final InstrumentTypeRepository repository;

    @Transactional
    public InstrumentType findOneWithNotFoundDetection (final Integer id) {
    return this.repository.findById(id).orElse(null);//.orElseThrow(() -> new EntityNotFoundException("InstrumentCategory Not found " + id));
}

    @Transactional
    public InstrumentType findOneWithNotFoundDetection (final String name) {
        return this.repository.findbyName(name).orElseThrow(() -> new EntityNotFoundException("Instrument Type Not found " + name));
    }
    @Override
    public String toString(){
        return super.toString();
    }

}
