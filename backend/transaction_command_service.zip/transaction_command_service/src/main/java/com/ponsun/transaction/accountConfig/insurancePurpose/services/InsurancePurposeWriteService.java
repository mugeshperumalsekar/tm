package com.ponsun.transaction.accountConfig.insurancePurpose.services;

import com.ponsun.transaction.accountConfig.insurancePurpose.request.CreateInsurancePurposeRequest;
import com.ponsun.transaction.accountConfig.insurancePurpose.request.UpdateInsurancePurposeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface InsurancePurposeWriteService {
    Response createInsurancePurpose(CreateInsurancePurposeRequest createInsurancePurposeRequest);

    Response updateInsurancePurpose(Integer id, UpdateInsurancePurposeRequest updateInsurancePurposeRequest);

    Response unblockInsurancePurpose(Integer id);

    Response deActivate(Integer id, Integer euid);
}
