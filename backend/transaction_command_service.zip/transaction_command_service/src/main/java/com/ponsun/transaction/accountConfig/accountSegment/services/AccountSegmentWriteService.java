package com.ponsun.transaction.accountConfig.accountSegment.services;

import com.ponsun.transaction.infrastructure.utils.Response;
import com.ponsun.transaction.accountConfig.accountSegment.requests.CreateAccountSegmentRequest;
import com.ponsun.transaction.accountConfig.accountSegment.requests.UpdateAccountSegmentRequest;

public interface AccountSegmentWriteService {
    Response createAccountSegment(CreateAccountSegmentRequest request);
    Response updateAccountSegment(Integer id, UpdateAccountSegmentRequest request);
    Response unblockAccountSegment(Integer id);
    Response deactive(Integer id, Integer euid);

}

