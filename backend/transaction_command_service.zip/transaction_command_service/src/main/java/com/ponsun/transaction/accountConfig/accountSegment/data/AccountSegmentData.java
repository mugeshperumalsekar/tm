package com.ponsun.transaction.accountConfig.accountSegment.data;

import lombok.Data;

@Data
public class AccountSegmentData {
    private Integer id;
    private String name;
    private String code;
    private Integer uid;
    private Integer euid;

    public AccountSegmentData(Integer id, String name, String code, Integer uid, Integer euid) {
        this.id = id;
        this.name = name;
        this.code = code;
        this.uid = uid;
        this.euid = euid;
    }
    public static AccountSegmentData newInstance(Integer id, String name, String code, Integer uid, Integer euid){
        return new AccountSegmentData(id,name,code,uid,euid);
    }
}
