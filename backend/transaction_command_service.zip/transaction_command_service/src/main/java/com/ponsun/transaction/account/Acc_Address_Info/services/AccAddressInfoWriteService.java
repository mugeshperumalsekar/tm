package com.ponsun.transaction.account.Acc_Address_Info.services;

import com.ponsun.transaction.account.Acc_Address_Info.requests.CreateAccAddressInfoRequest;
import com.ponsun.transaction.account.Acc_Address_Info.requests.UpdateAccAddressInfoRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface AccAddressInfoWriteService {
    Response createAccAddressInfo(CreateAccAddressInfoRequest request);
    Response updateAccAddressInfo(Integer id, UpdateAccAddressInfoRequest request);
    Response unblockAccAddressInfo(Integer id);
    Response deactive(Integer id, Integer euid);
}
