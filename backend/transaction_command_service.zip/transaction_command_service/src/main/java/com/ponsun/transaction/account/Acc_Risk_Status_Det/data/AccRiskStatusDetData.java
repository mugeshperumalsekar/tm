package com.ponsun.transaction.account.Acc_Risk_Status_Det.data;
import lombok.Data;

@Data
public class AccRiskStatusDetData {
    private Integer id;
    private Integer accountId;
    private Integer customerId;
    private String accountRisk;
    private String accountRiskEffectiveDate;
    private String accountRiskNextReviewDate;
    private String clientStatus;
    private String accountNumber;
    private Integer uid;
    private Integer euid;


    public AccRiskStatusDetData(Integer id, Integer accountId, Integer customerId, String accountRisk, String accountRiskEffectiveDate, String accountRiskNextReviewDate, String clientStatus, String accountNumber, Integer uid, Integer euid) {
        this.id = id;
        this.accountId = accountId;
        this.customerId = customerId;
        this.accountRisk = accountRisk;
        this.accountRiskEffectiveDate = accountRiskEffectiveDate;
        this.accountRiskNextReviewDate = accountRiskNextReviewDate;
        this.clientStatus = clientStatus;
        this.accountNumber = accountNumber;
        this.uid = uid;
        this.euid = euid;
    }
    public static AccRiskStatusDetData newInstance(Integer id, Integer accountId, Integer customerId, String accountRisk, String accountRiskEffectiveDate, String accountRiskNextReviewDate, String clientStatus, String accountNumber, Integer uid, Integer euid){
        return new AccRiskStatusDetData(id,accountId,customerId,accountRisk,accountRiskEffectiveDate,accountRiskNextReviewDate,clientStatus,accountNumber,uid,euid);
    }
}
