package com.ponsun.transaction.accountConfig.accountSegment.domain;

import com.ponsun.transaction.accountConfig.accountSegment.requests.CreateAccountSegmentRequest;
import com.ponsun.transaction.accountConfig.accountSegment.requests.UpdateAccountSegmentRequest;
import com.ponsun.transaction.common.entity.Status;
import com.ponsun.transaction.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Entity
@Accessors(chain = true)
@Table(name = "tm_config_account_segment")
public class AccountSegment extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static AccountSegment create(final CreateAccountSegmentRequest request) {
        final AccountSegment accountSegment = new AccountSegment();
        accountSegment.setName(request.getName());
        accountSegment.setCode(request.getCode());
        accountSegment.setUid(request.getUid());
        accountSegment.setEuid(request.getEuid());
        accountSegment.setStatus(Status.ACTIVE);
        accountSegment.setCreatedAt(LocalDateTime.now());
        return accountSegment;
    }

    public void update(final UpdateAccountSegmentRequest request) {
        this.setName(request.getName());
        this.setCode(request.getCode());
        this.setUid(request.getUid());
        this.setEuid(request.getEuid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }
}
