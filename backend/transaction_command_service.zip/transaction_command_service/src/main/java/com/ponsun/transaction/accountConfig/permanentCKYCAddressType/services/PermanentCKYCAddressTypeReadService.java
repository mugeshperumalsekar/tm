package com.ponsun.transaction.accountConfig.permanentCKYCAddressType.services;

import com.ponsun.transaction.accountConfig.permanentCKYCAddressType.domain.PermanentCKYCAddressType;

import java.util.List;

public interface PermanentCKYCAddressTypeReadService {
    PermanentCKYCAddressType fetchAccAddressTypeById(Integer id);

    List<PermanentCKYCAddressType> fetchAllAccAddressType();

    List<PermanentCKYCAddressType> fetchActivePermanentCKYCAddressType();

    List<PermanentCKYCAddressType> fetchDeActivePermanentCKYCAddressType();
}
