package com.ponsun.transaction.account.Acc_Info.data;
import lombok.Data;

@Data
public class AccInfoData {
    private Integer id;
    private Integer customerId;
    private String productAccOpeningDate;
    private String productAccountNumber;
    private String productAccountReasonCodeDescription;
    private String productAccountStatus;
    private String productAccountStatusDescription;
    private String productAccountStatusEffectiveDate;
    private String productAccountStatusReasonCode;
    private String productAccountType;
    private String productApplicationDate;
    private String productSegments;
    private String rmCode;
    private String rmType;
    private String tags;
    private String underwritingDate;
    private Integer uid;
    private Integer euid;

    public AccInfoData(Integer id,Integer customerId, String productAccOpeningDate, String productAccountNumber, String productAccountReasonCodeDescription, String productAccountStatus, String productAccountStatusDescription, String productAccountStatusEffectiveDate, String productAccountStatusReasonCode, String productAccountType, String productApplicationDate, String productSegments, String rmCode, String rmType, String tags, String underwritingDate, Integer uid, Integer euid) {
        this.id = id;
        this.customerId = customerId;
        this.productAccOpeningDate = productAccOpeningDate;
        this.productAccountNumber = productAccountNumber;
        this.productAccountReasonCodeDescription = productAccountReasonCodeDescription;
        this.productAccountStatus = productAccountStatus;
        this.productAccountStatusDescription = productAccountStatusDescription;
        this.productAccountStatusEffectiveDate = productAccountStatusEffectiveDate;
        this.productAccountStatusReasonCode = productAccountStatusReasonCode;
        this.productAccountType = productAccountType;
        this.productApplicationDate = productApplicationDate;
        this.productSegments = productSegments;
        this.rmCode = rmCode;
        this.rmType = rmType;
        this.tags = tags;
        this.underwritingDate = underwritingDate;
        this.uid = uid;
        this.euid = euid;
    }
    public static AccInfoData newInstance(Integer id,Integer customerId, String productAccOpeningDate, String productAccountNumber, String productAccountReasonCodeDescription, String productAccountStatus, String productAccountStatusDescription, String productAccountStatusEffectiveDate, String productAccountStatusReasonCode, String productAccountType, String productApplicationDate, String productSegments, String rmCode, String rmType, String tags, String underwritingDate, Integer uid, Integer euid){
        return new AccInfoData( id,customerId, productAccOpeningDate, productAccountNumber, productAccountReasonCodeDescription, productAccountStatus, productAccountStatusDescription, productAccountStatusEffectiveDate, productAccountStatusReasonCode, productAccountType, productApplicationDate, productSegments, rmCode, rmType, tags, underwritingDate, uid, euid);
    }
}
