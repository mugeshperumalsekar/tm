package com.ponsun.transaction.accountConfig.instrumentType.services;

import com.ponsun.transaction.accountConfig.instrumentType.requests.CreateInstrumentTypeRequest;
import com.ponsun.transaction.accountConfig.instrumentType.requests.UpdateInstrumentTypeRequest;
import com.ponsun.transaction.infrastructure.utils.Response;

public interface InstrumentTypeWriteService {
    Response createInstrumentType(CreateInstrumentTypeRequest request);
    Response updateInstrumentType(Integer id, UpdateInstrumentTypeRequest request);

    Response unblockInstrumentType(Integer id);
    Response deactive(Integer id, Integer euid);

}

