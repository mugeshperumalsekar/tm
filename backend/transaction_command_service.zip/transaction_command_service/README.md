touch .gitignore


cd existing_repo
git remote add origin https://gitlab.com/transaction-monitoring/transaction_command_service.git
git branch -M main
git push -uf origin main

#merge cmd
git checkout main
git fetch origin
git pull origin main
git merge develop
# Resolve any conflicts if necessary
git push origin main


SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `tm_precalc_threshold_details`;
TRUNCATE `tm_pre_calc_threshold`;
TRUNCATE `tm_precalc_threshold_avg_details`;
TRUNCATE `tm_precalc_threshold_max_details`;
TRUNCATE`tm_precalc_threshold_sum_details`;
SET FOREIGN_KEY_CHECKS = 1;
