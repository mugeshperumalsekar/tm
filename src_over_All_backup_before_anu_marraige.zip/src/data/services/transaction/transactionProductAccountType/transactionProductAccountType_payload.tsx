
export interface TransactionProductAccountTypePayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

