export interface InsurancePurposePayload {
    name: string;
    code:string;
    uid:string;
}