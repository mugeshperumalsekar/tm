export interface AccountSegmentPayload {
    name: string;
    code:string;
    uid:string;
}