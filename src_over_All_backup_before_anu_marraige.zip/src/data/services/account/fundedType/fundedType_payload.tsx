export interface FundedTypePayload {
    name: string;
    code:string;
    uid:string;
}