export interface PermanentCKYCAddressTypePayload {
    name: string;
    code:string;
    uid:string;
}