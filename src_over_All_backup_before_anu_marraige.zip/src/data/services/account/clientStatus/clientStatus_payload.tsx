export interface ClientStatusPayload {
    name: string;
    code:string;
    uid:string;
}