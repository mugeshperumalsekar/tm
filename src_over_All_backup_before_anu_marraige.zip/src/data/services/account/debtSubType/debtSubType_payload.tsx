export interface DebtSubTypePayload {
    name: string;
    code:string;
    uid:string;
}