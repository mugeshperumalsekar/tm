export interface Configparamenter {
    scenario_list_id: number;
    scenario_condition_id: number;
    uid: number;
    euid: number;
};