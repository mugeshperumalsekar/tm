export interface IncomeProofPayload {
    name: string;
    code:string;
    uid:string;
}