export interface KYCAttesationPayload {
    name: string;
    code:string;
    uid:string;
}