export interface CountryPayload {
    name: string;
    iso2DigitCode:string;
    uid:string;
}   