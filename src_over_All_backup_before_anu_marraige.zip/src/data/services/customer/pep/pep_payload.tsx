export interface PEPPayload {
    name: string;
    code:string;
    uid:string;
}