export interface PermanentAddressPayload {
    name: string;
    code:string;
    uid:string;
}

