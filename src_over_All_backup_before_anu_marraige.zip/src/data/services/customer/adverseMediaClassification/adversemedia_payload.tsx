export interface AdverseMediaClassificationPayload {
    name: string;
    code:string;
    uid:string;
}