export interface CKYCAddressTypePayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

