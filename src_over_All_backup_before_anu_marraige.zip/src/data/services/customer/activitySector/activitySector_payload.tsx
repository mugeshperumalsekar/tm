export interface ActivitySectorPayload {
    name: string;
    code:string;
    uid:string;
}