export interface RMTypePayload {
    name: string;
    code:string;
    uid:string;
}