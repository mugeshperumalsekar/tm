export interface StatePayload {
    name: string;
    code:string;
    uid:string;
    euid:string;
}

