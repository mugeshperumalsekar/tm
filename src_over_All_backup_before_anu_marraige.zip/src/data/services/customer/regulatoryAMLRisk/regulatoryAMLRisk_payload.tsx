export interface RegulatoryAMLRiskPayload {
    name: string;
    code:string;
    uid:string;
}