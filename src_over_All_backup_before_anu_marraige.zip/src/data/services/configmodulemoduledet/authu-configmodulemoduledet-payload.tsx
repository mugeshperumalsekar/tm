export interface AuthConfigModuleModuleDetPayload {
    modid: Number,
    moddetid: Number,
    modname: String,
    moddetname: String
}