export interface GroundPayload {
    id: number;
    groundsOfSuspicion: string;
    customerId: number;
    accountId: number;
    hitId: number;
    uid: number;
    euid: number;
}